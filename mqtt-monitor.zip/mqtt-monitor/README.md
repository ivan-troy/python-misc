# mqtt-monitor

A lightweight, themeable **terminal dashboard for MQTT** — monitor a broker's
health, watch per-topic statistics, and browse live payloads, all from your
terminal. Built on [paho-mqtt 2.x](https://pypi.org/project/paho-mqtt/) and
[Rich](https://github.com/Textualize/rich).

It answers the questions a raw `mosquitto_sub` can't: *which topics are busiest?
which generate the most traffic? what do their payloads actually look like?* —
while also surfacing the broker's own `$SYS` health metrics.

> Inspired by the idea behind `gambitcomminc/mqtt-stats` (per-topic statistics),
> rebuilt from scratch as a modern, dependency-light, GTK-free terminal app with
> a proper package layout, tests, themes and payload browsing.

---

## Features

- **Broker monitor** — live `$SYS` metrics (uptime, clients, messages, bytes,
  load averages, heap) with human-friendly formatting.
- **Per-topic statistics** — message counts, total bytes, instantaneous
  messages/second, average size, and a last-payload preview.
- **Payload browser** — tail and inspect recent payloads for any topic filter,
  with automatic JSON pretty-printing.
- **Sortable** — order topics by rate, count, bytes, recency, or name; cycle
  live with a keypress.
- **Themes** — seven built-in palettes, including minimalist/monochrome ones,
  swappable at runtime.
- **Robust** — paho 2.x `VERSION2` callbacks, automatic reconnect with
  exponential backoff, TLS and WebSocket support, clean shutdown.
- **Lightweight** — three runtime dependencies (`paho-mqtt`, `rich`, `typer`).

## Install

```bash
# with uv (recommended)
uv venv
uv pip install -e ".[dev]"

# or plain pip
pip install -e ".[dev]"
```

## Quick start

```bash
# full dashboard: broker health + per-topic stats
mqtt-monitor dashboard --host test.mosquitto.org

# per-topic stats only, under a subtree, sorted by throughput
mqtt-monitor topics --host localhost --topic 'sensors/#' --sort bytes

# broker $SYS health only
mqtt-monitor broker --host localhost

# tail payloads on a topic (JSON is pretty-printed)
mqtt-monitor browse 'sensors/+/temperature' --host localhost

# list the available themes with a colour preview
mqtt-monitor themes
```

Run `mqtt-monitor --help` or `mqtt-monitor <command> --help` for all options.

### Interactive keys (dashboard / topics)

| key       | action                         |
| --------- | ------------------------------ |
| `q`       | quit                           |
| `p`/space | pause / resume refresh         |
| `r`       | reset counters (new epoch)     |
| `t`       | cycle theme                    |
| `s`       | cycle sort key                 |

> When stdin is not a TTY (piped, CI, no terminal) the dashboard runs as a
> read-only view and exits cleanly on `Ctrl-C`.

### Authentication & TLS

```bash
export MQTT_PASSWORD='s3cret'          # preferred over --password on the CLI
mqtt-monitor dashboard --host broker.example.com --port 8883 \
    --username alice --tls --ca-certs /etc/ssl/certs/ca.pem
```

## Try it without a broker

A pure-Python broker (`amqtt`, a dev dependency) plus a demo publisher let you
see everything working locally:

```bash
# terminal 1 — start a local broker on :1883
uv run python scripts/local_broker.py

# terminal 2 — publish synthetic sensor traffic
uv run python scripts/demo_publisher.py --host localhost

# terminal 3 — watch it
uv run mqtt-monitor dashboard --host localhost
```

## Development

Convenience scripts wrap the common `uv` workflows:

```bash
./scripts/setup.sh     # create venv + install (dev extras)
./scripts/test.sh      # ruff + mypy + pytest (with coverage)
./scripts/run.sh       # run the dashboard against localhost
```

Or the raw commands:

```bash
uv run ruff check .
uv run mypy
uv run pytest --cov=mqtt_monitor
uv run pytest -m "not integration"   # skip broker-backed tests
```

## Architecture

```
cli.py        Typer commands, argument parsing → MonitorConfig
config.py     frozen MonitorConfig value object (validated)
client.py     paho 2.x wrapper: routes messages into the stores
metrics.py    thread-safe MetricsStore + snapshots + rate computation
sys_topics.py $SYS parsing and human formatting
themes.py     semantic Rich themes (7 palettes)
ui.py         PURE render functions (snapshot + theme → renderable)
app.py        live loops that drive Rich Live around ui.py
keyboard.py   optional non-blocking key reader (stdlib only)
```

**Threading model.** paho runs its network loop on a background thread and
calls `on_message` there; the main thread renders. All shared state lives behind
a lock in `MetricsStore`/`SysMetrics`, and the UI only ever reads immutable
snapshots — so there are no data races and rendering can never see a half-updated
dict. See the source docstrings and the write-up in the chat that generated this
project for the trade-offs versus an asyncio design.

## License

MIT — see [LICENSE](./LICENSE).
