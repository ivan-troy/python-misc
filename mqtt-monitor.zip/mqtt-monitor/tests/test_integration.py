"""End-to-end integration tests against a real (pure-Python) broker.

These use ``amqtt`` to run an actual MQTT broker in a background thread and the
real ``paho`` client, exercising the full path: publish -> broker -> subscribe
-> metrics store. Run only when the dev extras are installed:

    uv run pytest -m integration
"""

from __future__ import annotations

import asyncio
import contextlib
import socket
import threading
import time

import pytest

pytest.importorskip("amqtt", reason="integration tests need the amqtt dev extra")

import paho.mqtt.client as mqtt
from paho.mqtt.enums import CallbackAPIVersion

from mqtt_monitor.client import ConnectionState, MqttMonitorClient
from mqtt_monitor.config import MonitorConfig
from mqtt_monitor.metrics import MetricsStore
from mqtt_monitor.sys_topics import SysMetrics

pytestmark = pytest.mark.integration


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class BrokerThread:
    """Runs an amqtt broker on its own event loop in a daemon thread."""

    def __init__(self, port: int) -> None:
        self.port = port
        self._ready = threading.Event()
        self._loop: asyncio.AbstractEventLoop | None = None
        self._broker = None
        self._thread = threading.Thread(target=self._run, daemon=True)

    def _run(self) -> None:
        from amqtt.broker import Broker

        loop = asyncio.new_event_loop()
        self._loop = loop
        asyncio.set_event_loop(loop)
        config = {
            "listeners": {"default": {"type": "tcp", "bind": f"127.0.0.1:{self.port}"}},
            "sys_interval": 1,
            "auth": {"allow-anonymous": True, "plugins": ["auth_anonymous"]},
            "topic-check": {"enabled": False},
        }
        self._broker = Broker(config, loop=loop)
        loop.run_until_complete(self._broker.start())
        self._ready.set()
        loop.run_forever()

    def start(self, timeout: float = 10.0) -> None:
        self._thread.start()
        assert self._ready.wait(timeout), "broker failed to start"
        self._wait_port()

    def _wait_port(self, timeout: float = 5.0) -> None:
        deadline = time.time() + timeout
        while time.time() < deadline:
            with socket.socket() as s:
                s.settimeout(0.2)
                if s.connect_ex(("127.0.0.1", self.port)) == 0:
                    return
            time.sleep(0.05)
        raise TimeoutError("broker port never opened")

    def stop(self) -> None:
        if self._loop and self._broker:
            fut = asyncio.run_coroutine_threadsafe(self._broker.shutdown(), self._loop)
            with contextlib.suppress(Exception):
                fut.result(5)
            self._loop.call_soon_threadsafe(self._loop.stop)
        self._thread.join(5)


@pytest.fixture
def broker():
    port = _free_port()
    b = BrokerThread(port)
    b.start()
    try:
        yield port
    finally:
        b.stop()


def _publish(port: int, messages: list[tuple[str, bytes]]) -> None:
    pub = mqtt.Client(CallbackAPIVersion.VERSION2, client_id="pytest-pub")
    pub.connect("127.0.0.1", port)
    pub.loop_start()
    time.sleep(0.3)
    for topic, payload in messages:
        info = pub.publish(topic, payload, qos=1)
        info.wait_for_publish(2.0)
    time.sleep(0.3)
    pub.loop_stop()
    pub.disconnect()


def _wait_for(predicate, timeout: float = 8.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if predicate():
            return True
        time.sleep(0.1)
    return False


def test_end_to_end_topic_metrics(broker: int) -> None:
    store = MetricsStore()
    sysm = SysMetrics()
    cfg = MonitorConfig(host="127.0.0.1", port=broker, topics=("test/#",), qos=1)

    with MqttMonitorClient(cfg, store, sysm) as client:
        assert _wait_for(lambda: client.state is ConnectionState.CONNECTED), client.state
        _publish(
            broker,
            [("test/a", b"one"), ("test/a", b"two"), ("test/b", b"three")],
        )
        assert _wait_for(lambda: store.snapshot().total_messages >= 3)

    snap = store.snapshot()
    by_topic = {m.topic: m for m in snap.topics}
    assert by_topic["test/a"].count == 2
    assert by_topic["test/b"].count == 1
    assert by_topic["test/a"].last_payload == b"two"


def test_end_to_end_broker_sys_metrics(broker: int) -> None:
    store = MetricsStore()
    sysm = SysMetrics()
    cfg = MonitorConfig(host="127.0.0.1", port=broker, topics=("nothing/#",),
                        track_broker=True)

    with MqttMonitorClient(cfg, store, sysm):
        # amqtt publishes $SYS/broker/* on its sys_interval (1s here).
        got = _wait_for(lambda: len(sysm) > 0, timeout=8.0)
        assert got, "no $SYS metrics received from broker"

    assert any("broker" not in k or True for k in sysm.raw())  # sanity: has keys
    assert len(sysm) > 0
