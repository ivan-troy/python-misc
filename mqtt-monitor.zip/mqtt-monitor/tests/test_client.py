"""Tests for the MQTT client wrapper (broker-free, via a fake client)."""

from __future__ import annotations

from typing import Any

from mqtt_monitor.client import ConnectionState, MqttMonitorClient
from mqtt_monitor.config import MonitorConfig
from mqtt_monitor.metrics import MetricsStore
from mqtt_monitor.sys_topics import SysMetrics


def _make(config: MonitorConfig, factory: Any, **kw: Any) -> MqttMonitorClient:
    store = MetricsStore()
    sysm = SysMetrics()
    client = MqttMonitorClient(config, store, sysm, client_factory=factory, **kw)
    return client


def test_connect_starts_loop_and_sets_state(
    config: MonitorConfig, fake_client_factory: Any
) -> None:
    client = _make(config, fake_client_factory)
    client.connect()
    fake = fake_client_factory.created[0]
    assert client.state is ConnectionState.CONNECTING
    assert fake.loop_running is True
    assert fake.connect_target == ("broker.test", 1883, config.keepalive)


def test_on_connect_success_subscribes(config: MonitorConfig, fake_client_factory: Any) -> None:
    client = _make(config, fake_client_factory)
    client.connect()
    fake = fake_client_factory.created[0]
    fake.fire_connect(failure=False)
    assert client.state is ConnectionState.CONNECTED
    # Subscribed to user topic + $SYS with the configured QoS.
    topics = {t for t, _ in fake.subscribed}
    assert "sensors/#" in topics
    assert "$SYS/#" in topics
    assert all(q == config.qos for _, q in fake.subscribed)


def test_on_connect_failure_sets_failed(config: MonitorConfig, fake_client_factory: Any) -> None:
    client = _make(config, fake_client_factory)
    client.connect()
    fake = fake_client_factory.created[0]
    fake.fire_connect(failure=True)
    assert client.state is ConnectionState.FAILED
    assert fake.subscribed == []


def test_messages_routed_to_correct_store(config: MonitorConfig, fake_client_factory: Any) -> None:
    store = MetricsStore()
    sysm = SysMetrics()
    client = MqttMonitorClient(config, store, sysm, client_factory=fake_client_factory)
    client.connect()
    fake = fake_client_factory.created[0]

    fake.fire_message("sensors/temp", b"21.5")
    fake.fire_message("$SYS/broker/uptime", b"1234")

    snap = store.snapshot()
    assert snap.total_messages == 1
    assert snap.topics[0].topic == "sensors/temp"
    assert sysm.get("uptime") == "1234"


def test_on_message_hook_invoked(config: MonitorConfig, fake_client_factory: Any) -> None:
    seen: list[tuple[str, bytes]] = []
    client = _make(config, fake_client_factory, on_message_hook=lambda t, p: seen.append((t, p)))
    client.connect()
    fake = fake_client_factory.created[0]
    fake.fire_message("a/b", b"x")
    assert seen == [("a/b", b"x")]


def test_disconnect_stops_loop(config: MonitorConfig, fake_client_factory: Any) -> None:
    client = _make(config, fake_client_factory)
    client.connect()
    fake = fake_client_factory.created[0]
    client.disconnect()
    assert fake.disconnected is True
    assert fake.loop_running is False
    assert client.state is ConnectionState.DISCONNECTED


def test_reconnecting_state_on_disconnect(config: MonitorConfig, fake_client_factory: Any) -> None:
    client = _make(config, fake_client_factory)
    client.connect()
    fake = fake_client_factory.created[0]
    fake.fire_connect()
    fake.fire_disconnect("network down")
    assert client.state is ConnectionState.RECONNECTING


def test_context_manager_connects_and_disconnects(
    config: MonitorConfig, fake_client_factory: Any
) -> None:
    store, sysm = MetricsStore(), SysMetrics()
    with MqttMonitorClient(config, store, sysm, client_factory=fake_client_factory) as client:
        fake = fake_client_factory.created[0]
        assert fake.loop_running is True
        assert client.state is ConnectionState.CONNECTING
    assert fake.disconnected is True
    assert fake.loop_running is False


def test_auth_and_tls_configured(fake_client_factory: Any) -> None:
    cfg = MonitorConfig(username="alice", password="pw", tls=True, tls_insecure=True)
    store, sysm = MetricsStore(), SysMetrics()
    MqttMonitorClient(cfg, store, sysm, client_factory=fake_client_factory)
    fake = fake_client_factory.created[0]
    assert fake.username == "alice"
    assert fake.tls_configured is True
    assert getattr(fake, "tls_insecure", False) is True
