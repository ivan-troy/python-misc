"""Tests for the pure UI render functions.

These render into a headless Rich console and assert on the captured text, so
they exercise the real rendering path without needing a terminal.
"""

from __future__ import annotations

import pytest
from rich.console import Console

from mqtt_monitor.client import ConnectionState
from mqtt_monitor.config import MonitorConfig
from mqtt_monitor.metrics import MetricsStore, RateComputer
from mqtt_monitor.sys_topics import SysMetrics
from mqtt_monitor.themes import get_theme
from mqtt_monitor.ui import (
    build_dashboard,
    human_count,
    human_rate,
    payload_preview,
    render_broker_panel,
    render_browse_table,
    render_header,
    render_payload_full,
    render_topics_table,
)


def _render(renderable: object, width: int = 100) -> str:
    console = Console(
        theme=get_theme("nord").rich_theme(), width=width, force_terminal=False
    )
    with console.capture() as cap:
        console.print(renderable)
    return cap.get()


@pytest.mark.parametrize(
    ("n", "expected"),
    [(5, "5"), (999, "999"), (1000, "1.0K"), (1_500_000, "1.5M")],
)
def test_human_count(n: int, expected: str) -> None:
    assert human_count(n) == expected


@pytest.mark.parametrize(
    ("rate", "expected"),
    [(0, "—"), (0.25, "0.25/s"), (12.5, "12.5/s"), (250, "250/s"), (1500, "1.5K/s")],
)
def test_human_rate(rate: float, expected: str) -> None:
    assert human_rate(rate) == expected


def test_payload_preview_collapses_and_truncates() -> None:
    assert payload_preview(b"hello   world\n\n") == "hello world"
    long = payload_preview(b"x" * 500, max_len=10)
    assert len(long) == 10
    assert long.endswith("…")


def test_payload_preview_empty() -> None:
    assert payload_preview(b"") == "∅"


def test_payload_preview_binary_safe() -> None:
    # Invalid UTF-8 must not raise.
    out = payload_preview(b"\xff\xfe\x00abc")
    assert isinstance(out, str)


def test_render_payload_full_pretty_prints_json() -> None:
    out = _render(render_payload_full(b'{"a": 1, "b": [1,2]}'))
    assert '"a"' in out and '"b"' in out


def test_render_payload_full_plain_text() -> None:
    out = _render(render_payload_full(b"just text"))
    assert "just text" in out


def test_render_header_shows_status_and_counts() -> None:
    store = MetricsStore()
    store.record("t", b"12345")
    snap = store.snapshot()
    header = render_header(
        MonitorConfig(host="h", port=1883), ConnectionState.CONNECTED, "", snap,
        get_theme("nord"),
    )
    out = _render(header)
    assert "CONNECTED" in out
    assert "h:1883" in out
    assert "mqtt-monitor" in out


def test_render_broker_panel_waiting_and_populated() -> None:
    sysm = SysMetrics()
    assert "waiting" in _render(render_broker_panel(sysm, get_theme("nord")))
    sysm.update("$SYS/broker/uptime", b"3661")
    out = _render(render_broker_panel(sysm, get_theme("nord")))
    assert "Uptime" in out
    assert "01:01:01" in out


def test_render_topics_table_lists_and_limits() -> None:
    store = MetricsStore()
    for i in range(30):
        store.record(f"topic/{i}", b"payloaddata")
    snap = store.snapshot()
    rates = RateComputer().update(snap)
    cfg = MonitorConfig(top_n=5)
    out = _render(render_topics_table(snap, rates, cfg, get_theme("nord")), width=120)
    assert "topic/" in out
    assert "more" in out  # indicates hidden rows beyond top_n


def test_render_topics_table_empty_state() -> None:
    snap = MetricsStore().snapshot()
    out = _render(render_topics_table(snap, {}, MonitorConfig(), get_theme("nord")))
    assert "no messages yet" in out


def test_build_dashboard_with_and_without_broker() -> None:
    store = MetricsStore()
    store.record("sensors/a", b"1")
    snap = store.snapshot()
    sysm = SysMetrics()
    theme = get_theme("minimal")

    full = _render(
        build_dashboard(
            MonitorConfig(track_broker=True), ConnectionState.CONNECTED, "", snap,
            {}, sysm, theme,
        ),
        width=120,
    )
    assert "broker ($SYS)" in full
    assert "sensors/a" in full

    topics_only = _render(
        build_dashboard(
            MonitorConfig(track_broker=False), ConnectionState.CONNECTED, "", snap,
            {}, sysm, theme, interactive=False,
        ),
        width=120,
    )
    assert "broker ($SYS)" not in topics_only
    assert "Ctrl-C to quit" in topics_only


def test_render_browse_table() -> None:
    store = MetricsStore()
    store.record("s/1", b'{"v": 1}')
    store.record("s/1", b'{"v": 2}')
    records = list(store.history("s/1"))
    out = _render(render_browse_table("s/1", records, get_theme("slate")), width=100)
    assert "browse" in out
    assert "s/1" in out


def test_all_themes_render_without_error() -> None:
    from mqtt_monitor.themes import theme_names

    store = MetricsStore()
    store.record("a/b", b"data")
    snap = store.snapshot()
    for name in theme_names():
        theme = get_theme(name)
        console = Console(theme=theme.rich_theme(), width=120)
        with console.capture():
            console.print(
                build_dashboard(
                    MonitorConfig(), ConnectionState.CONNECTED, "", snap, {},
                    SysMetrics(), theme,
                )
            )
