"""Tests for the configuration value object."""

from __future__ import annotations

import pytest

from mqtt_monitor.config import (
    DEFAULT_TOPIC,
    SYS_WILDCARD,
    MonitorConfig,
    SortKey,
    Transport,
)


def test_defaults_are_sensible() -> None:
    cfg = MonitorConfig()
    assert cfg.host == "localhost"
    assert cfg.port == 1883
    assert cfg.topics == (DEFAULT_TOPIC,)
    assert cfg.client_id.startswith("mqtt-monitor-")
    assert cfg.transport is Transport.TCP


def test_client_ids_are_unique() -> None:
    assert MonitorConfig().client_id != MonitorConfig().client_id


@pytest.mark.parametrize("qos", [-1, 3, 99])
def test_invalid_qos_rejected(qos: int) -> None:
    with pytest.raises(ValueError, match="qos"):
        MonitorConfig(qos=qos)


@pytest.mark.parametrize("port", [0, -5, 70000])
def test_invalid_port_rejected(port: int) -> None:
    with pytest.raises(ValueError, match="port"):
        MonitorConfig(port=port)


def test_zero_refresh_rejected() -> None:
    with pytest.raises(ValueError, match="refresh"):
        MonitorConfig(refresh_hz=0)


def test_empty_topics_rejected() -> None:
    with pytest.raises(ValueError, match="topic"):
        MonitorConfig(topics=())


def test_subscriptions_add_sys_when_tracking_broker() -> None:
    cfg = MonitorConfig(topics=("a/#",), track_broker=True)
    assert SYS_WILDCARD in cfg.subscriptions
    assert "a/#" in cfg.subscriptions


def test_subscriptions_omit_sys_when_not_tracking() -> None:
    cfg = MonitorConfig(topics=("a/#",), track_broker=False)
    assert SYS_WILDCARD not in cfg.subscriptions


def test_subscriptions_do_not_duplicate_sys() -> None:
    cfg = MonitorConfig(topics=(SYS_WILDCARD,), track_broker=True)
    assert cfg.subscriptions.count(SYS_WILDCARD) == 1


def test_address_property() -> None:
    assert MonitorConfig(host="h", port=8883).address == "h:8883"


def test_immutability_and_helpers() -> None:
    cfg = MonitorConfig(theme="nord", sort_key=SortKey.RATE)
    themed = cfg.with_theme("dracula")
    sorted_cfg = cfg.with_sort_key(SortKey.BYTES)
    assert cfg.theme == "nord"  # original untouched
    assert themed.theme == "dracula"
    assert sorted_cfg.sort_key is SortKey.BYTES
    with pytest.raises((AttributeError, TypeError)):
        cfg.host = "other"  # type: ignore[misc]
