"""CLI tests using Typer's runner; live loops are monkeypatched out."""

from __future__ import annotations

from typing import Any

import pytest
from typer.testing import CliRunner

import mqtt_monitor.app as app_module
from mqtt_monitor.cli import app
from mqtt_monitor.config import MonitorConfig, SortKey

runner = CliRunner()


def test_version_command() -> None:
    result = runner.invoke(app, ["version"])
    assert result.exit_code == 0
    assert "mqtt-monitor" in result.stdout


def test_themes_command_lists_all() -> None:
    result = runner.invoke(app, ["themes"])
    assert result.exit_code == 0
    for name in ("nord", "minimal", "dracula", "matrix"):
        assert name in result.stdout


def test_dashboard_builds_expected_config(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}

    def fake_run(cfg: MonitorConfig) -> None:
        captured["cfg"] = cfg

    monkeypatch.setattr(app_module, "run_dashboard", fake_run)
    result = runner.invoke(
        app,
        ["dashboard", "--host", "example.org", "--port", "8883",
         "--topic", "a/#", "--topic", "b/#", "--sort", "bytes", "--theme", "slate"],
    )
    assert result.exit_code == 0, result.stdout
    cfg = captured["cfg"]
    assert cfg.host == "example.org"
    assert cfg.port == 8883
    assert cfg.topics == ("a/#", "b/#")
    assert cfg.sort_key is SortKey.BYTES
    assert cfg.theme == "slate"


def test_topics_command_disables_broker(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}
    monkeypatch.setattr(app_module, "run_dashboard", lambda cfg: captured.update(cfg=cfg))
    result = runner.invoke(app, ["topics", "--host", "h"])
    assert result.exit_code == 0
    assert captured["cfg"].track_broker is False


def test_browse_passes_topic(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}

    def fake_browse(cfg: MonitorConfig, topic: str) -> None:
        captured["cfg"] = cfg
        captured["topic"] = topic

    monkeypatch.setattr(app_module, "run_browse", fake_browse)
    result = runner.invoke(app, ["browse", "sensors/+/temp", "--host", "h"])
    assert result.exit_code == 0
    assert captured["topic"] == "sensors/+/temp"
    assert captured["cfg"].topics == ("sensors/+/temp",)


def test_bad_theme_is_rejected(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(app_module, "run_dashboard", lambda cfg: None)
    result = runner.invoke(app, ["dashboard", "--theme", "no-such-theme"])
    assert result.exit_code != 0
    assert "unknown theme" in result.stdout


def test_invalid_qos_is_rejected() -> None:
    result = runner.invoke(app, ["dashboard", "--qos", "5"])
    assert result.exit_code != 0


def test_password_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}
    monkeypatch.setattr(app_module, "run_dashboard", lambda cfg: captured.update(cfg=cfg))
    monkeypatch.setenv("MQTT_PASSWORD", "from-env")
    result = runner.invoke(app, ["dashboard", "--username", "u"])
    assert result.exit_code == 0
    assert captured["cfg"].password == "from-env"


def test_no_args_shows_help() -> None:
    result = runner.invoke(app, [])
    # no_args_is_help => usage shown, non-zero exit by Typer convention
    assert "Usage" in result.stdout
