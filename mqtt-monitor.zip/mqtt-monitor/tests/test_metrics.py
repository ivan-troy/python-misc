"""Tests for the metrics engine."""

from __future__ import annotations

import threading

import pytest

from mqtt_monitor.metrics import (
    MetricsStore,
    RateComputer,
    TopicMetric,
    sort_metrics,
)


class FakeClock:
    """Deterministic monotonic-ish clock for rate tests."""

    def __init__(self, start: float = 1000.0) -> None:
        self.t = start

    def __call__(self) -> float:
        return self.t

    def advance(self, dt: float) -> None:
        self.t += dt


def test_record_and_snapshot_counts() -> None:
    store = MetricsStore()
    store.record("a/b", b"hello")
    store.record("a/b", b"world!")
    store.record("a/c", b"x")

    snap = store.snapshot()
    assert snap.total_messages == 3
    assert snap.total_bytes == len(b"hello") + len(b"world!") + 1
    assert snap.topic_count == 2

    by_topic = {m.topic: m for m in snap.topics}
    assert by_topic["a/b"].count == 2
    assert by_topic["a/b"].bytes_total == 11
    assert by_topic["a/b"].last_payload == b"world!"
    assert by_topic["a/c"].count == 1


def test_snapshot_is_immutable_view() -> None:
    store = MetricsStore()
    store.record("t", b"1")
    snap = store.snapshot()
    store.record("t", b"2")  # mutate after snapshot
    # Old snapshot must not change.
    assert snap.topics[0].count == 1
    assert store.snapshot().topics[0].count == 2


def test_reset_clears_everything() -> None:
    store = MetricsStore()
    store.record("t", b"1")
    store.reset()
    snap = store.snapshot()
    assert snap.total_messages == 0
    assert snap.topic_count == 0


def test_history_is_bounded() -> None:
    store = MetricsStore(history_size=3)
    for i in range(10):
        store.record("t", str(i).encode())
    hist = store.history("t")
    assert len(hist) == 3
    assert [r.payload for r in hist] == [b"7", b"8", b"9"]


def test_history_unknown_topic_empty() -> None:
    assert MetricsStore().history("nope") == ()


def test_topic_metric_derived_properties() -> None:
    m = TopicMetric(
        topic="t", count=4, bytes_total=40,
        first_seen=100.0, last_seen=103.0, last_payload=b"z",
    )
    assert m.avg_size == 10.0
    # lifetime_rate uses (count-1)/span => 3/3 == 1.0
    assert m.lifetime_rate == pytest.approx(1.0)


def test_topic_metric_rate_zero_span() -> None:
    m = TopicMetric("t", 1, 5, 100.0, 100.0, b"x")
    assert m.lifetime_rate == 0.0
    assert m.avg_size == 5.0


def test_store_overall_rate_uses_clock() -> None:
    clock = FakeClock()
    store = MetricsStore(clock=clock)
    store.record("t", b"12345")
    clock.advance(2.0)
    snap = store.snapshot()
    assert snap.elapsed == pytest.approx(2.0)
    assert snap.overall_rate == pytest.approx(0.5)
    assert snap.overall_byte_rate == pytest.approx(2.5)


def test_rate_computer_between_snapshots() -> None:
    clock = FakeClock()
    store = MetricsStore(clock=clock)
    rc = RateComputer()

    store.record("t", b"a")
    rc.update(store.snapshot())  # first sample => baseline, no rate yet

    clock.advance(1.0)
    store.record("t", b"b")
    store.record("t", b"c")
    rates = rc.update(store.snapshot())
    # +2 messages over 1s
    assert rates["t"].msg_rate == pytest.approx(2.0)
    assert rates["t"].byte_rate == pytest.approx(2.0)


def test_rate_computer_first_update_is_zero() -> None:
    store = MetricsStore()
    store.record("t", b"x")
    rates = RateComputer().update(store.snapshot())
    assert rates["t"].msg_rate == 0.0


def _metric(topic: str, count: int, byts: int, last: float) -> TopicMetric:
    return TopicMetric(topic, count, byts, 0.0, last, b"")


def test_sort_metrics_by_count_and_bytes_and_topic() -> None:
    ms = [
        _metric("b", count=1, byts=100, last=5.0),
        _metric("a", count=9, byts=10, last=1.0),
        _metric("c", count=3, byts=50, last=9.0),
    ]
    assert [m.topic for m in sort_metrics(ms, "count")] == ["a", "c", "b"]
    assert [m.topic for m in sort_metrics(ms, "bytes")] == ["b", "c", "a"]
    assert [m.topic for m in sort_metrics(ms, "topic")] == ["a", "b", "c"]
    assert [m.topic for m in sort_metrics(ms, "last")] == ["c", "b", "a"]


def test_sort_metrics_by_rate_prefers_live_rates() -> None:
    from mqtt_monitor.metrics import TopicRate

    ms = [_metric("slow", 100, 0, 1.0), _metric("fast", 2, 0, 1.0)]
    rates = {
        "slow": TopicRate("slow", 0.1, 0.0),
        "fast": TopicRate("fast", 99.0, 0.0),
    }
    assert [m.topic for m in sort_metrics(ms, "rate", rates)] == ["fast", "slow"]


def test_sort_metrics_unknown_key_raises() -> None:
    with pytest.raises(ValueError, match="unknown sort key"):
        sort_metrics([], "nonsense")


def test_thread_safety_under_concurrent_writers() -> None:
    store = MetricsStore()
    n_threads, per_thread = 8, 2000

    def worker() -> None:
        for _ in range(per_thread):
            store.record("shared", b"x")

    threads = [threading.Thread(target=worker) for _ in range(n_threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    snap = store.snapshot()
    assert snap.total_messages == n_threads * per_thread
    assert snap.topics[0].count == n_threads * per_thread
