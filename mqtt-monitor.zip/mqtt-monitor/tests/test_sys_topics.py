"""Tests for $SYS parsing and formatting helpers."""

from __future__ import annotations

import pytest

from mqtt_monitor.sys_topics import (
    SysMetrics,
    format_bytes,
    format_duration,
)


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        (0, "0 B"),
        (512, "512 B"),
        (1024, "1.0 KiB"),
        (1536, "1.5 KiB"),
        (1024 * 1024, "1.0 MiB"),
        (5 * 1024**3, "5.0 GiB"),
    ],
)
def test_format_bytes(value: int, expected: str) -> None:
    assert format_bytes(value) == expected


@pytest.mark.parametrize(
    ("seconds", "expected"),
    [
        (0, "00:00:00"),
        (65, "00:01:05"),
        (3661, "01:01:01"),
        (90000, "1d 01:00:00"),
    ],
)
def test_format_duration(seconds: int, expected: str) -> None:
    assert format_duration(seconds) == expected


def test_is_sys_topic() -> None:
    assert SysMetrics.is_sys_topic("$SYS/broker/uptime")
    assert not SysMetrics.is_sys_topic("sensors/temp")


def test_update_ignores_non_sys() -> None:
    s = SysMetrics()
    s.update("sensors/x", b"1")
    assert len(s) == 0


def test_update_and_get() -> None:
    s = SysMetrics()
    s.update("$SYS/broker/clients/connected", b"42")
    assert s.get("clients/connected") == "42"
    assert len(s) == 1


def test_friendly_rows_formats_known_fields() -> None:
    s = SysMetrics()
    s.update("$SYS/broker/uptime", b"3661 seconds")
    s.update("$SYS/broker/clients/connected", b"7")
    s.update("$SYS/broker/bytes/received", b"2048")
    rows = dict(s.friendly_rows())
    assert rows["Uptime"] == "01:01:01"
    assert rows["Clients connected"] == "7"
    assert rows["Bytes received"] == "2.0 KiB"


def test_friendly_rows_ordering_known_before_unknown() -> None:
    s = SysMetrics()
    s.update("$SYS/broker/custom/thing", b"hello")   # unknown
    s.update("$SYS/broker/uptime", b"10")            # known, should come first
    labels = [label for label, _ in s.friendly_rows()]
    assert labels[0] == "Uptime"
    assert "custom/thing" in labels


def test_friendly_rows_preserves_unknown_values() -> None:
    s = SysMetrics()
    s.update("$SYS/broker/version", b"mosquitto 2.0.18")
    rows = dict(s.friendly_rows())
    assert rows["Broker version"] == "mosquitto 2.0.18"


def test_bad_numeric_values_fall_back_gracefully() -> None:
    s = SysMetrics()
    s.update("$SYS/broker/bytes/received", b"not-a-number")
    rows = dict(s.friendly_rows())
    assert rows["Bytes received"] == "not-a-number"
