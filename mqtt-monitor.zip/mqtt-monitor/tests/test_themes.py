"""Tests for the theme system."""

from __future__ import annotations

import pytest
from rich.theme import Theme

from mqtt_monitor.themes import (
    _STYLE_KEYS,
    DEFAULT_THEME,
    all_themes,
    get_theme,
    next_theme,
    theme_names,
)


def test_default_theme_exists() -> None:
    assert DEFAULT_THEME in theme_names()


def test_every_theme_defines_all_semantic_styles() -> None:
    for theme in all_themes():
        for key in _STYLE_KEYS:
            assert key in theme.styles, f"{theme.name} missing {key}"


def test_every_theme_builds_a_rich_theme() -> None:
    for theme in all_themes():
        assert isinstance(theme.rich_theme(), Theme)


def test_get_unknown_theme_lists_options() -> None:
    with pytest.raises(KeyError) as exc:
        get_theme("does-not-exist")
    # Message should help the user by listing valid names.
    assert "nord" in str(exc.value)


def test_next_theme_cycles_and_wraps() -> None:
    names = theme_names()
    first = names[0]
    seen = [first]
    cur = first
    for _ in range(len(names)):
        cur = next_theme(cur)
        seen.append(cur)
    # After len(names) steps we should be back to the start.
    assert seen[-1] == first
    assert set(seen[:-1]) == set(names)


def test_next_theme_from_unknown_returns_first() -> None:
    assert next_theme("bogus") == theme_names()[0]


def test_minimal_themes_present() -> None:
    names = theme_names()
    assert "minimal" in names
    assert "mono-light" in names
