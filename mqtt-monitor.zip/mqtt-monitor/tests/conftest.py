"""Shared fixtures and a fake paho client for broker-free unit tests."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pytest

from mqtt_monitor.config import MonitorConfig


@dataclass
class FakeReasonCode:
    """Stand-in for paho's ReasonCode with the attribute we check."""

    is_failure: bool = False

    def __str__(self) -> str:  # pragma: no cover - cosmetic
        return "Failure" if self.is_failure else "Success"


@dataclass
class FakeMessage:
    """Stand-in for paho.mqtt.client.MQTTMessage."""

    topic: str
    payload: bytes


class FakeMqttClient:
    """Records calls and lets tests drive the paho callbacks directly.

    Constructed the same way our wrapper constructs the real client, so it can
    be injected via ``client_factory``.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self.init_args = args
        self.init_kwargs = kwargs
        self.subscribed: list[tuple[str, int]] = []
        self.connected = False
        self.loop_running = False
        self.disconnected = False
        self.username: str | None = None
        self.tls_configured = False
        # Callback slots (assigned by the wrapper)
        self.on_connect: Any = None
        self.on_disconnect: Any = None
        self.on_message: Any = None
        self.on_connect_fail: Any = None

    # --- paho API surface used by the wrapper --------------------------- #
    def username_pw_set(self, username: str, password: str | None = None) -> None:
        self.username = username

    def tls_set(self, *args: Any, **kwargs: Any) -> None:
        self.tls_configured = True

    def tls_insecure_set(self, value: bool) -> None:
        self.tls_insecure = value

    def reconnect_delay_set(self, **kwargs: Any) -> None:
        self.reconnect_delay = kwargs

    def connect_async(self, host: str, port: int, keepalive: int = 60) -> None:
        self.connect_target = (host, port, keepalive)

    def loop_start(self) -> None:
        self.loop_running = True

    def loop_stop(self) -> None:
        self.loop_running = False

    def disconnect(self) -> None:
        self.disconnected = True

    def subscribe(self, subs: list[tuple[str, int]]) -> None:
        self.subscribed.extend(subs)

    # --- test helpers to fire callbacks --------------------------------- #
    def fire_connect(self, *, failure: bool = False) -> None:
        self.on_connect(self, None, {}, FakeReasonCode(is_failure=failure), None)

    def fire_message(self, topic: str, payload: bytes) -> None:
        self.on_message(self, None, FakeMessage(topic, payload))

    def fire_disconnect(self, reason: str = "network") -> None:
        self.on_disconnect(self, None, {}, reason, None)


@pytest.fixture
def fake_client_factory() -> Any:
    created: list[FakeMqttClient] = []

    def factory(*args: Any, **kwargs: Any) -> FakeMqttClient:
        c = FakeMqttClient(*args, **kwargs)
        created.append(c)
        return c

    factory.created = created  # type: ignore[attr-defined]
    return factory


@pytest.fixture
def config() -> MonitorConfig:
    return MonitorConfig(host="broker.test", port=1883, topics=("sensors/#",), qos=1)
