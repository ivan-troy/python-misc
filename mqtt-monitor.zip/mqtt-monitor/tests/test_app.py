"""Tests for the live-loop drivers.

The loops run ``while True`` around Rich's ``Live``; we make them run a bounded
number of frames by injecting a fake keyboard that eventually returns ``q`` and
fake ``Live``/client objects, so the real loop body (key handling, theme/sort
switching, reset, render composition) is exercised without a terminal or broker.
"""

from __future__ import annotations

from typing import Any

import pytest

import mqtt_monitor.app as app_module
from mqtt_monitor.app import _handle_key, _next_sort, run_broker, run_browse, run_dashboard
from mqtt_monitor.client import ConnectionState
from mqtt_monitor.config import MonitorConfig, SortKey


def test_handle_key_mapping() -> None:
    assert _handle_key("q") == "quit"
    assert _handle_key(" ") == "pause"
    assert _handle_key("p") == "pause"
    assert _handle_key("R") == "reset"
    assert _handle_key("t") == "theme"
    assert _handle_key("s") == "sort"
    assert _handle_key("z") is None


def test_next_sort_cycles() -> None:
    order = list(SortKey)
    cur = order[0]
    seen = {cur}
    for _ in range(len(order)):
        cur = _next_sort(cur)
        seen.add(cur)
    assert seen == set(order)


class _FakeStatus:
    def get(self) -> tuple[ConnectionState, str]:
        return ConnectionState.CONNECTED, ""


class _FakeClient:
    """Drop-in for MqttMonitorClient: context manager + status only."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self.status = _FakeStatus()

    def __enter__(self) -> _FakeClient:
        return self

    def __exit__(self, *exc: object) -> None:
        return None


class _FakeLive:
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self.updates: list[object] = []

    def __enter__(self) -> _FakeLive:
        return self

    def __exit__(self, *exc: object) -> None:
        return None

    def update(self, renderable: object, refresh: bool = False) -> None:
        self.updates.append(renderable)


class _FakeKeys:
    """Yields a scripted sequence of keypresses, then quits."""

    def __init__(self, script: list[str | None]) -> None:
        self._script = list(script)
        self.enabled = True

    def __enter__(self) -> _FakeKeys:
        return self

    def __exit__(self, *exc: object) -> None:
        return None

    def get(self) -> str | None:
        return self._script.pop(0) if self._script else "q"


@pytest.fixture
def patch_runtime(monkeypatch: pytest.MonkeyPatch) -> list[_FakeLive]:
    lives: list[_FakeLive] = []

    def live_factory(*a: Any, **k: Any) -> _FakeLive:
        live = _FakeLive()
        lives.append(live)
        return live

    monkeypatch.setattr(app_module, "MqttMonitorClient", _FakeClient)
    monkeypatch.setattr(app_module, "Live", live_factory)
    monkeypatch.setattr(app_module.time, "sleep", lambda _s: None)
    return lives


def test_run_dashboard_exercises_all_actions(
    patch_runtime: list[_FakeLive], monkeypatch: pytest.MonkeyPatch
) -> None:
    # theme, sort, reset, pause, a plain render, then quit.
    keys = _FakeKeys(["t", "s", "r", "p", None, "q"])
    monkeypatch.setattr(app_module, "KeyboardListener", lambda: keys)

    run_dashboard(MonitorConfig(theme="nord", track_broker=True))

    # At least the two non-key-consuming frames rendered ('p' toggles then
    # 'None' renders); ensure the loop produced output and returned cleanly.
    assert patch_runtime[0].updates, "dashboard produced no frames"


def test_run_dashboard_non_interactive(
    patch_runtime: list[_FakeLive], monkeypatch: pytest.MonkeyPatch
) -> None:
    keys = _FakeKeys([None, "q"])
    keys.enabled = False  # simulate piped stdin
    monkeypatch.setattr(app_module, "KeyboardListener", lambda: keys)
    run_dashboard(MonitorConfig(track_broker=False))
    assert patch_runtime[0].updates


def test_run_browse_single_frame(
    patch_runtime: list[_FakeLive], monkeypatch: pytest.MonkeyPatch
) -> None:
    # Break out of the infinite loop after the first sleep.
    calls = {"n": 0}

    def stop_after_one(_s: float) -> None:
        calls["n"] += 1
        raise KeyboardInterrupt

    monkeypatch.setattr(app_module.time, "sleep", stop_after_one)
    with pytest.raises(KeyboardInterrupt):
        run_browse(MonitorConfig(), "sensors/#")
    assert patch_runtime[0].updates


def test_run_broker_single_frame(
    patch_runtime: list[_FakeLive], monkeypatch: pytest.MonkeyPatch
) -> None:
    def stop_after_one(_s: float) -> None:
        raise KeyboardInterrupt

    monkeypatch.setattr(app_module.time, "sleep", stop_after_one)
    with pytest.raises(KeyboardInterrupt):
        run_broker(MonitorConfig())
    assert patch_runtime[0].updates
