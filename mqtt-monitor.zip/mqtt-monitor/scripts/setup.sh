#!/usr/bin/env bash
# Create the virtualenv and install the project with dev extras.
set -euo pipefail
cd "$(dirname "$0")/.."
uv venv
uv pip install -e ".[dev]"
echo "✓ environment ready — activate with 'source .venv/bin/activate' or use 'uv run ...'"
