#!/usr/bin/env bash
# Run the dashboard (defaults to localhost:1883). Extra args pass through.
set -euo pipefail
cd "$(dirname "$0")/.."
uv run mqtt-monitor dashboard "$@"
