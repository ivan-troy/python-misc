#!/usr/bin/env bash
# Lint, type-check, and run the test suite with coverage.
set -euo pipefail
cd "$(dirname "$0")/.."
echo "== ruff =="
uv run ruff check .
echo "== mypy =="
uv run mypy
echo "== pytest =="
uv run pytest --cov=mqtt_monitor --cov-report=term-missing "$@"
