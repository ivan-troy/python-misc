#!/usr/bin/env python
"""Publish synthetic sensor traffic so you can see the dashboard in action.

    uv run python scripts/demo_publisher.py --host localhost

Generates a mix of topics at different rates and payload sizes, so the sorting
and rate columns have something interesting to show.
"""

from __future__ import annotations

import argparse
import json
import random
import time

import paho.mqtt.client as mqtt
from paho.mqtt.enums import CallbackAPIVersion

SENSORS = [
    ("sensors/livingroom/temperature", 2.0, "temp"),
    ("sensors/livingroom/humidity", 1.0, "humidity"),
    ("sensors/kitchen/temperature", 0.5, "temp"),
    ("sensors/garden/soil", 0.2, "soil"),
    ("devices/thermostat/state", 0.3, "state"),
    ("logs/app/events", 8.0, "log"),
    ("telemetry/gps/position", 4.0, "gps"),
]


def make_payload(kind: str) -> bytes:
    now = time.time()
    if kind == "temp":
        body = {"ts": now, "c": round(random.uniform(18, 26), 2)}
    elif kind == "humidity":
        body = {"ts": now, "rh": round(random.uniform(30, 70), 1)}
    elif kind == "soil":
        body = {"ts": now, "moisture": random.randint(0, 100)}
    elif kind == "gps":
        body = {"ts": now, "lat": round(random.uniform(-90, 90), 5),
                "lon": round(random.uniform(-180, 180), 5)}
    elif kind == "state":
        body = {"ts": now, "on": random.choice([True, False]), "set": 21}
    else:
        body = {"ts": now, "level": random.choice(["INFO", "WARN", "ERROR"]),
                "msg": "x" * random.randint(10, 120)}
    return json.dumps(body).encode()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=1883)
    parser.add_argument("--duration", type=float, default=0, help="seconds (0 = forever)")
    args = parser.parse_args()

    client = mqtt.Client(CallbackAPIVersion.VERSION2, client_id="demo-publisher")
    client.connect(args.host, args.port)
    client.loop_start()
    print(f"publishing demo traffic to {args.host}:{args.port} (Ctrl-C to stop)")

    next_due = {topic: 0.0 for topic, _, _ in SENSORS}
    start = time.time()
    try:
        while True:
            now = time.time()
            for topic, hz, kind in SENSORS:
                if now >= next_due[topic]:
                    client.publish(topic, make_payload(kind), qos=0)
                    # jitter the interval a little for realism
                    next_due[topic] = now + (1.0 / hz) * random.uniform(0.7, 1.3)
            if args.duration and (now - start) >= args.duration:
                break
            time.sleep(0.02)
    except KeyboardInterrupt:
        pass
    finally:
        client.loop_stop()
        client.disconnect()
        print("\npublisher stopped")


if __name__ == "__main__":
    main()
