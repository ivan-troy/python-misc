#!/usr/bin/env python
"""Run a pure-Python MQTT broker (amqtt) for local demos and tests.

    uv run python scripts/local_broker.py [--port 1883]

Publishes $SYS statistics every 5s so the broker view has data to show.
Requires the dev extras (``amqtt``).
"""

from __future__ import annotations

import argparse
import asyncio
import logging


def build_config(port: int) -> dict:
    return {
        "listeners": {
            "default": {"type": "tcp", "bind": f"0.0.0.0:{port}", "max-connections": 500},
        },
        "sys_interval": 5,  # publish $SYS/broker/* every 5 seconds
        "auth": {"allow-anonymous": True, "plugins": ["auth_anonymous"]},
        "topic-check": {"enabled": False},
    }


async def _serve(port: int) -> None:
    from amqtt.broker import Broker

    broker = Broker(build_config(port))
    await broker.start()
    print(f"amqtt broker listening on tcp://0.0.0.0:{port} (Ctrl-C to stop)")
    try:
        await asyncio.Event().wait()  # run forever
    finally:
        await broker.shutdown()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=1883)
    parser.add_argument("--quiet", action="store_true", help="silence amqtt logs")
    args = parser.parse_args()
    logging.basicConfig(level=logging.WARNING if args.quiet else logging.INFO)
    try:
        asyncio.run(_serve(args.port))
    except KeyboardInterrupt:
        print("\nbroker stopped")


if __name__ == "__main__":
    main()
