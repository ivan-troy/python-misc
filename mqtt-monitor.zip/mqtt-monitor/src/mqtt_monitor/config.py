"""Immutable configuration objects for a monitoring session.

Keeping configuration in a frozen dataclass (rather than threading a dozen
keyword arguments through every layer) makes the code easier to test and
reason about: a session is fully described by one value object.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field, replace
from enum import Enum


class Transport(str, Enum):
    """MQTT transport layer."""

    TCP = "tcp"
    WEBSOCKETS = "websockets"


class SortKey(str, Enum):
    """How the per-topic table is ordered."""

    RATE = "rate"          # messages/second (windowed)
    COUNT = "count"        # total messages
    BYTES = "bytes"        # total bytes
    TOPIC = "topic"        # alphabetical
    LAST = "last"          # most recently seen first


# The $SYS wildcard is treated specially by brokers and is *not* covered by '#',
# so it must be subscribed to explicitly when broker stats are wanted.
SYS_WILDCARD = "$SYS/#"
DEFAULT_TOPIC = "#"


@dataclass(frozen=True, slots=True)
class MonitorConfig:
    """A fully-resolved description of a monitoring session."""

    host: str = "localhost"
    port: int = 1883
    topics: tuple[str, ...] = (DEFAULT_TOPIC,)
    qos: int = 0
    username: str | None = None
    password: str | None = None
    client_id: str = field(default_factory=lambda: f"mqtt-monitor-{uuid.uuid4().hex[:8]}")
    transport: Transport = Transport.TCP
    keepalive: int = 60
    tls: bool = False
    tls_insecure: bool = False
    ca_certs: str | None = None
    # Behaviour
    track_broker: bool = True     # subscribe to $SYS/# for broker stats
    refresh_hz: float = 4.0       # UI refresh rate
    max_payload_preview: int = 120
    payload_history: int = 200    # messages kept per topic for the browser
    top_n: int = 20               # rows shown in the topics table
    theme: str = "nord"
    sort_key: SortKey = SortKey.RATE

    def __post_init__(self) -> None:
        if not 0 <= self.qos <= 2:
            raise ValueError(f"qos must be 0, 1 or 2, got {self.qos!r}")
        if not 1 <= self.port <= 65535:
            raise ValueError(f"port must be in 1..65535, got {self.port!r}")
        if self.refresh_hz <= 0:
            raise ValueError("refresh_hz must be positive")
        if not self.topics:
            raise ValueError("at least one topic is required")

    @property
    def subscriptions(self) -> tuple[str, ...]:
        """All topic filters to subscribe to, including $SYS when enabled."""
        subs = list(self.topics)
        if self.track_broker and SYS_WILDCARD not in subs:
            subs.append(SYS_WILDCARD)
        return tuple(subs)

    @property
    def address(self) -> str:
        return f"{self.host}:{self.port}"

    def with_theme(self, theme: str) -> MonitorConfig:
        """Return a copy with a different theme (configs are immutable)."""
        return replace(self, theme=theme)

    def with_sort_key(self, sort_key: SortKey) -> MonitorConfig:
        return replace(self, sort_key=sort_key)
