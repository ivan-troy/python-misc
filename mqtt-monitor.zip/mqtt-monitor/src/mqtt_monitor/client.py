"""A thin, well-behaved wrapper around paho-mqtt 2.x.

Responsibilities
----------------
* Own a single :class:`paho.mqtt.client.Client` configured with the modern
  ``CallbackAPIVersion.VERSION2`` API.
* Route inbound messages to the right store (``$SYS`` -> broker stats, else
  the per-topic metrics store).
* Expose connection state and lifecycle as a context manager so callers never
  leak the background network thread.

The wrapper deliberately holds no rendering logic — it just fills the stores.
"""

from __future__ import annotations

import threading
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Any, Literal

import paho.mqtt.client as mqtt
from paho.mqtt.enums import CallbackAPIVersion

from mqtt_monitor.config import MonitorConfig, Transport
from mqtt_monitor.metrics import MetricsStore
from mqtt_monitor.sys_topics import SysMetrics

if TYPE_CHECKING:
    from types import TracebackType


class ConnectionState(str, Enum):
    INITIAL = "initial"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"
    DISCONNECTED = "disconnected"
    FAILED = "failed"


@dataclass
class ConnectionStatus:
    """Mutable, lock-protected connection status shared with the UI."""

    state: ConnectionState = ConnectionState.INITIAL
    detail: str = ""
    _lock: threading.Lock = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        self._lock = threading.Lock()

    def set(self, state: ConnectionState, detail: str = "") -> None:
        with self._lock:
            self.state = state
            self.detail = detail

    def get(self) -> tuple[ConnectionState, str]:
        with self._lock:
            return self.state, self.detail


class MqttMonitorClient:
    """Connects to a broker and feeds the metric stores.

    Example
    -------
    >>> with MqttMonitorClient(config, store, sys_metrics) as client:  # doctest: +SKIP
    ...     time.sleep(5)  # background thread fills the stores
    """

    def __init__(
        self,
        config: MonitorConfig,
        store: MetricsStore,
        sys_metrics: SysMetrics | None = None,
        *,
        on_message_hook: Callable[[str, bytes], None] | None = None,
        client_factory: Callable[..., mqtt.Client] | None = None,
    ) -> None:
        self.config = config
        self.store = store
        self.sys_metrics = sys_metrics if sys_metrics is not None else SysMetrics()
        self.status = ConnectionStatus()
        self._on_message_hook = on_message_hook

        transport: Literal["tcp", "websockets"] = (
            "websockets" if config.transport is Transport.WEBSOCKETS else "tcp"
        )
        factory = client_factory or mqtt.Client
        self._client = factory(
            CallbackAPIVersion.VERSION2,
            client_id=config.client_id,
            transport=transport,
            reconnect_on_failure=True,
        )
        self._configure_client()

    # -- setup -------------------------------------------------------------- #
    def _configure_client(self) -> None:
        c = self.config
        client = self._client
        if c.username:
            client.username_pw_set(c.username, c.password)
        if c.tls:
            client.tls_set(ca_certs=c.ca_certs)
            if c.tls_insecure:
                client.tls_insecure_set(True)
        # Exponential backoff between 1s and 60s for reconnects.
        client.reconnect_delay_set(min_delay=1, max_delay=60)
        client.on_connect = self._on_connect
        client.on_disconnect = self._on_disconnect
        client.on_message = self._on_message
        client.on_connect_fail = self._on_connect_fail

    # -- lifecycle ---------------------------------------------------------- #
    def connect(self) -> None:
        """Start connecting and spin up the background network loop."""
        self.status.set(ConnectionState.CONNECTING, self.config.address)
        self._client.connect_async(
            self.config.host, self.config.port, keepalive=self.config.keepalive
        )
        self._client.loop_start()

    def disconnect(self) -> None:
        """Cleanly stop the loop and disconnect (idempotent)."""
        try:
            self._client.disconnect()
        finally:
            self._client.loop_stop()
            self.status.set(ConnectionState.DISCONNECTED, "closed")

    def __enter__(self) -> MqttMonitorClient:
        self.connect()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.disconnect()

    @property
    def state(self) -> ConnectionState:
        return self.status.get()[0]

    # -- callbacks (paho VERSION2 signatures) ------------------------------- #
    def _on_connect(
        self,
        client: mqtt.Client,
        userdata: Any,
        flags: Any,
        reason_code: Any,
        properties: Any = None,
    ) -> None:
        if getattr(reason_code, "is_failure", False):
            self.status.set(ConnectionState.FAILED, str(reason_code))
            return
        self.status.set(ConnectionState.CONNECTED, self.config.address)
        # (Re)subscribe here so subscriptions survive reconnects automatically.
        subs = [(topic, self.config.qos) for topic in self.config.subscriptions]
        if subs:
            client.subscribe(subs)

    def _on_disconnect(
        self,
        client: mqtt.Client,
        userdata: Any,
        *args: Any,
    ) -> None:
        # VERSION2 passes (client, userdata, disconnect_flags, reason_code, properties).
        reason = args[-2] if len(args) >= 2 else (args[0] if args else "")
        if self.status.get()[0] is not ConnectionState.DISCONNECTED:
            self.status.set(ConnectionState.RECONNECTING, str(reason))

    def _on_connect_fail(self, client: mqtt.Client, userdata: Any) -> None:
        self.status.set(ConnectionState.RECONNECTING, "connection failed")

    def _on_message(
        self, client: mqtt.Client, userdata: Any, msg: mqtt.MQTTMessage
    ) -> None:
        topic = msg.topic
        payload = msg.payload or b""
        if SysMetrics.is_sys_topic(topic):
            self.sys_metrics.update(topic, payload)
        else:
            self.store.record(topic, payload)
        if self._on_message_hook is not None:
            self._on_message_hook(topic, payload)
