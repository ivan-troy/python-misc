"""Command-line interface.

``mqtt-monitor`` exposes a few focused sub-commands that all share the same
connection options. The shared options are declared once as reusable
``Annotated`` aliases to keep each command signature short and DRY.
"""

from __future__ import annotations

from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

from mqtt_monitor import __version__
from mqtt_monitor.config import DEFAULT_TOPIC, MonitorConfig, SortKey, Transport
from mqtt_monitor.themes import DEFAULT_THEME, all_themes, get_theme, make_theme_error_message

app = typer.Typer(
    add_completion=False,
    no_args_is_help=True,
    rich_markup_mode="rich",
    help="Lightweight, themeable terminal dashboard for MQTT brokers.",
)

# --------------------------------------------------------------------------- #
# Reusable option aliases (declared once, reused across commands)
# --------------------------------------------------------------------------- #
HostOpt = Annotated[str, typer.Option("--host", "-h", help="Broker hostname.")]
PortOpt = Annotated[int, typer.Option("--port", "-p", help="Broker port.")]
TopicOpt = Annotated[
    list[str],
    typer.Option("--topic", "-t", help="Topic filter to subscribe to (repeatable)."),
]
QosOpt = Annotated[int, typer.Option("--qos", "-q", min=0, max=2, help="Subscription QoS.")]
UserOpt = Annotated[str | None, typer.Option("--username", "-u", help="Username.")]
PassOpt = Annotated[
    str | None,
    typer.Option("--password", "-P", help="Password (prefer $MQTT_PASSWORD)."),
]
ClientIdOpt = Annotated[str | None, typer.Option("--client-id", help="MQTT client id.")]
TransportOpt = Annotated[Transport, typer.Option("--transport", help="Transport layer.")]
TlsOpt = Annotated[bool, typer.Option("--tls/--no-tls", help="Enable TLS.")]
TlsInsecureOpt = Annotated[
    bool, typer.Option("--tls-insecure", help="Skip TLS certificate verification.")
]
CaCertsOpt = Annotated[str | None, typer.Option("--ca-certs", help="CA bundle path for TLS.")]
ThemeOpt = Annotated[str, typer.Option("--theme", help="UI theme name.")]
RefreshOpt = Annotated[
    float, typer.Option("--refresh", min=0.5, max=30, help="Refresh rate (Hz).")
]
TopNOpt = Annotated[int, typer.Option("--top", min=1, help="Rows in the topics table.")]
SortOpt = Annotated[SortKey, typer.Option("--sort", help="Topic table sort key.")]
NoBrokerOpt = Annotated[
    bool, typer.Option("--no-broker", help="Do not subscribe to $SYS broker stats.")
]


def _resolve_password(password: str | None) -> str | None:
    if password is not None:
        return password
    import os

    return os.environ.get("MQTT_PASSWORD")


def _build_config(**kwargs: object) -> MonitorConfig:
    """Build and validate a :class:`MonitorConfig`, exiting cleanly on error."""
    topics = kwargs.pop("topics")
    topics_tuple = tuple(topics) if topics else (DEFAULT_TOPIC,)  # type: ignore[arg-type]
    theme = kwargs.get("theme", DEFAULT_THEME)
    try:
        get_theme(str(theme))
    except KeyError:
        raise typer.BadParameter(make_theme_error_message(str(theme))) from None
    try:
        return MonitorConfig(topics=topics_tuple, **kwargs)  # type: ignore[arg-type]
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc


def _run(runner: object, *args: object) -> None:
    """Invoke a runtime loop, swallowing Ctrl-C into a tidy exit."""
    try:
        runner(*args)  # type: ignore[operator]
    except KeyboardInterrupt:
        raise typer.Exit(code=0) from None


# --------------------------------------------------------------------------- #
# Commands
# --------------------------------------------------------------------------- #
@app.command()
def dashboard(
    host: HostOpt = "localhost",
    port: PortOpt = 1883,
    topic: TopicOpt = None,  # type: ignore[assignment]
    qos: QosOpt = 0,
    username: UserOpt = None,
    password: PassOpt = None,
    client_id: ClientIdOpt = None,
    transport: TransportOpt = Transport.TCP,
    tls: TlsOpt = False,
    tls_insecure: TlsInsecureOpt = False,
    ca_certs: CaCertsOpt = None,
    theme: ThemeOpt = DEFAULT_THEME,
    refresh: RefreshOpt = 4.0,
    top: TopNOpt = 20,
    sort: SortOpt = SortKey.RATE,
    no_broker: NoBrokerOpt = False,
) -> None:
    """Full live dashboard: broker health + per-topic statistics."""
    from mqtt_monitor.app import run_dashboard

    cfg = _build_config(
        host=host, port=port, topics=topic, qos=qos, username=username,
        password=_resolve_password(password),
        client_id=client_id or MonitorConfig().client_id,
        transport=transport, tls=tls, tls_insecure=tls_insecure, ca_certs=ca_certs,
        theme=theme, refresh_hz=refresh, top_n=top, sort_key=sort,
        track_broker=not no_broker,
    )
    _run(run_dashboard, cfg)


@app.command()
def topics(
    host: HostOpt = "localhost",
    port: PortOpt = 1883,
    topic: TopicOpt = None,  # type: ignore[assignment]
    qos: QosOpt = 0,
    username: UserOpt = None,
    password: PassOpt = None,
    theme: ThemeOpt = DEFAULT_THEME,
    refresh: RefreshOpt = 4.0,
    top: TopNOpt = 25,
    sort: SortOpt = SortKey.RATE,
) -> None:
    """Per-topic statistics only (no broker panel), full width."""
    from mqtt_monitor.app import run_dashboard

    cfg = _build_config(
        host=host, port=port, topics=topic, qos=qos, username=username,
        password=_resolve_password(password), theme=theme, refresh_hz=refresh,
        top_n=top, sort_key=sort, track_broker=False,
    )
    _run(run_dashboard, cfg)


@app.command()
def broker(
    host: HostOpt = "localhost",
    port: PortOpt = 1883,
    username: UserOpt = None,
    password: PassOpt = None,
    theme: ThemeOpt = DEFAULT_THEME,
    refresh: RefreshOpt = 2.0,
) -> None:
    """Broker health from the $SYS topic tree."""
    from mqtt_monitor.app import run_broker

    cfg = _build_config(
        host=host, port=port, topics=[DEFAULT_TOPIC], username=username,
        password=_resolve_password(password), theme=theme, refresh_hz=refresh,
        track_broker=True,
    )
    _run(run_broker, cfg)


@app.command()
def browse(
    topic: Annotated[str, typer.Argument(help="Topic filter to tail.")],
    host: HostOpt = "localhost",
    port: PortOpt = 1883,
    qos: QosOpt = 0,
    username: UserOpt = None,
    password: PassOpt = None,
    theme: ThemeOpt = DEFAULT_THEME,
    refresh: RefreshOpt = 8.0,
    history: Annotated[int, typer.Option("--history", min=1, help="Payloads to retain.")] = 200,
) -> None:
    """Tail and inspect recent payloads on a specific topic."""
    from mqtt_monitor.app import run_browse

    cfg = _build_config(
        host=host, port=port, topics=[topic], qos=qos, username=username,
        password=_resolve_password(password), theme=theme, refresh_hz=refresh,
        payload_history=history, track_broker=False,
    )
    _run(run_browse, cfg, topic)


@app.command()
def themes() -> None:
    """List available UI themes with a coloured style preview."""
    from rich.text import Text

    from mqtt_monitor.themes import UITheme

    console = Console()
    table = Table(title="Available themes", expand=False)
    table.add_column("name", style="bold")
    table.add_column("description")
    table.add_column("preview")

    def preview(theme: UITheme) -> Text:
        txt = Text()
        for key, sample in (("title", "Aa"), ("value", "value"), ("accent", "accent"),
                            ("good", "ok"), ("warn", "warn"), ("bad", "err")):
            txt.append(sample + " ", style=theme.styles.get(key, ""))
        return txt

    for t in all_themes():
        table.add_row(t.name, t.description, preview(t))
    console.print(table)


@app.command()
def version() -> None:
    """Print the version and exit."""
    typer.echo(f"mqtt-monitor {__version__}")


if __name__ == "__main__":  # pragma: no cover
    app()
