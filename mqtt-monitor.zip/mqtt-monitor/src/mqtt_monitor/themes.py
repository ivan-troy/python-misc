"""Theme system for the terminal UI.

Every widget references *semantic* style names (``title``, ``value``, ``good``,
``bad`` ...) rather than raw colours, so swapping a palette re-skins the whole
app without touching layout code. A theme also carries a ``box`` and
``border_style`` so structural chrome changes with the palette too.
"""

from __future__ import annotations

from dataclasses import dataclass

from rich import box
from rich.box import Box
from rich.theme import Theme

# Semantic style keys every theme must define.
_STYLE_KEYS = (
    "title", "subtitle", "label", "value", "accent", "muted",
    "good", "warn", "bad", "table.header", "table.row", "border",
)


@dataclass(frozen=True, slots=True)
class UITheme:
    """A named palette plus structural chrome choices."""

    name: str
    description: str
    styles: dict[str, str]
    box: Box = box.ROUNDED
    border_style: str = "border"

    def rich_theme(self) -> Theme:
        return Theme(self.styles)

    def validate(self) -> None:
        missing = [k for k in _STYLE_KEYS if k not in self.styles]
        if missing:
            raise ValueError(f"theme {self.name!r} missing styles: {missing}")


# --------------------------------------------------------------------------- #
# Palettes
# --------------------------------------------------------------------------- #
_NORD = UITheme(
    name="nord",
    description="Cool arctic blues — calm and easy on the eyes.",
    box=box.ROUNDED,
    styles={
        "title": "bold #88c0d0",
        "subtitle": "#81a1c1",
        "label": "#8fbcbb",
        "value": "#eceff4",
        "accent": "bold #b48ead",
        "muted": "#4c566a",
        "good": "bold #a3be8c",
        "warn": "bold #ebcb8b",
        "bad": "bold #bf616a",
        "table.header": "bold #88c0d0",
        "table.row": "#d8dee9",
        "border": "#4c566a",
    },
)

_DRACULA = UITheme(
    name="dracula",
    description="Vivid neon on deep purple-grey.",
    box=box.ROUNDED,
    styles={
        "title": "bold #bd93f9",
        "subtitle": "#ff79c6",
        "label": "#8be9fd",
        "value": "#f8f8f2",
        "accent": "bold #ff79c6",
        "muted": "#6272a4",
        "good": "bold #50fa7b",
        "warn": "bold #f1fa8c",
        "bad": "bold #ff5555",
        "table.header": "bold #bd93f9",
        "table.row": "#f8f8f2",
        "border": "#6272a4",
    },
)

_SOLARIZED = UITheme(
    name="solarized",
    description="The classic balanced Solarized-dark palette.",
    box=box.SQUARE,
    styles={
        "title": "bold #268bd2",
        "subtitle": "#2aa198",
        "label": "#93a1a1",
        "value": "#eee8d5",
        "accent": "bold #d33682",
        "muted": "#586e75",
        "good": "bold #859900",
        "warn": "bold #b58900",
        "bad": "bold #dc322f",
        "table.header": "bold #268bd2",
        "table.row": "#93a1a1",
        "border": "#586e75",
    },
)

_MATRIX = UITheme(
    name="matrix",
    description="Green-on-black terminal nostalgia.",
    box=box.HEAVY,
    styles={
        "title": "bold #00ff41",
        "subtitle": "#00b32c",
        "label": "#00b32c",
        "value": "#7fff9f",
        "accent": "bold #baffc9",
        "muted": "#026e1a",
        "good": "bold #00ff41",
        "warn": "bold #d4ff00",
        "bad": "bold #ff3131",
        "table.header": "bold #00ff41",
        "table.row": "#3aff6a",
        "border": "#026e1a",
    },
)

# --- Minimalistic themes --------------------------------------------------- #
_MINIMAL = UITheme(
    name="minimal",
    description="Monochrome, no colour noise — content first.",
    box=box.SIMPLE,
    styles={
        "title": "bold white",
        "subtitle": "dim white",
        "label": "dim white",
        "value": "white",
        "accent": "bold white",
        "muted": "grey42",
        "good": "white",
        "warn": "bold white",
        "bad": "bold white",
        "table.header": "bold white",
        "table.row": "white",
        "border": "grey42",
    },
)

_MONO_LIGHT = UITheme(
    name="mono-light",
    description="Minimal palette tuned for light terminals.",
    box=box.MINIMAL,
    styles={
        "title": "bold black",
        "subtitle": "grey35",
        "label": "grey35",
        "value": "black",
        "accent": "bold black",
        "muted": "grey58",
        "good": "black",
        "warn": "bold black",
        "bad": "bold black",
        "table.header": "bold black",
        "table.row": "grey19",
        "border": "grey70",
    },
)

_SLATE = UITheme(
    name="slate",
    description="Understated blue-grey with a single accent.",
    box=box.SIMPLE_HEAVY,
    styles={
        "title": "bold #cbd5e1",
        "subtitle": "#94a3b8",
        "label": "#94a3b8",
        "value": "#e2e8f0",
        "accent": "bold #38bdf8",
        "muted": "#475569",
        "good": "#4ade80",
        "warn": "#facc15",
        "bad": "#f87171",
        "table.header": "bold #cbd5e1",
        "table.row": "#cbd5e1",
        "border": "#334155",
    },
)


_THEMES: dict[str, UITheme] = {
    t.name: t
    for t in (_NORD, _DRACULA, _SOLARIZED, _MATRIX, _MINIMAL, _MONO_LIGHT, _SLATE)
}
for _t in _THEMES.values():
    _t.validate()

DEFAULT_THEME = "nord"


def get_theme(name: str) -> UITheme:
    """Return a theme by name, raising ``KeyError`` with the valid set listed."""
    try:
        return _THEMES[name]
    except KeyError as exc:
        raise KeyError(
            f"unknown theme {name!r}; available: {', '.join(sorted(_THEMES))}"
        ) from exc


def theme_names() -> list[str]:
    return sorted(_THEMES)


def all_themes() -> list[UITheme]:
    return [_THEMES[n] for n in theme_names()]


def make_theme_error_message(name: str) -> str:
    """Human-friendly message listing valid themes for a bad ``--theme``."""
    return f"unknown theme {name!r}; available: {', '.join(theme_names())}"


def next_theme(current: str) -> str:
    """Cycle to the next theme name (wraps around)."""
    names = theme_names()
    try:
        idx = names.index(current)
    except ValueError:
        return names[0]
    return names[(idx + 1) % len(names)]
