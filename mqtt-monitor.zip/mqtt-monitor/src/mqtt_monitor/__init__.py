"""mqtt-monitor: a lightweight, themeable terminal dashboard for MQTT.

Public API surface kept intentionally small so downstream code can rely on it.
"""

from __future__ import annotations

from mqtt_monitor.config import MonitorConfig
from mqtt_monitor.metrics import MetricsStore, StoreSnapshot, TopicMetric
from mqtt_monitor.sys_topics import SysMetrics

__all__ = [
    "MetricsStore",
    "MonitorConfig",
    "StoreSnapshot",
    "SysMetrics",
    "TopicMetric",
    "__version__",
]

__version__ = "0.1.0"
