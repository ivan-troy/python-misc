"""Parsing and presentation of broker ``$SYS`` statistics.

Brokers publish their own health under the ``$SYS/broker/...`` tree. The exact
set of keys varies (Mosquitto, EMQX, HiveMQ, VerneMQ all differ slightly), so
we keep a curated table of well-known keys for nice labels/ordering/formatting
and fall back to showing anything else generically.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from threading import Lock


def format_bytes(value: float) -> str:
    """Human-readable byte count (1024-based)."""
    num = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if abs(num) < 1024.0 or unit == "TiB":
            return f"{num:.0f} {unit}" if unit == "B" else f"{num:.1f} {unit}"
        num /= 1024.0
    return f"{num:.1f} TiB"  # pragma: no cover - unreachable


def format_duration(seconds: float) -> str:
    """Compact human duration, e.g. ``3d 04:15:09``."""
    seconds = int(seconds)
    days, rem = divmod(seconds, 86_400)
    hours, rem = divmod(rem, 3_600)
    minutes, secs = divmod(rem, 60)
    if days:
        return f"{days}d {hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def _fmt_uptime(raw: str) -> str:
    # Mosquitto reports e.g. "3600 seconds"; keep it robust to either form.
    token = raw.split()[0] if raw else "0"
    try:
        return format_duration(float(token))
    except ValueError:
        return raw


def _fmt_bytes(raw: str) -> str:
    try:
        return format_bytes(float(raw))
    except ValueError:
        return raw


def _fmt_number(raw: str) -> str:
    try:
        f = float(raw)
    except ValueError:
        return raw
    return f"{int(f):,}" if f.is_integer() else f"{f:,.2f}"


@dataclass(frozen=True, slots=True)
class SysField:
    """A known ``$SYS`` key with display metadata."""

    suffix: str          # topic suffix after "$SYS/broker/"
    label: str           # human label
    fmt: Callable[[str], str]


# Curated, ordered set of the most useful broker metrics.
KNOWN_FIELDS: tuple[SysField, ...] = (
    SysField("version", "Broker version", str),
    SysField("uptime", "Uptime", _fmt_uptime),
    SysField("clients/connected", "Clients connected", _fmt_number),
    SysField("clients/active", "Clients active", _fmt_number),
    SysField("clients/inactive", "Clients inactive", _fmt_number),
    SysField("clients/total", "Clients total", _fmt_number),
    SysField("clients/maximum", "Clients peak", _fmt_number),
    SysField("subscriptions/count", "Subscriptions", _fmt_number),
    SysField("retained messages/count", "Retained messages", _fmt_number),
    SysField("messages/received", "Messages received", _fmt_number),
    SysField("messages/sent", "Messages sent", _fmt_number),
    SysField("publish/messages/received", "Publishes received", _fmt_number),
    SysField("publish/messages/sent", "Publishes sent", _fmt_number),
    SysField("messages/stored", "Messages stored", _fmt_number),
    SysField("bytes/received", "Bytes received", _fmt_bytes),
    SysField("bytes/sent", "Bytes sent", _fmt_bytes),
    SysField("load/messages/received/1min", "Msg in /1min", _fmt_number),
    SysField("load/messages/sent/1min", "Msg out /1min", _fmt_number),
    SysField("load/bytes/received/1min", "Bytes in /1min", _fmt_bytes),
    SysField("load/bytes/sent/1min", "Bytes out /1min", _fmt_bytes),
    SysField("heap/current", "Heap current", _fmt_bytes),
    SysField("heap/maximum", "Heap maximum", _fmt_bytes),
)

_FIELD_BY_SUFFIX = {f.suffix: f for f in KNOWN_FIELDS}
_FIELD_ORDER = {f.suffix: i for i, f in enumerate(KNOWN_FIELDS)}
_PREFIX = "$SYS/broker/"


@dataclass
class SysMetrics:
    """Thread-safe holder of raw ``$SYS`` values with friendly rendering."""

    _raw: dict[str, str] = field(default_factory=dict)
    _lock: Lock = field(default_factory=Lock)

    @staticmethod
    def is_sys_topic(topic: str) -> bool:
        return topic.startswith("$SYS/")

    def update(self, topic: str, payload: bytes) -> None:
        """Store a ``$SYS`` value. Non-``$SYS`` topics are ignored."""
        if not self.is_sys_topic(topic):
            return
        suffix = topic[len(_PREFIX):] if topic.startswith(_PREFIX) else topic
        text = payload.decode("utf-8", errors="replace").strip()
        with self._lock:
            self._raw[suffix] = text

    def get(self, suffix: str) -> str | None:
        with self._lock:
            return self._raw.get(suffix)

    def raw(self) -> dict[str, str]:
        with self._lock:
            return dict(self._raw)

    def friendly_rows(self) -> list[tuple[str, str]]:
        """Return ``(label, formatted_value)`` rows.

        Known keys come first in curated order; any additional keys the broker
        exposes follow alphabetically so nothing is silently dropped.
        """
        data = self.raw()
        rows: list[tuple[str, str]] = []
        for suffix, value in data.items():
            fld = _FIELD_BY_SUFFIX.get(suffix)
            if fld is not None:
                rows.append((fld.label, fld.fmt(value)))
        rows.sort(key=lambda r: _label_order(r[0]))
        extras = sorted(
            (s, v) for s, v in data.items() if s not in _FIELD_BY_SUFFIX
        )
        rows.extend((s, v) for s, v in extras)
        return rows

    def __len__(self) -> int:
        with self._lock:
            return len(self._raw)


_LABEL_ORDER = {f.label: i for i, f in enumerate(KNOWN_FIELDS)}


def _label_order(label: str) -> int:
    return _LABEL_ORDER.get(label, len(KNOWN_FIELDS))
