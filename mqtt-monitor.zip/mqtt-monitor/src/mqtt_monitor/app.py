"""Runtime drivers that connect the client, stores, and Rich UI.

These functions own the live loop; everything they render comes from the pure
functions in :mod:`mqtt_monitor.ui`, and everything they display comes from the
thread-safe stores filled by :class:`~mqtt_monitor.client.MqttMonitorClient`.
"""

from __future__ import annotations

import time
from dataclasses import replace

from rich.live import Live

from mqtt_monitor.client import MqttMonitorClient
from mqtt_monitor.config import MonitorConfig, SortKey
from mqtt_monitor.keyboard import KeyboardListener
from mqtt_monitor.metrics import MetricsStore, PayloadRecord, RateComputer
from mqtt_monitor.sys_topics import SysMetrics
from mqtt_monitor.themes import UITheme, get_theme, next_theme
from mqtt_monitor.ui import build_dashboard, make_console, render_browse_table

_SORT_CYCLE = list(SortKey)


def _next_sort(current: SortKey) -> SortKey:
    idx = _SORT_CYCLE.index(current)
    return _SORT_CYCLE[(idx + 1) % len(_SORT_CYCLE)]


def run_dashboard(config: MonitorConfig) -> None:
    """Run the interactive live dashboard until quit (``q`` or Ctrl-C)."""
    store = MetricsStore(history_size=config.payload_history)
    sys_metrics = SysMetrics()
    rates = RateComputer()
    theme: UITheme = get_theme(config.theme)
    console = make_console(theme)

    paused = False
    period = 1.0 / config.refresh_hz

    client = MqttMonitorClient(config, store, sys_metrics)
    with KeyboardListener() as keys, client, Live(
        console=console, screen=True, auto_refresh=False
    ) as live:
        interactive = keys.enabled
        while True:
            key = keys.get()
            if key is not None:
                action = _handle_key(key)
                if action == "quit":
                    break
                if action == "pause":
                    paused = not paused
                elif action == "reset":
                    store.reset()
                    rates = RateComputer()
                elif action == "theme":
                    config = config.with_theme(next_theme(config.theme))
                    theme = get_theme(config.theme)
                    console.push_theme(theme.rich_theme())
                elif action == "sort":
                    config = config.with_sort_key(_next_sort(config.sort_key))

            snapshot = store.snapshot()
            topic_rates = {} if paused else rates.update(snapshot)
            state, detail = client.status.get()
            live.update(
                build_dashboard(
                    config, state, detail, snapshot, topic_rates,
                    sys_metrics, theme, paused=paused, interactive=interactive,
                ),
                refresh=True,
            )
            time.sleep(period)


def _handle_key(key: str) -> str | None:
    mapping = {
        "q": "quit", "Q": "quit",
        "p": "pause", " ": "pause",
        "r": "reset", "R": "reset",
        "t": "theme", "T": "theme",
        "s": "sort", "S": "sort",
    }
    return mapping.get(key)


def run_browse(config: MonitorConfig, topic: str) -> None:
    """Tail payloads of a single topic in a scrolling table."""
    # Browsing one topic: subscribe to just that filter, skip $SYS noise.
    browse_config = replace(config, topics=(topic,), track_broker=False)
    store = MetricsStore(history_size=max(config.payload_history, 100))
    theme = get_theme(config.theme)
    console = make_console(theme)
    period = 1.0 / config.refresh_hz

    client = MqttMonitorClient(browse_config, store)
    with client, Live(console=console, screen=True, auto_refresh=False) as live:
        while True:
            snapshot = store.snapshot()
            # Merge histories across all matching subtopics under the filter.
            merged: list[PayloadRecord] = []
            for m in snapshot.topics:
                merged.extend(store.history(m.topic))
            merged.sort(key=lambda r: r.timestamp)
            live.update(render_browse_table(topic, merged, theme), refresh=True)
            time.sleep(period)


def run_broker(config: MonitorConfig) -> None:
    """Show only the broker ``$SYS`` panel, full width."""
    from rich.console import Group

    from mqtt_monitor.ui import render_broker_panel, render_header

    store = MetricsStore(history_size=1)
    sys_metrics = SysMetrics()
    # Subscribe to $SYS (user topics are ignored in this view).
    broker_config = replace(config, track_broker=True)
    theme = get_theme(config.theme)
    console = make_console(theme)
    period = 1.0 / config.refresh_hz

    client = MqttMonitorClient(broker_config, store, sys_metrics)
    with client, Live(console=console, screen=True, auto_refresh=False) as live:
        while True:
            snapshot = store.snapshot()
            state, detail = client.status.get()
            live.update(
                Group(
                    render_header(config, state, detail, snapshot, theme),
                    render_broker_panel(sys_metrics, theme),
                ),
                refresh=True,
            )
            time.sleep(period)
