"""Allow ``python -m mqtt_monitor``."""

from mqtt_monitor.cli import app

if __name__ == "__main__":
    app()
