"""Minimal, dependency-free, non-blocking keyboard input.

Rich's ``Live`` does not read input, so for an interactive dashboard we run a
tiny listener in a background thread and drain single keypresses from a queue.
The listener degrades gracefully: if stdin is not a TTY (piped, CI, no
terminal) it simply yields nothing, and the dashboard runs as a read-only view.

Only the standard library is used (``termios``/``tty`` on POSIX, ``msvcrt`` on
Windows), keeping the tool lightweight.
"""

from __future__ import annotations

import contextlib
import queue
import sys
import threading
from collections.abc import Iterator

__all__ = ["KeyboardListener", "stdin_is_interactive"]


def stdin_is_interactive() -> bool:
    """True only when stdin is a real terminal we can read keys from."""
    try:
        return sys.stdin is not None and sys.stdin.isatty()
    except (ValueError, OSError):  # pragma: no cover - closed stdin
        return False


class KeyboardListener:
    """Background single-key reader exposing a non-blocking ``get()``.

    Use as a context manager; it restores terminal state on exit. When the
    terminal is not interactive it becomes a no-op so calling code needs no
    special-casing.
    """

    def __init__(self) -> None:
        self._queue: queue.Queue[str] = queue.Queue()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.enabled = stdin_is_interactive()

    def __enter__(self) -> KeyboardListener:
        if self.enabled:
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._thread.start()
        return self

    def __exit__(self, *exc: object) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=0.5)

    def get(self) -> str | None:
        """Return the next pending keypress, or ``None`` if none is waiting."""
        try:
            return self._queue.get_nowait()
        except queue.Empty:
            return None

    # -- platform readers --------------------------------------------------- #
    def _run(self) -> None:  # pragma: no cover - requires a real TTY
        try:
            if sys.platform == "win32":
                self._run_windows()
            else:
                self._run_posix()
        except Exception:
            # Never let an input glitch crash the app; just stop reading.
            self.enabled = False

    def _run_posix(self) -> None:  # pragma: no cover - requires a real TTY
        import select
        import termios
        import tty

        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setcbreak(fd)
            while not self._stop.is_set():
                if select.select([sys.stdin], [], [], 0.1)[0]:
                    ch = sys.stdin.read(1)
                    if ch:
                        self._queue.put(ch)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)

    def _run_windows(self) -> None:  # pragma: no cover - windows only
        import msvcrt
        import time

        while not self._stop.is_set():
            if msvcrt.kbhit():  # type: ignore[attr-defined]
                ch = msvcrt.getwch()  # type: ignore[attr-defined]
                if ch:
                    self._queue.put(ch)
            else:
                time.sleep(0.05)


@contextlib.contextmanager
def keyboard_listener() -> Iterator[KeyboardListener]:
    """Convenience context manager wrapper."""
    listener = KeyboardListener()
    with listener:
        yield listener
