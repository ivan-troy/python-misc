"""Metric collection for per-topic MQTT statistics.

Design notes
------------
* Messages arrive on paho's network thread while the UI reads on the main
  thread, so all mutation goes through a single lock. The critical section is
  tiny (a few dict updates), which keeps contention negligible even at high
  message rates.
* Rendering never touches live mutable state: callers take an immutable
  :class:`StoreSnapshot`. This makes the UI trivially testable and avoids
  "dict changed size during iteration" style races.
* Instantaneous rate is computed by :class:`RateComputer` from two snapshots,
  which is O(1) per topic and avoids storing an unbounded window of timestamps.
"""

from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field
from threading import Lock
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Iterator


@dataclass(frozen=True, slots=True)
class PayloadRecord:
    """A single received payload, retained for the browser view."""

    timestamp: float
    payload: bytes

    @property
    def size(self) -> int:
        return len(self.payload)


@dataclass(frozen=True, slots=True)
class TopicMetric:
    """Immutable snapshot of one topic's statistics."""

    topic: str
    count: int
    bytes_total: int
    first_seen: float
    last_seen: float
    last_payload: bytes

    @property
    def avg_size(self) -> float:
        return self.bytes_total / self.count if self.count else 0.0

    @property
    def lifetime_rate(self) -> float:
        """Average messages/second over the topic's whole lifetime."""
        span = self.last_seen - self.first_seen
        if span <= 0:
            return 0.0
        return (self.count - 1) / span


class _TopicAccumulator:
    """Mutable per-topic counter (internal, guarded by the store lock)."""

    __slots__ = ("bytes_total", "count", "first_seen", "history", "last_seen", "topic")

    def __init__(self, topic: str, history_size: int) -> None:
        self.topic = topic
        self.count = 0
        self.bytes_total = 0
        self.first_seen = 0.0
        self.last_seen = 0.0
        self.history: deque[PayloadRecord] = deque(maxlen=history_size)

    def add(self, payload: bytes, ts: float) -> None:
        if self.count == 0:
            self.first_seen = ts
        self.count += 1
        self.bytes_total += len(payload)
        self.last_seen = ts
        self.history.append(PayloadRecord(ts, payload))

    def to_metric(self) -> TopicMetric:
        last = self.history[-1].payload if self.history else b""
        return TopicMetric(
            topic=self.topic,
            count=self.count,
            bytes_total=self.bytes_total,
            first_seen=self.first_seen,
            last_seen=self.last_seen,
            last_payload=last,
        )


@dataclass(frozen=True, slots=True)
class StoreSnapshot:
    """Immutable point-in-time view of the whole store."""

    captured_at: float
    started_at: float
    total_messages: int
    total_bytes: int
    topics: tuple[TopicMetric, ...]

    @property
    def elapsed(self) -> float:
        return max(self.captured_at - self.started_at, 0.0)

    @property
    def topic_count(self) -> int:
        return len(self.topics)

    @property
    def overall_rate(self) -> float:
        return self.total_messages / self.elapsed if self.elapsed > 0 else 0.0

    @property
    def overall_byte_rate(self) -> float:
        return self.total_bytes / self.elapsed if self.elapsed > 0 else 0.0


class MetricsStore:
    """Thread-safe accumulator of per-topic MQTT statistics."""

    def __init__(
        self, *, history_size: int = 200, clock: Callable[[], float] = time.time
    ) -> None:
        self._history_size = history_size
        self._clock = clock
        self._lock = Lock()
        self._topics: dict[str, _TopicAccumulator] = {}
        self._total_messages = 0
        self._total_bytes = 0
        self._started_at = clock()

    def record(self, topic: str, payload: bytes, ts: float | None = None) -> None:
        """Record one received message. Safe to call from any thread."""
        ts = self._clock() if ts is None else ts
        with self._lock:
            acc = self._topics.get(topic)
            if acc is None:
                acc = _TopicAccumulator(topic, self._history_size)
                self._topics[topic] = acc
            acc.add(payload, ts)
            self._total_messages += 1
            self._total_bytes += len(payload)

    def reset(self) -> None:
        """Clear all collected topics and counters, restarting the epoch.

        Useful because brokers replay retained/will messages on connect; a reset
        lets you measure only *live* traffic from this point on.
        """
        with self._lock:
            self._topics.clear()
            self._total_messages = 0
            self._total_bytes = 0
            self._started_at = self._clock()

    def snapshot(self) -> StoreSnapshot:
        """Return an immutable copy safe to render outside the lock."""
        with self._lock:
            topics = tuple(acc.to_metric() for acc in self._topics.values())
            snap = StoreSnapshot(
                captured_at=self._clock(),
                started_at=self._started_at,
                total_messages=self._total_messages,
                total_bytes=self._total_bytes,
                topics=topics,
            )
        return snap

    def history(self, topic: str) -> tuple[PayloadRecord, ...]:
        """Return the retained payload history for a single topic (newest last)."""
        with self._lock:
            acc = self._topics.get(topic)
            return tuple(acc.history) if acc else ()

    def __len__(self) -> int:
        with self._lock:
            return len(self._topics)


@dataclass
class RateComputer:
    """Derives instantaneous rates by diffing successive snapshots.

    The store only accumulates totals; turning those into a "messages/second
    right now" figure needs two samples. This helper keeps the previous sample
    and returns per-topic and overall rates on each new snapshot.
    """

    _prev_counts: dict[str, int] = field(default_factory=dict)
    _prev_bytes: dict[str, int] = field(default_factory=dict)
    _prev_time: float | None = None

    def update(self, snapshot: StoreSnapshot) -> dict[str, TopicRate]:
        """Compute rates for ``snapshot`` relative to the previous one."""
        rates: dict[str, TopicRate] = {}
        dt = 0.0 if self._prev_time is None else snapshot.captured_at - self._prev_time
        for m in snapshot.topics:
            prev_c = self._prev_counts.get(m.topic, m.count if self._prev_time is None else 0)
            prev_b = self._prev_bytes.get(m.topic, m.bytes_total if self._prev_time is None else 0)
            if dt > 0:
                msg_rate = max(m.count - prev_c, 0) / dt
                byte_rate = max(m.bytes_total - prev_b, 0) / dt
            else:
                msg_rate = byte_rate = 0.0
            rates[m.topic] = TopicRate(m.topic, msg_rate, byte_rate)
        self._prev_counts = {m.topic: m.count for m in snapshot.topics}
        self._prev_bytes = {m.topic: m.bytes_total for m in snapshot.topics}
        self._prev_time = snapshot.captured_at
        return rates


@dataclass(frozen=True, slots=True)
class TopicRate:
    """Instantaneous rate for a topic between two snapshots."""

    topic: str
    msg_rate: float   # messages/second
    byte_rate: float  # bytes/second


def sort_metrics(
    metrics: Iterable[TopicMetric],
    key: str,
    rates: dict[str, TopicRate] | None = None,
) -> list[TopicMetric]:
    """Return ``metrics`` sorted by the named key (descending, except topic)."""
    rates = rates or {}
    items = list(metrics)

    def rate_of(m: TopicMetric) -> float:
        r = rates.get(m.topic)
        return r.msg_rate if r else m.lifetime_rate

    match key:
        case "rate":
            items.sort(key=rate_of, reverse=True)
        case "count":
            items.sort(key=lambda m: m.count, reverse=True)
        case "bytes":
            items.sort(key=lambda m: m.bytes_total, reverse=True)
        case "last":
            items.sort(key=lambda m: m.last_seen, reverse=True)
        case "topic":
            items.sort(key=lambda m: m.topic)
        case _:  # pragma: no cover - guarded by CLI enum
            raise ValueError(f"unknown sort key: {key!r}")
    return items


def iter_topics_by_prefix(
    metrics: Iterable[TopicMetric], prefix: str
) -> Iterator[TopicMetric]:
    """Yield metrics whose topic starts with ``prefix`` (exact tree match)."""
    for m in metrics:
        if m.topic == prefix or m.topic.startswith(prefix.rstrip("#/") + "/"):
            yield m
