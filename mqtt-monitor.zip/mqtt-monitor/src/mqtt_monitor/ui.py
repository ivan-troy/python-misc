"""Terminal UI built on Rich.

The render functions here are **pure**: given a snapshot + theme they return a
Rich renderable and never touch live state or perform I/O. That keeps them
unit-testable and lets the live loop stay a thin driver around them.
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import TYPE_CHECKING

from rich.align import Align
from rich.console import Console, Group, RenderableType
from rich.json import JSON
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from mqtt_monitor.client import ConnectionState
from mqtt_monitor.metrics import (
    StoreSnapshot,
    TopicRate,
    sort_metrics,
)
from mqtt_monitor.sys_topics import SysMetrics, format_bytes
from mqtt_monitor.themes import UITheme

if TYPE_CHECKING:
    from mqtt_monitor.config import MonitorConfig
    from mqtt_monitor.metrics import PayloadRecord

_STATE_STYLE = {
    ConnectionState.CONNECTED: ("good", "●"),
    ConnectionState.CONNECTING: ("warn", "◌"),
    ConnectionState.RECONNECTING: ("warn", "◌"),
    ConnectionState.DISCONNECTED: ("muted", "○"),
    ConnectionState.FAILED: ("bad", "✕"),
    ConnectionState.INITIAL: ("muted", "○"),
}


def make_console(theme: UITheme, **kwargs: object) -> Console:
    """Console pre-loaded with a theme's semantic styles."""
    return Console(theme=theme.rich_theme(), **kwargs)  # type: ignore[arg-type]


# --------------------------------------------------------------------------- #
# formatting helpers
# --------------------------------------------------------------------------- #
def human_count(n: float) -> str:
    n = float(n)
    for unit in ("", "K", "M", "B"):
        if abs(n) < 1000 or unit == "B":
            return f"{int(n)}" if unit == "" else f"{n:.1f}{unit}"
        n /= 1000
    return f"{n:.1f}B"  # pragma: no cover


def human_rate(rate: float) -> str:
    if rate <= 0:
        return "—"
    if rate < 1:
        return f"{rate:.2f}/s"
    if rate < 100:
        return f"{rate:.1f}/s"
    return f"{human_count(rate)}/s"


def payload_preview(payload: bytes, max_len: int = 120) -> str:
    """Single-line, whitespace-collapsed preview safe for a table cell."""
    text = payload.decode("utf-8", errors="replace")
    text = " ".join(text.split())
    if len(text) > max_len:
        text = text[: max_len - 1] + "…"
    return text or "∅"


def render_payload_full(payload: bytes) -> RenderableType:
    """Pretty renderable for a full payload; JSON is syntax-highlighted."""
    text = payload.decode("utf-8", errors="replace")
    stripped = text.strip()
    if stripped and stripped[0] in "{[":
        try:
            return JSON(json.dumps(json.loads(stripped)))
        except (json.JSONDecodeError, ValueError):
            pass
    return Text(text or "∅")


# --------------------------------------------------------------------------- #
# panels
# --------------------------------------------------------------------------- #
def render_header(
    config: MonitorConfig,
    state: ConnectionState,
    detail: str,
    snapshot: StoreSnapshot,
    theme: UITheme,
) -> Panel:
    style, glyph = _STATE_STYLE.get(state, ("muted", "○"))
    left = Text.assemble(
        (f"{glyph} ", style),
        (state.value.upper(), style),
        ("  ", ""),
        (config.address, "value"),
    )
    if detail and state in (ConnectionState.RECONNECTING, ConnectionState.FAILED):
        left.append(f"  ({detail})", style="muted")

    right = Text.assemble(
        ("topics ", "label"), (human_count(snapshot.topic_count), "value"),
        ("   msgs ", "label"), (human_count(snapshot.total_messages), "value"),
        ("   ", ""), (format_bytes(snapshot.total_bytes), "value"),
        ("   ", ""), (human_rate(snapshot.overall_rate), "accent"),
    )
    grid = Table.grid(expand=True)
    grid.add_column(justify="left")
    grid.add_column(justify="right")
    grid.add_row(left, right)
    return Panel(
        grid,
        title="[title]mqtt-monitor[/title]",
        subtitle=f"[subtitle]{datetime.now():%H:%M:%S}[/subtitle]",
        box=theme.box,
        border_style=theme.border_style,
    )


def render_broker_panel(sys_metrics: SysMetrics, theme: UITheme) -> Panel:
    table = Table.grid(padding=(0, 2))
    table.add_column(style="label", justify="left")
    table.add_column(style="value", justify="right")
    rows = sys_metrics.friendly_rows()
    if rows:
        for label, value in rows:
            table.add_row(label, value)
        body: RenderableType = table
    else:
        body = Align.center(Text("waiting for $SYS data…", style="muted"))
    return Panel(
        body,
        title="[title]broker ($SYS)[/title]",
        box=theme.box,
        border_style=theme.border_style,
    )


def render_topics_table(
    snapshot: StoreSnapshot,
    rates: dict[str, TopicRate],
    config: MonitorConfig,
    theme: UITheme,
) -> Panel:
    ordered = sort_metrics(snapshot.topics, config.sort_key.value, rates)
    shown = ordered[: config.top_n]

    table = Table(
        box=theme.box,
        border_style=theme.border_style,
        header_style="table.header",
        expand=True,
        row_styles=["table.row"],
        pad_edge=False,
    )
    table.add_column("topic", ratio=3, no_wrap=True, overflow="ellipsis")
    table.add_column("count", justify="right", ratio=1)
    table.add_column("msg/s", justify="right", ratio=1)
    table.add_column("bytes", justify="right", ratio=1)
    table.add_column("last payload", ratio=3, no_wrap=True, overflow="ellipsis")

    for m in shown:
        rate = rates.get(m.topic)
        rate_val = rate.msg_rate if rate else m.lifetime_rate
        rate_style = "accent" if rate_val > 0 else "muted"
        table.add_row(
            m.topic,
            human_count(m.count),
            Text(human_rate(rate_val), style=rate_style),
            format_bytes(m.bytes_total),
            Text(payload_preview(m.last_payload, config.max_payload_preview), style="muted"),
        )

    hidden = max(len(ordered) - len(shown), 0)
    subtitle = (
        f"[muted]sorted by {config.sort_key.value} · "
        f"{'showing all' if not hidden else f'+{hidden} more'}[/muted]"
    )
    return Panel(
        table if shown else Align.center(Text("no messages yet…", style="muted")),
        title=f"[title]topics[/title] [muted]({snapshot.topic_count})[/muted]",
        subtitle=subtitle,
        box=theme.box,
        border_style=theme.border_style,
    )


def render_footer(theme: UITheme, *, paused: bool, interactive: bool) -> RenderableType:
    if not interactive:
        return Text("Ctrl-C to quit", style="muted", justify="center")
    keys = [
        ("q", "quit"),
        ("p", "resume" if paused else "pause"),
        ("r", "reset"),
        ("t", "theme"),
        ("s", "sort"),
    ]
    parts: list[tuple[str, str]] = []
    for key, label in keys:
        parts.append((f" {key} ", "accent"))
        parts.append((f"{label}  ", "muted"))
    return Text.assemble(*parts, justify="center")


def build_dashboard(
    config: MonitorConfig,
    state: ConnectionState,
    detail: str,
    snapshot: StoreSnapshot,
    rates: dict[str, TopicRate],
    sys_metrics: SysMetrics,
    theme: UITheme,
    *,
    paused: bool = False,
    interactive: bool = True,
) -> RenderableType:
    """Compose the full dashboard as a single renderable."""
    header = render_header(config, state, detail, snapshot, theme)
    topics = render_topics_table(snapshot, rates, config, theme)
    footer = render_footer(theme, paused=paused, interactive=interactive)

    body: RenderableType
    if config.track_broker:
        columns = Table.grid(expand=True)
        columns.add_column(ratio=2)
        columns.add_column(ratio=5)
        columns.add_row(render_broker_panel(sys_metrics, theme), topics)
        body = columns
    else:
        body = topics

    return Group(header, body, footer)


def render_browse_table(
    topic: str,
    records: list[PayloadRecord],
    theme: UITheme,
    *,
    max_rows: int = 25,
    preview_len: int = 200,
) -> Panel:
    """A tail-style view of recent payloads for one topic (newest first)."""
    table = Table(
        box=theme.box,
        border_style=theme.border_style,
        header_style="table.header",
        expand=True,
        row_styles=["table.row"],
    )
    table.add_column("time", no_wrap=True)
    table.add_column("size", justify="right", no_wrap=True)
    table.add_column("payload", ratio=1, overflow="ellipsis")

    for rec in reversed(records[-max_rows:]):
        ts = datetime.fromtimestamp(rec.timestamp).strftime("%H:%M:%S.%f")[:-3]
        table.add_row(
            ts,
            format_bytes(rec.size),
            payload_preview(rec.payload, preview_len),
        )
    body: RenderableType = (
        table if records else Align.center(Text("waiting for messages…", style="muted"))
    )
    return Panel(
        body,
        title=f"[title]browse[/title] [value]{topic}[/value]",
        subtitle=f"[muted]{len(records)} retained[/muted]",
        box=theme.box,
        border_style=theme.border_style,
    )
