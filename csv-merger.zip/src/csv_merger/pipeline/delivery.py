"""Delivery strategies for merged pipeline output.

The runner produces one merged file per batch. *How* that file gets to
its consumer is configurable: today there are two strategies.

* :class:`HttpDelivery` — PUTs the file to a configured URL with an
  ``Idempotency-Key`` header. Retries 5xx and transport failures.
* :class:`ShareDelivery` — copies the file to a network-share folder
  atomically, then publishes an MQTT notification with file metadata
  as headers/properties. The notification's delivery is best-effort
  (logged on failure but does not undo the file delivery, per the
  agreed commit-ordering rule).

Both strategies implement the :class:`Delivery` protocol so the runner
calls a single ``deliver(...)`` regardless of which one is configured.

Failure semantics:

* Delivery raises :class:`TransientError` for retryable failures
  (5xx, connection refused, ENOSPC, etc.). The runner's retry policy
  handles re-attempts on the next tick and quarantines after N
  consecutive failures.
* Delivery raises :class:`PermanentError` for failures that won't
  succeed on retry (4xx other than 408/429, malformed config). The
  runner records a batch failure but does NOT auto-quarantine in
  fewer attempts — quarantine is purely attempt-count based.
* :class:`ShareDelivery` does NOT raise if the MQTT notification fails
  after the file has been written to the share. The commit point is
  file-on-share. Failed MQTT publishes are logged and reported via
  the return value (see :class:`DeliveryResult`).
"""

from __future__ import annotations

import logging
import os
import shutil
import socket
import ssl
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from csv_merger.pipeline._errors import PermanentError, TransientError
from csv_merger.pipeline.config import (
    MqttConfig,
    PipelineConfig,
    PublishConfig,
    ShareConfig,
)
from csv_merger.pipeline.outbox import OutboxManifest
from csv_merger.pipeline.retry import with_retry
from csv_merger.pipeline.transport import publish_file

logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------- #
# Result type                                                                 #
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class DeliveryResult:
    """Outcome of a delivery attempt.

    Attributes:
        delivered: ``True`` if the file reached its destination (HTTP
            2xx, or share write committed atomically). The runner
            treats this as the commit point for the batch.
        notification_sent: For strategies that issue a follow-up
            notification (e.g. MQTT). ``None`` if the strategy has no
            notification step. ``True`` on success, ``False`` if the
            notification failed (the file is still delivered).
        notification_error: Error message if ``notification_sent`` is
            ``False``.
    """

    delivered: bool
    notification_sent: bool | None = None
    notification_error: str | None = None


# --------------------------------------------------------------------------- #
# Protocol                                                                    #
# --------------------------------------------------------------------------- #


class Delivery(Protocol):
    """Strategy interface for delivering a merged file to its consumer.

    Implementations are constructed once per pipeline run via
    :func:`build_delivery` and re-used for any pending outbox files
    plus the current run's batch.
    """

    def deliver(
        self,
        file: Path,
        manifest: OutboxManifest,
        idempotency_key: str,
    ) -> DeliveryResult:
        """Deliver ``file`` to the configured destination.

        Args:
            file: Local outbox file to deliver.
            manifest: The outbox manifest describing the batch. Used
                for notification metadata (file name, hash, run_id,
                source_files count).
            idempotency_key: A stable identifier for this delivery
                attempt — consumers can de-duplicate retries. Use the
                full batch signature.

        Returns:
            A :class:`DeliveryResult`.

        Raises:
            TransientError: retryable failure (will count toward
                quarantine if it persists).
            PermanentError: non-retryable failure (4xx, config error).
        """
        ...


# --------------------------------------------------------------------------- #
# HTTP delivery                                                               #
# --------------------------------------------------------------------------- #


class HttpDelivery:
    """Deliver via HTTP PUT to a configured URL.

    Behaviour is the original publish path lifted into a strategy
    class. The runner used to call :func:`publish_file` directly; now
    it calls ``HttpDelivery.deliver(...)`` instead.
    """

    def __init__(self, config: PublishConfig) -> None:
        self._config = config

    def deliver(
        self,
        file: Path,
        manifest: OutboxManifest,
        idempotency_key: str,
    ) -> DeliveryResult:
        publish_file(
            file,
            self._config.url,
            idempotency_key=idempotency_key,
            max_attempts=self._config.max_attempts,
            base_delay=self._config.base_delay_seconds,
            max_delay=self._config.max_delay_seconds,
            connect_timeout=self._config.connect_timeout_seconds,
            read_timeout=self._config.read_timeout_seconds,
        )
        # HTTP delivery has no follow-up notification; notification_sent
        # stays None to distinguish "no notification step" from
        # "notification step ran".
        return DeliveryResult(delivered=True, notification_sent=None)


# --------------------------------------------------------------------------- #
# Share delivery                                                              #
# --------------------------------------------------------------------------- #


class ShareDelivery:
    """Deliver to a network-share folder, then notify via MQTT.

    Atomicity: copy to ``destination/<name>.tmp``, fsync, rename to
    ``destination/<name>``. A crash before rename leaves a ``.tmp``
    file on the share (consumer ignores). A crash after rename means
    the file is delivered but MQTT may not be — the next tick will
    NOT re-deliver because the file is in ``outbox/sent`` once the
    delivery returns. If MQTT visibility matters more than file
    delivery, the consumer should scan the share as a backstop.

    Retry: file write is retried via the :mod:`retry` helper on
    ``OSError``. MQTT publish is retried within :meth:`_notify`. MQTT
    failure does NOT roll back the file delivery.
    """

    def __init__(
        self,
        share_config: ShareConfig,
        mqtt_config: MqttConfig,
    ) -> None:
        self._share = share_config
        self._mqtt = mqtt_config

    def deliver(
        self,
        file: Path,
        manifest: OutboxManifest,
        idempotency_key: str,
    ) -> DeliveryResult:
        delivered_path = self._write_to_share(file)

        # Commit point: file is on the share. Anything below this
        # point is best-effort. If MQTT fails, we log and report it
        # via the result but do not raise — undoing the file delivery
        # would create worse problems than a missed notification.
        try:
            self._notify(delivered_path, manifest, idempotency_key)
        except Exception as exc:
            # Note: notify already has internal retry. Reaching here
            # means retries exhausted.
            logger.error(
                "share delivery succeeded but MQTT notify failed for %s: %s",
                delivered_path.name,
                exc,
            )
            return DeliveryResult(
                delivered=True,
                notification_sent=False,
                notification_error=f"{type(exc).__name__}: {exc}",
            )

        return DeliveryResult(delivered=True, notification_sent=True)

    # ------------------------------------------------------------------ #
    # Share write                                                        #
    # ------------------------------------------------------------------ #

    def _write_to_share(self, source: Path) -> Path:
        """Atomically copy ``source`` to the configured destination.

        Returns the final path on the share. Retries transient OS
        errors per :class:`ShareConfig.max_attempts`.
        """
        destination_dir = self._share.destination
        destination = destination_dir / source.name

        def attempt() -> Path:
            return _atomic_copy_to_share(source, destination)

        return with_retry(
            attempt,
            max_attempts=self._share.max_attempts,
            base_delay=self._share.base_delay_seconds,
            max_delay=self._share.max_delay_seconds,
        )

    # ------------------------------------------------------------------ #
    # MQTT notify                                                        #
    # ------------------------------------------------------------------ #

    def _notify(
        self,
        delivered_path: Path,
        manifest: OutboxManifest,
        idempotency_key: str,
    ) -> None:
        """Publish an MQTT notification with file metadata.

        The payload is a UTF-8 JSON document carrying the same
        information the consumer would otherwise glean from the
        manifest sidecar. The MQTT v5 client lets us include user
        properties as proper headers; for v3 clients (paho >=1.6) we
        still publish the same data inside the JSON payload, so
        consumers don't need to depend on MQTT v5 features.
        """
        payload = _build_notification_payload(
            delivered_path, manifest, idempotency_key
        )

        def attempt() -> None:
            _publish_mqtt(self._mqtt, payload)

        with_retry(
            attempt,
            max_attempts=self._mqtt.max_attempts,
            base_delay=self._mqtt.base_delay_seconds,
            max_delay=self._mqtt.max_delay_seconds,
        )


# --------------------------------------------------------------------------- #
# Factory                                                                     #
# --------------------------------------------------------------------------- #


def build_delivery(config: PipelineConfig) -> Delivery:
    """Construct the delivery strategy selected by config.

    Validation (mode is known, mode-required sections present) is
    performed by :class:`PipelineConfig.__post_init__`; by the time we
    reach here, the config is sound.
    """
    if config.delivery.mode == "http":
        return HttpDelivery(config.publish)
    if config.delivery.mode == "share":
        return ShareDelivery(config.share, config.mqtt)
    # Should be unreachable thanks to PipelineConfig validation.
    raise PermanentError(  # pragma: no cover
        f"unknown delivery mode: {config.delivery.mode}"
    )


# --------------------------------------------------------------------------- #
# Internal helpers                                                            #
# --------------------------------------------------------------------------- #


def _atomic_copy_to_share(source: Path, destination: Path) -> Path:
    """Copy a single file to ``destination`` atomically, size-verified.

    Pattern: write to ``destination.tmp``, fsync, rename. Same as the
    transport fetch path, just with a different source/dest pair.

    Raises:
        PermanentError: source vanished.
        TransientError: any other OSError (network blip, ENOSPC,
            permission flap). Retried by :class:`ShareDelivery`.
    """
    try:
        source_stat = source.stat()
    except FileNotFoundError as exc:
        raise PermanentError(f"source vanished: {source}") from exc
    except OSError as exc:
        raise TransientError(f"cannot stat {source}: {exc}") from exc

    expected_size = source_stat.st_size

    # Make sure the share folder exists. mkdir on a non-existent
    # network share fails with a clear error rather than silently
    # creating a local-only path.
    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise TransientError(
            f"cannot ensure destination dir {destination.parent}: {exc}"
        ) from exc

    tmp_fd, tmp_name = tempfile.mkstemp(
        prefix=f".{destination.name}.",
        suffix=".tmp",
        dir=str(destination.parent),
    )
    tmp_path = Path(tmp_name)
    os.close(tmp_fd)

    try:
        try:
            shutil.copyfile(source, tmp_path)
        except FileNotFoundError as exc:
            raise PermanentError(
                f"source vanished mid-copy: {source}"
            ) from exc
        except (OSError, shutil.SameFileError) as exc:
            raise TransientError(
                f"copy to share failed: {source} -> {tmp_path}: {exc}"
            ) from exc

        actual_size = tmp_path.stat().st_size
        if actual_size != expected_size:
            raise TransientError(
                f"size mismatch on share write: "
                f"expected {expected_size}, got {actual_size}"
            )

        with tmp_path.open("rb+") as fh:
            os.fsync(fh.fileno())

        try:
            os.replace(tmp_path, destination)
        except OSError as exc:
            raise TransientError(
                f"rename to {destination} failed: {exc}"
            ) from exc
    except BaseException:
        try:
            tmp_path.unlink()
        except FileNotFoundError:
            pass
        raise

    logger.info(
        "share delivery: %s -> %s (%d bytes)",
        source.name,
        destination,
        expected_size,
    )
    return destination


def _build_notification_payload(
    delivered_path: Path,
    manifest: OutboxManifest,
    idempotency_key: str,
) -> bytes:
    """Build the JSON notification payload.

    Schema deliberately small — consumers shouldn't depend on a large
    fluctuating envelope. Keys:

    * ``schema_version`` (int) — bump on incompatible changes.
    * ``idempotency_key`` (str) — full batch signature, for dedup.
    * ``file`` (object) — name and absolute path on the share.
    * ``batch`` (object) — manifest-derived metadata.
    """
    import json
    payload = {
        "schema_version": 1,
        "idempotency_key": idempotency_key,
        "file": {
            "name": delivered_path.name,
            "path": str(delivered_path),
        },
        "batch": {
            "signature": manifest.batch_signature,
            "run_id": manifest.run_id,
            "source_file_count": len(manifest.source_files),
        },
    }
    return json.dumps(payload, sort_keys=True).encode("utf-8")


def _publish_mqtt(config: MqttConfig, payload: bytes) -> None:
    """Publish ``payload`` to the configured MQTT topic.

    Connection is one-shot: connect, publish, disconnect. We do not
    keep a long-lived client because the pipeline is short-lived
    (one process per tick) and reusing a stale connection across
    process restarts has no benefit.

    Raises:
        TransientError: connection or publish failure.
    """
    # Import inside the function so HTTP-mode deployments don't pay
    # the import cost (and so missing paho-mqtt produces a clearer
    # error than ModuleNotFoundError at module-import time).
    try:
        import paho.mqtt.client as mqtt
    except ImportError as exc:  # pragma: no cover — packaging error
        raise TransientError(
            f"paho-mqtt not installed: {exc}"
        ) from exc

    client_id = config.client_id or ""
    client = mqtt.Client(client_id=client_id, clean_session=True)

    if config.username:
        client.username_pw_set(config.username, config.password or None)

    if config.use_tls:
        client.tls_set_context(ssl.create_default_context())

    try:
        client.connect(
            config.broker_host,
            config.broker_port,
            keepalive=int(config.connect_timeout_seconds * 2),
        )
    except (OSError, socket.gaierror) as exc:
        raise TransientError(
            f"MQTT connect to {config.broker_host}:{config.broker_port} "
            f"failed: {exc}"
        ) from exc

    # The loop_start/loop_stop pair lets paho process network I/O in
    # a background thread, including the PUBACK for QoS 1.
    client.loop_start()
    try:
        info = client.publish(
            config.topic,
            payload=payload,
            qos=config.qos,
            retain=config.retain,
        )
        # Wait for the publish to be sent (or the QoS 1 PUBACK).
        try:
            info.wait_for_publish(timeout=config.publish_timeout_seconds)
        except (ValueError, RuntimeError) as exc:
            raise TransientError(
                f"MQTT publish timed out or failed: {exc}"
            ) from exc

        if info.rc != mqtt.MQTT_ERR_SUCCESS:
            raise TransientError(
                f"MQTT publish failed with rc={info.rc}"
            )
    finally:
        try:
            client.loop_stop()
        except Exception:  # pragma: no cover — defensive
            pass
        try:
            client.disconnect()
        except Exception:  # pragma: no cover — defensive
            pass
    logger.debug(
        "MQTT notify published to %s (qos=%d, %d bytes)",
        config.topic,
        config.qos,
        len(payload),
    )
