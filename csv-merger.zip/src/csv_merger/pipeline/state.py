"""Postgres-backed pipeline state.

The state store is the resilience anchor for the pipeline. It persists:

* Every run, with its overall status and any error.
* Every step within a run, with its duration and status.
* Every source file successfully processed (path + content hash), so
  the next run can skip it.
* Every failed batch with its attempt count, supporting the quarantine
  policy.
* Every alert sent, backing per-category rate limiting.

Design choices worth flagging:

* **Postgres, single shared instance.** All pipeline instances write
  to one shared database. The ``pipeline_instance_id`` column on
  every table tags each row with the host that wrote it, so
  dashboards and reports can filter/group by instance.
* **One connection per process.** No pooling needed — the runner is
  single-threaded for state operations. The connect cost (~50ms) is
  negligible at the 2-minute tick cadence.
* **Autocommit mode.** We manage transactions explicitly with
  ``with conn.transaction():`` where atomicity matters (bulk
  ``mark_processed``); everything else is single-statement.
* **Step timing via context manager.** ``with state.step(run_id, "fetch"):``
  records start/end/duration with no manual bookkeeping at call sites.
* **Timestamps stored as TIMESTAMPTZ.** Returned to Python as
  ISO-8601 strings (with the ``+00:00`` suffix) so the public shape
  matches what the previous SQLite backend returned. Reporting code
  and downstream consumers see no difference.

The schema is created idempotently at construction time via
``CREATE TABLE IF NOT EXISTS``. There is no migration system yet;
if the schema ever changes, the deployment process handles it (drop
and recreate, or write a migration script).
"""

from __future__ import annotations

import hashlib
import logging
import time
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Iterator

import psycopg
from psycopg.rows import dict_row

from csv_merger.pipeline._errors import StateError

logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------- #
# Schema                                                                      #
# --------------------------------------------------------------------------- #


_SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    run_id               BIGSERIAL PRIMARY KEY,
    pipeline_instance_id TEXT NOT NULL DEFAULT 'default',
    started_at           TIMESTAMPTZ NOT NULL,
    finished_at          TIMESTAMPTZ,
    status               TEXT NOT NULL,
    batch_signature      TEXT,
    error_text           TEXT
);

CREATE TABLE IF NOT EXISTS run_steps (
    run_id               BIGINT NOT NULL,
    pipeline_instance_id TEXT NOT NULL DEFAULT 'default',
    step_name            TEXT NOT NULL,
    started_at           TIMESTAMPTZ NOT NULL,
    finished_at          TIMESTAMPTZ,
    duration_ms          BIGINT,
    status               TEXT NOT NULL,
    error_text           TEXT,
    PRIMARY KEY (run_id, step_name),
    FOREIGN KEY (run_id) REFERENCES runs(run_id)
);

CREATE TABLE IF NOT EXISTS processed_files (
    source_path          TEXT NOT NULL,
    content_hash         TEXT NOT NULL,
    run_id               BIGINT NOT NULL,
    pipeline_instance_id TEXT NOT NULL DEFAULT 'default',
    processed_at         TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (source_path, content_hash),
    FOREIGN KEY (run_id) REFERENCES runs(run_id)
);

CREATE TABLE IF NOT EXISTS failed_batches (
    batch_signature      TEXT PRIMARY KEY,
    pipeline_instance_id TEXT NOT NULL DEFAULT 'default',
    first_failure_at     TIMESTAMPTZ NOT NULL,
    last_failure_at      TIMESTAMPTZ NOT NULL,
    attempt_count        INTEGER NOT NULL,
    last_error           TEXT,
    status               TEXT NOT NULL
);

-- alert_history backs the rate-limit decision in alerting.py.
-- Categories: 'quarantine' | 'catastrophic'. One row per send.
CREATE TABLE IF NOT EXISTS alert_history (
    alert_id             BIGSERIAL PRIMARY KEY,
    pipeline_instance_id TEXT NOT NULL DEFAULT 'default',
    category             TEXT NOT NULL,
    sent_at              TIMESTAMPTZ NOT NULL,
    subject              TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_runs_status_started
    ON runs(status, started_at);
CREATE INDEX IF NOT EXISTS idx_runs_batch_sig
    ON runs(batch_signature);
CREATE INDEX IF NOT EXISTS idx_runs_instance
    ON runs(pipeline_instance_id);
CREATE INDEX IF NOT EXISTS idx_processed_files_run
    ON processed_files(run_id);
CREATE INDEX IF NOT EXISTS idx_alert_history_cat_time
    ON alert_history(category, sent_at);
"""

# Run status values.
RUN_STATUS_RUNNING = "running"
RUN_STATUS_SUCCESS = "success"
RUN_STATUS_FAILED = "failed"

# Step status values.
STEP_STATUS_SUCCESS = "success"
STEP_STATUS_FAILED = "failed"
STEP_STATUS_SKIPPED = "skipped"

# Batch status values.
BATCH_STATUS_RETRYING = "retrying"
BATCH_STATUS_QUARANTINED = "quarantined"


# --------------------------------------------------------------------------- #
# Public types                                                                #
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class RunRecord:
    """A row from the ``runs`` table, for reporting."""

    run_id: int
    started_at: str
    finished_at: str | None
    status: str
    batch_signature: str | None
    error_text: str | None


@dataclass(frozen=True)
class StepRecord:
    """A row from the ``run_steps`` table, for reporting."""

    run_id: int
    step_name: str
    started_at: str
    finished_at: str | None
    duration_ms: int | None
    status: str
    error_text: str | None


@dataclass(frozen=True)
class FailedBatchRecord:
    """A row from the ``failed_batches`` table."""

    batch_signature: str
    first_failure_at: str
    last_failure_at: str
    attempt_count: int
    last_error: str | None
    status: str


# --------------------------------------------------------------------------- #
# Batch signatures                                                            #
# --------------------------------------------------------------------------- #


def compute_batch_signature(files: Iterable[tuple[str, str]]) -> str:
    """Compute a deterministic signature for a batch of ``(path, hash)`` tuples.

    Order-independent: the same set of files always produces the same
    signature regardless of iteration order. Used as the key in
    :class:`failed_batches` and as the identity of an outbox file.
    """
    sorted_pairs = sorted(files)
    hasher = hashlib.sha256()
    for path, content_hash in sorted_pairs:
        hasher.update(path.encode("utf-8"))
        hasher.update(b"\x00")
        hasher.update(content_hash.encode("utf-8"))
        hasher.update(b"\x00")
    return hasher.hexdigest()


def compute_file_hash(path: Path, *, chunk_size: int = 65536) -> str:
    """Return the SHA-256 of a file's contents as a hex string."""
    hasher = hashlib.sha256()
    with path.open("rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            hasher.update(chunk)
    return hasher.hexdigest()


# --------------------------------------------------------------------------- #
# StateStore                                                                  #
# --------------------------------------------------------------------------- #


class StateStore:
    """Postgres-backed pipeline state.

    Construct with a psycopg conninfo string (built by
    :meth:`StateConfig.conninfo`). The connection is opened in
    autocommit mode; explicit transactions are used only where
    atomicity across multiple statements matters.

    The optional ``instance_id`` parameter tags every row this store
    inserts with the running pipeline's identity. This is used by
    batch 2 for multi-host filtering/reporting; batch 1 defaults it
    to ``"default"`` so tables can be shared across future upgrades
    without a schema migration.
    """

    def __init__(
        self,
        conninfo: str,
        *,
        instance_id: str = "default",
    ) -> None:
        self._conninfo = conninfo
        self._instance_id = instance_id
        try:
            self._conn = psycopg.connect(
                conninfo,
                autocommit=True,
                row_factory=dict_row,
            )
        except psycopg.Error as exc:
            raise StateError(f"cannot open state DB: {exc}") from exc

        self._apply_schema()

    def close(self) -> None:
        """Close the underlying connection. Idempotent."""
        try:
            self._conn.close()
        except psycopg.Error:
            pass

    def __enter__(self) -> "StateStore":
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()

    # ------------------------------------------------------------------ #
    # Setup                                                              #
    # ------------------------------------------------------------------ #

    def _apply_schema(self) -> None:
        """Create tables and indexes idempotently."""
        try:
            with self._conn.cursor() as cur:
                cur.execute(_SCHEMA)
        except psycopg.Error as exc:
            raise StateError(f"schema setup failed: {exc}") from exc

    # ------------------------------------------------------------------ #
    # Low-level execute helper                                            #
    # ------------------------------------------------------------------ #

    def execute(
        self,
        sql: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> None:
        """Execute a single statement. Exposed for the runner's skipped-step
        helper, which patches a step row's status after the timing
        context manager exits. Not intended for general use."""
        with self._conn.cursor() as cur:
            cur.execute(sql, params)

    # ------------------------------------------------------------------ #
    # Run lifecycle                                                      #
    # ------------------------------------------------------------------ #

    def start_run(self) -> int:
        """Insert a new ``runs`` row and return its ID."""
        now = _utc_now()
        with self._conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO runs
                    (started_at, status, pipeline_instance_id)
                VALUES (%s, %s, %s)
                RETURNING run_id
                """,
                (now, RUN_STATUS_RUNNING, self._instance_id),
            )
            row = cur.fetchone()
        if row is None:  # pragma: no cover — RETURNING always fires
            raise StateError("INSERT into runs did not return a run_id")
        run_id = int(row["run_id"])
        logger.debug("started run %d at %s", run_id, now)
        return run_id

    def finish_run(
        self,
        run_id: int,
        *,
        status: str,
        error_text: str | None = None,
        batch_signature: str | None = None,
    ) -> None:
        """Mark a run finished with its terminal status.

        ``batch_signature`` may be set after the run started, once we
        know which files we attempted. ``None`` leaves it unchanged.
        """
        now = _utc_now()
        with self._conn.cursor() as cur:
            if batch_signature is None:
                cur.execute(
                    """
                    UPDATE runs
                       SET finished_at = %s, status = %s, error_text = %s
                     WHERE run_id = %s
                    """,
                    (now, status, error_text, run_id),
                )
            else:
                cur.execute(
                    """
                    UPDATE runs
                       SET finished_at = %s, status = %s, error_text = %s,
                           batch_signature = %s
                     WHERE run_id = %s
                    """,
                    (now, status, error_text, batch_signature, run_id),
                )

    # ------------------------------------------------------------------ #
    # Step timing                                                        #
    # ------------------------------------------------------------------ #

    @contextmanager
    def step(
        self,
        run_id: int,
        step_name: str,
    ) -> Iterator[None]:
        """Time a step and record it in the ``run_steps`` table.

        On exit:
        * success → records status ``success``.
        * exception → records status ``failed`` with the exception text,
          then re-raises.
        """
        started_at = _utc_now()
        start = time.monotonic()
        with self._conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO run_steps
                    (run_id, step_name, started_at, status,
                     pipeline_instance_id)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (
                    run_id, step_name, started_at,
                    RUN_STATUS_RUNNING, self._instance_id,
                ),
            )
        try:
            yield
        except BaseException as exc:
            duration_ms = int((time.monotonic() - start) * 1000)
            with self._conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE run_steps
                       SET finished_at = %s, duration_ms = %s,
                           status = %s, error_text = %s
                     WHERE run_id = %s AND step_name = %s
                    """,
                    (
                        _utc_now(),
                        duration_ms,
                        STEP_STATUS_FAILED,
                        f"{type(exc).__name__}: {exc}",
                        run_id,
                        step_name,
                    ),
                )
            raise
        else:
            duration_ms = int((time.monotonic() - start) * 1000)
            with self._conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE run_steps
                       SET finished_at = %s, duration_ms = %s, status = %s
                     WHERE run_id = %s AND step_name = %s
                    """,
                    (
                        _utc_now(),
                        duration_ms,
                        STEP_STATUS_SUCCESS,
                        run_id,
                        step_name,
                    ),
                )

    # ------------------------------------------------------------------ #
    # processed_files                                                    #
    # ------------------------------------------------------------------ #

    def is_processed(self, source_path: str, content_hash: str) -> bool:
        """Return ``True`` if this exact ``(path, hash)`` has been processed."""
        with self._conn.cursor() as cur:
            cur.execute(
                """
                SELECT 1 FROM processed_files
                 WHERE source_path = %s AND content_hash = %s
                """,
                (source_path, content_hash),
            )
            row = cur.fetchone()
        return row is not None

    def mark_processed(
        self,
        run_id: int,
        files: Iterable[tuple[str, str]],
    ) -> int:
        """Insert ``(source_path, content_hash)`` rows for the given run.

        Wrapped in a transaction so the batch is recorded atomically:
        either every file is marked processed or none is.

        Returns the number of rows inserted. ``ON CONFLICT DO NOTHING``
        means re-marking an already-processed file is a no-op.
        """
        rows = list(files)
        if not rows:
            return 0
        now = _utc_now()
        # psycopg 3 executemany doesn't reliably report rowcount for
        # ON CONFLICT DO NOTHING; we count with a SELECT-then-INSERT
        # pattern via INSERT ... RETURNING which does. Since we care
        # about the count (for logging), use RETURNING.
        params = [
            (path, h, run_id, self._instance_id, now)
            for path, h in rows
        ]
        with self._conn.transaction():
            with self._conn.cursor() as cur:
                total_inserted = 0
                for p in params:
                    cur.execute(
                        """
                        INSERT INTO processed_files
                            (source_path, content_hash, run_id,
                             pipeline_instance_id, processed_at)
                        VALUES (%s, %s, %s, %s, %s)
                        ON CONFLICT (source_path, content_hash) DO NOTHING
                        RETURNING 1
                        """,
                        p,
                    )
                    if cur.fetchone() is not None:
                        total_inserted += 1
        return total_inserted

    # ------------------------------------------------------------------ #
    # failed_batches                                                     #
    # ------------------------------------------------------------------ #

    def record_batch_failure(
        self,
        batch_signature: str,
        *,
        max_attempts: int,
        error_text: str | None = None,
    ) -> int:
        """Record a failure for ``batch_signature`` and return the new count.

        If ``attempt_count`` reaches ``max_attempts``, the batch's
        status is updated to ``quarantined``. The caller decides what to
        do with that (typically: alert).
        """
        now = _utc_now()
        with self._conn.cursor() as cur:
            cur.execute(
                "SELECT attempt_count FROM failed_batches "
                "WHERE batch_signature = %s",
                (batch_signature,),
            )
            existing = cur.fetchone()

            if existing is None:
                cur.execute(
                    """
                    INSERT INTO failed_batches
                        (batch_signature, pipeline_instance_id,
                         first_failure_at, last_failure_at,
                         attempt_count, last_error, status)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        batch_signature, self._instance_id,
                        now, now,
                        1, error_text, BATCH_STATUS_RETRYING,
                    ),
                )
                return 1

            new_count = int(existing["attempt_count"]) + 1
            status = (
                BATCH_STATUS_QUARANTINED
                if new_count >= max_attempts
                else BATCH_STATUS_RETRYING
            )
            cur.execute(
                """
                UPDATE failed_batches
                   SET last_failure_at = %s, attempt_count = %s,
                       last_error = %s, status = %s
                 WHERE batch_signature = %s
                """,
                (now, new_count, error_text, status, batch_signature),
            )
            return new_count

    def is_batch_quarantined(self, batch_signature: str) -> bool:
        """Return ``True`` if this batch has been quarantined."""
        with self._conn.cursor() as cur:
            cur.execute(
                """
                SELECT status FROM failed_batches
                 WHERE batch_signature = %s AND status = %s
                """,
                (batch_signature, BATCH_STATUS_QUARANTINED),
            )
            row = cur.fetchone()
        return row is not None

    def clear_batch_failure(self, batch_signature: str) -> None:
        """Delete a row from ``failed_batches`` (e.g. on retry success)."""
        with self._conn.cursor() as cur:
            cur.execute(
                "DELETE FROM failed_batches WHERE batch_signature = %s",
                (batch_signature,),
            )

    # ------------------------------------------------------------------ #
    # Reporting queries                                                  #
    # ------------------------------------------------------------------ #

    def recent_runs(self, limit: int = 10) -> list[RunRecord]:
        """Return the most recent ``limit`` runs, newest first."""
        with self._conn.cursor() as cur:
            cur.execute(
                """
                SELECT run_id, started_at, finished_at, status,
                       batch_signature, error_text
                  FROM runs
                 ORDER BY run_id DESC
                 LIMIT %s
                """,
                (limit,),
            )
            rows = cur.fetchall()
        return [_row_to_run(r) for r in rows]

    def steps_for_run(self, run_id: int) -> list[StepRecord]:
        """Return all step records for a given run, in start order."""
        with self._conn.cursor() as cur:
            cur.execute(
                """
                SELECT run_id, step_name, started_at, finished_at,
                       duration_ms, status, error_text
                  FROM run_steps
                 WHERE run_id = %s
                 ORDER BY started_at
                """,
                (run_id,),
            )
            rows = cur.fetchall()
        return [_row_to_step(r) for r in rows]

    def quarantined_batches(self) -> list[FailedBatchRecord]:
        """Return all batches currently in ``quarantined`` status."""
        with self._conn.cursor() as cur:
            cur.execute(
                """
                SELECT batch_signature, first_failure_at, last_failure_at,
                       attempt_count, last_error, status
                  FROM failed_batches
                 WHERE status = %s
                 ORDER BY last_failure_at DESC
                """,
                (BATCH_STATUS_QUARANTINED,),
            )
            rows = cur.fetchall()
        return [_row_to_failed_batch(r) for r in rows]

    # ------------------------------------------------------------------ #
    # alert_history                                                      #
    # ------------------------------------------------------------------ #

    def seconds_since_last_alert(self, category: str) -> float | None:
        """Return seconds elapsed since the last alert in ``category``.

        Returns ``None`` if no alert in this category has ever been
        recorded. The alerting module uses this for its rate-limit
        decision.
        """
        with self._conn.cursor() as cur:
            cur.execute(
                """
                SELECT sent_at FROM alert_history
                 WHERE category = %s
                 ORDER BY alert_id DESC
                 LIMIT 1
                """,
                (category,),
            )
            row = cur.fetchone()
        if row is None:
            return None
        sent_at = row["sent_at"]
        if not isinstance(sent_at, datetime):
            return None
        if sent_at.tzinfo is None:
            sent_at = sent_at.replace(tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        return max(0.0, (now - sent_at).total_seconds())

    def record_alert_sent(self, category: str, subject: str) -> None:
        """Insert a row into ``alert_history`` after a successful send.

        The caller decides whether to record before or after the actual
        SMTP send. We recommend after — duplicate alerts on crash-mid-
        send are better than missed alerts on crash-after-record.
        """
        with self._conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO alert_history
                    (category, sent_at, subject, pipeline_instance_id)
                VALUES (%s, %s, %s, %s)
                """,
                (category, _utc_now(), subject, self._instance_id),
            )


# --------------------------------------------------------------------------- #
# Helpers                                                                     #
# --------------------------------------------------------------------------- #


def _utc_now() -> datetime:
    """UTC now with seconds precision (no microseconds).

    Microseconds add noise without helping when scanning logs by eye.
    Postgres stores TIMESTAMPTZ with microsecond precision natively;
    we round down at write time for consistency with the previous
    SQLite backend, which stored ISO strings truncated to seconds.
    """
    return datetime.now(timezone.utc).replace(microsecond=0)


def _fmt_ts(value: Any) -> str | None:
    """Format a Postgres TIMESTAMPTZ value as an ISO-8601 string.

    Returns ``None`` if the input is falsy (matches the previous
    behavior for nullable timestamp columns).
    """
    if value is None:
        return None
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        result: str = value.isoformat()
        return result
    return str(value)


def _row_to_run(row: dict[str, Any]) -> RunRecord:
    return RunRecord(
        run_id=int(row["run_id"]),
        started_at=_fmt_ts(row["started_at"]) or "",
        finished_at=_fmt_ts(row["finished_at"]),
        status=row["status"],
        batch_signature=row["batch_signature"],
        error_text=row["error_text"],
    )


def _row_to_step(row: dict[str, Any]) -> StepRecord:
    return StepRecord(
        run_id=int(row["run_id"]),
        step_name=row["step_name"],
        started_at=_fmt_ts(row["started_at"]) or "",
        finished_at=_fmt_ts(row["finished_at"]),
        duration_ms=(
            int(row["duration_ms"])
            if row["duration_ms"] is not None
            else None
        ),
        status=row["status"],
        error_text=row["error_text"],
    )


def _row_to_failed_batch(row: dict[str, Any]) -> FailedBatchRecord:
    return FailedBatchRecord(
        batch_signature=row["batch_signature"],
        first_failure_at=_fmt_ts(row["first_failure_at"]) or "",
        last_failure_at=_fmt_ts(row["last_failure_at"]) or "",
        attempt_count=int(row["attempt_count"]),
        last_error=row["last_error"],
        status=row["status"],
    )
