"""Integration tests for csv_merger.pipeline.runner.

These tests run the full pipeline against:

* A tempdir that simulates the source folder (with real sample batch
  and record files copied in).
* A stdlib ``http.server`` running in a background thread, simulating
  the publish endpoint.
* A patched ``_smtp_send`` so alert emails don't try to reach a real
  SMTP server.

The runner's contract is "never raise for operational conditions" — we
verify that by reading the :class:`RunResult` rather than catching
exceptions.
"""

from __future__ import annotations

import shutil
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Callable
from unittest.mock import patch

from csv_merger.pipeline.config import (
    EmailConfig,
    FetchConfig,
    FoldersConfig,
    OutboxConfig,
    PipelineConfig,
    PublishConfig,
    QuiescenceConfig,
    RetryPolicyConfig,
    StateConfig,
)
from csv_merger.pipeline.locking import FileLock
from csv_merger.pipeline.outbox import list_pending, manifest_path_for
from csv_merger.pipeline.runner import run_pipeline
from tests.pipeline._pg import PostgresTestCase
from csv_merger.pipeline.state import (
    RUN_STATUS_FAILED,
    RUN_STATUS_SUCCESS,
    STEP_STATUS_SKIPPED,
    StateStore,
    compute_batch_signature,
    compute_file_hash,
)
from tests._helpers import SAMPLE_DIR


def _count(conninfo: str, table: str) -> int:
    """Return ``COUNT(*)`` from ``table`` in the given schema.

    Used by tests that want to check the effects of a pipeline run
    against the state DB — the runner is a black box; this pokes at
    the tables it wrote.
    """
    import psycopg
    with psycopg.connect(conninfo, autocommit=True) as conn:
        with conn.cursor() as cur:
            cur.execute(f"SELECT COUNT(*) FROM {table}")
            row = cur.fetchone()
    assert row is not None
    return int(row[0])


# --------------------------------------------------------------------------- #
# HTTP fake                                                                   #
# --------------------------------------------------------------------------- #


class _RecordingHandler(BaseHTTPRequestHandler):
    """Records every request and returns a configured status sequence."""

    received_requests: list[tuple[str, dict, bytes]] = []
    status_sequence: list[int] = []

    def do_PUT(self) -> None:  # noqa: N802
        self._handle()

    def do_POST(self) -> None:  # noqa: N802
        self._handle()

    def _handle(self) -> None:
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length) if length else b""
        self.received_requests.append(
            (self.path, dict(self.headers), body)
        )
        status = (
            self.status_sequence.pop(0)
            if self.status_sequence
            else 200
        )
        self.send_response(status)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def log_message(self, format: str, *args: object) -> None:
        pass  # silence per-request stderr


def _start_server(
    status_sequence: list[int] | None = None,
) -> tuple[HTTPServer, str, Callable[[], None]]:
    _RecordingHandler.received_requests = []
    _RecordingHandler.status_sequence = list(status_sequence or [])
    server = HTTPServer(("127.0.0.1", 0), _RecordingHandler)
    host, port = server.server_address
    url = f"http://{host}:{port}/upload"
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    def stop() -> None:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)

    return server, url, stop


# --------------------------------------------------------------------------- #
# Test scaffolding                                                            #
# --------------------------------------------------------------------------- #


def _build_config(
    tmp: Path,
    publish_url: str,
    *,
    conninfo: str,
) -> PipelineConfig:
    """Construct a PipelineConfig pointing at subdirectories under `tmp`.

    ``conninfo`` is a Postgres DSN string (with ``options=-c search_path=...``
    baked in by the PostgresTestCase fixture) — we decompose the small
    number of fields StateConfig cares about from it.
    """
    folders = FoldersConfig(
        source=tmp / "source",
        staging=tmp / "staging",
        fetched=tmp / "fetched",
        outbox_pending=tmp / "outbox" / "pending",
        outbox_sent=tmp / "outbox" / "sent",
        dead_letter=tmp / "dead_letter",
    )
    state = _state_config_from_conninfo(
        conninfo, lock_path=tmp / "state" / "pipeline.lock"
    )
    return PipelineConfig(
        folders=folders,
        state=state,
        publish=PublishConfig(
            url=publish_url,
            max_attempts=2,           # fail fast in tests
            base_delay_seconds=0.01,
            max_delay_seconds=0.05,
            connect_timeout_seconds=2.0,
            read_timeout_seconds=2.0,
        ),
        email=EmailConfig(
            smtp_host="smtp.test.invalid",
            smtp_port=587,
            from_address="pipeline@test.invalid",
            to_addresses=("ops@test.invalid",),
            rate_limit_per_hour=10,   # high so test alerts aren't suppressed
        ),
        quiescence=QuiescenceConfig(
            quiet_seconds=0,          # don't wait in tests
            max_wait_seconds=2,
            poll_interval_seconds=1,
        ),
        fetch=FetchConfig(parallel_workers=4),
        retry_policy=RetryPolicyConfig(max_attempts_per_batch=3),
        outbox=OutboxConfig(sent_retention_days=7),
    )


def _state_config_from_conninfo(
    conninfo: str, *, lock_path: Path,
) -> StateConfig:
    """Parse a psycopg conninfo string into a StateConfig.

    Extracts host, port, dbname, user, sslmode, and options (which
    carries our per-test ``search_path``). Password is not passed
    through — tests against local Postgres use trust auth.
    """
    import psycopg.conninfo
    parsed = psycopg.conninfo.conninfo_to_dict(conninfo)
    return StateConfig(
        lock_path=lock_path,
        pg_host=parsed.get("host", "localhost"),
        pg_port=int(parsed.get("port", 5432)),
        pg_database=parsed.get("dbname", "csv_merger"),
        pg_user=parsed.get("user", "csv_merger"),
        pg_sslmode=parsed.get("sslmode", "prefer"),
        pg_options=parsed.get("options", ""),
    )


def _seed_source(source: Path, file_names: list[str]) -> None:
    """Copy named files from sample_data/ into the source folder."""
    source.mkdir(parents=True, exist_ok=True)
    for name in file_names:
        shutil.copy(SAMPLE_DIR / name, source / name)


def _all_samples() -> list[str]:
    """All sample batch + record file names."""
    return sorted(
        p.name for p in SAMPLE_DIR.iterdir()
        if p.is_file() and (p.name.startswith("batch-")
                            or p.name.startswith("record-"))
    )


# --------------------------------------------------------------------------- #
# Tests                                                                       #
# --------------------------------------------------------------------------- #


class HappyPathTests(PostgresTestCase):
    def test_full_pipeline_run_succeeds(self) -> None:
        _, url, stop = _start_server()
        try:
            with TemporaryDirectory() as tmp:
                tmp_path = Path(tmp)
                config = _build_config(tmp_path, url, conninfo=self.conninfo)
                _seed_source(config.folders.source, _all_samples())

                with patch(
                    "csv_merger.pipeline.alerting._smtp_send",
                ):
                    result = run_pipeline(config)

                # Outcome
                self.assertEqual(result.status, RUN_STATUS_SUCCESS)
                self.assertIsNotNone(result.batch_signature)
                self.assertGreater(result.files_processed, 0)
                self.assertFalse(result.skipped_lock_held)
                self.assertFalse(result.skipped_quarantined)
                self.assertIsNone(result.error)

                # The HTTP fake received exactly one PUT
                self.assertEqual(
                    len(_RecordingHandler.received_requests), 1
                )
                path, headers, body = _RecordingHandler.received_requests[0]
                self.assertEqual(path, "/upload")
                # Body should be the merged output (non-empty)
                self.assertGreater(len(body), 0)
                # Idempotency-Key should be the batch signature
                self.assertEqual(
                    headers.get("Idempotency-Key"),
                    result.batch_signature,
                )

                # Outbox/sent should contain the file + manifest
                sent_files = sorted(config.folders.outbox_sent.iterdir())
                self.assertEqual(len(sent_files), 2)  # data + manifest

                # Pending should be empty
                self.assertEqual(
                    list_pending(config.folders.outbox_pending), []
                )

                # State should record the files as processed
                row_count = _count(self.conninfo, "processed_files")
                self.assertEqual(row_count, result.files_processed)
        finally:
            stop()


class LockHeldTests(PostgresTestCase):
    def test_lock_held_returns_skipped_without_recording_run(self) -> None:
        _, url, stop = _start_server()
        try:
            with TemporaryDirectory() as tmp:
                tmp_path = Path(tmp)
                config = _build_config(tmp_path, url, conninfo=self.conninfo)
                _seed_source(config.folders.source, _all_samples())

                # Hold the lock from another "process" (just another
                # FileLock instance in the same process).
                config.state.lock_path.parent.mkdir(
                    parents=True, exist_ok=True
                )
                holder = FileLock(config.state.lock_path)
                holder.acquire()
                try:
                    with patch(
                        "csv_merger.pipeline.alerting._smtp_send",
                    ):
                        result = run_pipeline(config)
                finally:
                    holder.release()

                self.assertTrue(result.skipped_lock_held)
                self.assertIsNone(result.run_id)
                # No run should have been recorded (the runner never
                # opened the state store because the lock was held).
                # We don't COUNT(*) here because the schema may not
                # even have the runs table yet — this test's isolated
                # Postgres schema was created by setUp, but the
                # runner exited before applying its own schema.
                # The absence of result.run_id is the assertion.
        finally:
            stop()


class NoNewFilesTests(PostgresTestCase):
    def test_empty_source_records_skipped_steps(self) -> None:
        _, url, stop = _start_server()
        try:
            with TemporaryDirectory() as tmp:
                tmp_path = Path(tmp)
                config = _build_config(tmp_path, url, conninfo=self.conninfo)
                config.folders.source.mkdir(parents=True)
                # No source files

                with patch(
                    "csv_merger.pipeline.alerting._smtp_send",
                ):
                    result = run_pipeline(config)

                self.assertEqual(result.status, RUN_STATUS_SUCCESS)
                self.assertEqual(result.files_processed, 0)
                # No HTTP request should have been made.
                self.assertEqual(
                    len(_RecordingHandler.received_requests), 0
                )

                # Steps after discover should be recorded as skipped.
                state = StateStore(self.conninfo)
                try:
                    steps = state.steps_for_run(result.run_id)
                    skipped = {
                        s.step_name for s in steps
                        if s.status == STEP_STATUS_SKIPPED
                    }
                    self.assertIn("fetch", skipped)
                    self.assertIn("publish", skipped)
                    self.assertIn("mark_processed", skipped)
                finally:
                    state.close()
        finally:
            stop()


class DrainBlocksNewBatchTests(PostgresTestCase):
    def test_pending_file_that_fails_to_publish_blocks_new_batch(self) -> None:
        """If draining the outbox leaves anything pending, defer the new batch."""
        # Server will reject everything with 500 → pending file stays.
        _, url, stop = _start_server(status_sequence=[500] * 10)
        try:
            with TemporaryDirectory() as tmp:
                tmp_path = Path(tmp)
                config = _build_config(tmp_path, url, conninfo=self.conninfo)
                _seed_source(config.folders.source, _all_samples())

                # Pre-seed outbox/pending with a fake file + manifest.
                config.folders.outbox_pending.mkdir(parents=True)
                pending_file = config.folders.outbox_pending / (
                    f"99-{'a' * 16}.txt"
                )
                pending_file.write_text("prior merged output")
                manifest_path = manifest_path_for(pending_file)
                manifest_path.write_text(
                    '{"batch_signature": "' + ("a" * 64) + '", '
                    '"run_id": 99, '
                    '"source_files": []}'
                )

                with patch(
                    "csv_merger.pipeline.alerting._smtp_send",
                ):
                    result = run_pipeline(config)

                # Run should have failed due to incomplete drain
                self.assertEqual(result.status, RUN_STATUS_FAILED)
                self.assertIn("outbox drain", result.error or "")

                # No new files should have been processed
                self.assertEqual(result.files_processed, 0)

                # The pending file should still be there (publish failed)
                self.assertTrue(pending_file.exists())
        finally:
            stop()


class QuarantineTests(PostgresTestCase):
    def test_quarantined_batch_is_skipped(self) -> None:
        """Pre-existing quarantine record causes run to skip without work."""
        _, url, stop = _start_server()
        try:
            with TemporaryDirectory() as tmp:
                tmp_path = Path(tmp)
                config = _build_config(tmp_path, url, conninfo=self.conninfo)
                _seed_source(config.folders.source, _all_samples())

                # Compute the batch signature that the runner will see
                # and pre-record it as quarantined.
                hashes = []
                for name in _all_samples():
                    path = config.folders.source / name
                    hashes.append((str(path), compute_file_hash(path)))
                expected_sig = compute_batch_signature(hashes)

                # Pre-populate state with a quarantine record.
                state = StateStore(self.conninfo)
                try:
                    for _ in range(3):
                        state.record_batch_failure(
                            expected_sig,
                            max_attempts=3,
                            error_text="pre-existing",
                        )
                    self.assertTrue(
                        state.is_batch_quarantined(expected_sig)
                    )
                finally:
                    state.close()

                with patch(
                    "csv_merger.pipeline.alerting._smtp_send",
                ):
                    result = run_pipeline(config)

                self.assertTrue(result.skipped_quarantined)
                self.assertEqual(result.status, RUN_STATUS_FAILED)
                # No HTTP request — work was skipped
                self.assertEqual(
                    len(_RecordingHandler.received_requests), 0
                )
        finally:
            stop()

    def test_batch_failure_increments_and_quarantines_on_nth_attempt(
        self,
    ) -> None:
        """After N consecutive failures, batch is quarantined and alert sent.

        Note: once run 1 writes the batch to outbox/pending, runs 2+ see
        it as a drain failure (not a new-batch failure). The drain path
        increments the same batch counter and fires the quarantine alert
        when the threshold is reached.
        """
        # Server rejects with 500; max_attempts_per_batch=3.
        _, url, stop = _start_server(status_sequence=[500] * 100)
        try:
            with TemporaryDirectory() as tmp:
                tmp_path = Path(tmp)
                config = _build_config(tmp_path, url, conninfo=self.conninfo)
                _seed_source(config.folders.source, _all_samples())

                alerts_captured: list[tuple[str, str]] = []

                def fake_smtp_send(cfg, msg) -> None:
                    alerts_captured.append((msg["Subject"], msg.get_content()))

                with patch(
                    "csv_merger.pipeline.alerting._smtp_send",
                    side_effect=fake_smtp_send,
                ):
                    # Three runs in a row, each fails publish (run 1 as
                    # new-batch failure, runs 2-3 as drain failures).
                    result1 = run_pipeline(config)
                    result2 = run_pipeline(config)
                    result3 = run_pipeline(config)

                self.assertEqual(result1.status, RUN_STATUS_FAILED)
                self.assertEqual(result2.status, RUN_STATUS_FAILED)
                self.assertEqual(result3.status, RUN_STATUS_FAILED)

                # The batch should be quarantined after 3 attempts —
                # verify via state DB (not via RunResult, since drain-
                # path quarantines don't set quarantined_now).
                state = StateStore(self.conninfo)
                try:
                    quar = state.quarantined_batches()
                    self.assertEqual(len(quar), 1)
                    self.assertEqual(quar[0].attempt_count, 3)
                finally:
                    state.close()

                # Alert should have been sent (once) when the threshold
                # was crossed on the 3rd attempt.
                self.assertEqual(len(alerts_captured), 1)
                self.assertIn("quarantined", alerts_captured[0][0].lower())
        finally:
            stop()


class EmergencyAlertTests(PostgresTestCase):
    def test_state_db_init_failure_triggers_emergency_alert(self) -> None:
        """If state DB cannot be opened, alert via emergency path."""
        _, url, stop = _start_server()
        try:
            with TemporaryDirectory() as tmp:
                tmp_path = Path(tmp)
                config = _build_config(tmp_path, url, conninfo=self.conninfo)

                # Sabotage the state DB: point at a Postgres host that
                # can't be reached. The runner should trip the "state
                # init failed" branch and fire the emergency alert.
                sabotaged_state = StateConfig(
                    lock_path=config.state.lock_path,
                    pg_host="nowhere.invalid",
                    pg_port=5432,
                    pg_database="x",
                    pg_user="x",
                    pg_sslmode="disable",
                    pg_connect_timeout=1,
                )
                # Reconstruct config with the bad state.
                sabotaged_config = PipelineConfig(
                    folders=config.folders,
                    state=sabotaged_state,
                    publish=config.publish,
                    email=config.email,
                    quiescence=config.quiescence,
                    fetch=config.fetch,
                    retry_policy=config.retry_policy,
                    outbox=config.outbox,
                )

                alerts_captured: list[str] = []

                def fake_smtp_send(cfg, msg) -> None:
                    alerts_captured.append(msg["Subject"])

                with patch(
                    "csv_merger.pipeline.alerting._smtp_send",
                    side_effect=fake_smtp_send,
                ):
                    result = run_pipeline(sabotaged_config)

                self.assertEqual(result.status, RUN_STATUS_FAILED)
                self.assertIsNotNone(result.error)
                self.assertIn("state", result.error)
                # Emergency alert path should have fired
                self.assertEqual(len(alerts_captured), 1)
                self.assertIn("catastrophic", alerts_captured[0].lower())
        finally:
            stop()


# --------------------------------------------------------------------------- #
# Share-mode integration                                                      #
# --------------------------------------------------------------------------- #


def _build_share_config(tmp: Path, *, conninfo: str) -> PipelineConfig:
    """Construct a share-mode PipelineConfig pointing at tempdirs."""
    from csv_merger.pipeline.config import (
        DeliveryConfig,
        MqttConfig,
        ShareConfig,
    )

    folders = FoldersConfig(
        source=tmp / "source",
        staging=tmp / "staging",
        fetched=tmp / "fetched",
        outbox_pending=tmp / "outbox" / "pending",
        outbox_sent=tmp / "outbox" / "sent",
        dead_letter=tmp / "dead_letter",
    )
    state = _state_config_from_conninfo(
        conninfo, lock_path=tmp / "state" / "pipeline.lock"
    )
    return PipelineConfig(
        folders=folders,
        state=state,
        share=ShareConfig(
            destination=tmp / "destination",
            max_attempts=2,
            base_delay_seconds=0.01,
            max_delay_seconds=0.05,
        ),
        mqtt=MqttConfig(
            broker_host="broker.test.invalid",
            broker_port=1883,
            topic="csv-merger/delivered",
            max_attempts=2,
            base_delay_seconds=0.01,
            max_delay_seconds=0.05,
        ),
        delivery=DeliveryConfig(mode="share"),
        email=EmailConfig(
            smtp_host="smtp.test.invalid",
            smtp_port=587,
            from_address="pipeline@test.invalid",
            to_addresses=("ops@test.invalid",),
            rate_limit_per_hour=10,
        ),
        quiescence=QuiescenceConfig(
            quiet_seconds=0,
            max_wait_seconds=2,
            poll_interval_seconds=1,
        ),
        fetch=FetchConfig(parallel_workers=4),
        retry_policy=RetryPolicyConfig(max_attempts_per_batch=3),
        outbox=OutboxConfig(sent_retention_days=7),
    )


class ShareModeTests(PostgresTestCase):
    def test_full_pipeline_share_mode_succeeds(self) -> None:
        """End-to-end share+MQTT: file lands on share, MQTT publishes once."""
        with TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            config = _build_share_config(tmp_path, conninfo=self.conninfo)
            _seed_source(config.folders.source, _all_samples())

            mqtt_payloads: list[bytes] = []

            def fake_mqtt_publish(cfg, payload) -> None:
                mqtt_payloads.append(payload)

            with patch(
                "csv_merger.pipeline.delivery._publish_mqtt",
                side_effect=fake_mqtt_publish,
            ), patch(
                "csv_merger.pipeline.alerting._smtp_send",
            ):
                result = run_pipeline(config)

            # Outcome
            self.assertEqual(result.status, RUN_STATUS_SUCCESS, msg=result.error)
            self.assertGreater(result.files_processed, 0)

            # File arrived on the share (with the outbox-style filename).
            share_files = list((tmp_path / "destination").iterdir())
            self.assertEqual(len(share_files), 1)
            self.assertTrue(share_files[0].name.endswith(".txt"))

            # MQTT published exactly once.
            self.assertEqual(len(mqtt_payloads), 1)
            import json
            payload = json.loads(mqtt_payloads[0].decode("utf-8"))
            self.assertEqual(payload["idempotency_key"], result.batch_signature)
            self.assertEqual(payload["batch"]["run_id"], result.run_id)

            # Outbox/sent has the data + manifest.
            sent = sorted(config.folders.outbox_sent.iterdir())
            self.assertEqual(len(sent), 2)

    def test_share_succeeds_but_mqtt_fails_run_still_succeeds(self) -> None:
        """Per the commit-ordering rule: MQTT failure doesn't fail the run."""
        with TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            config = _build_share_config(tmp_path, conninfo=self.conninfo)
            _seed_source(config.folders.source, _all_samples())

            from csv_merger.pipeline._errors import TransientError as TE

            with patch(
                "csv_merger.pipeline.delivery._publish_mqtt",
                side_effect=TE("broker down"),
            ), patch(
                "csv_merger.pipeline.alerting._smtp_send",
            ):
                result = run_pipeline(config)

            # The run still succeeded — the file is on the share.
            self.assertEqual(result.status, RUN_STATUS_SUCCESS, msg=result.error)
            share_files = list((tmp_path / "destination").iterdir())
            self.assertEqual(len(share_files), 1)


if __name__ == "__main__":
    unittest.main()
