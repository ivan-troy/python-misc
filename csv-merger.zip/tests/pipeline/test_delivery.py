"""Tests for csv_merger.pipeline.delivery."""

from __future__ import annotations

import json
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Callable
from unittest.mock import patch

from csv_merger.pipeline._errors import (
    ConfigError,
    PermanentError,
    TransientError,
)
from csv_merger.pipeline.config import (
    DeliveryConfig,
    EmailConfig,
    FetchConfig,
    FoldersConfig,
    MqttConfig,
    OutboxConfig,
    PipelineConfig,
    PublishConfig,
    QuiescenceConfig,
    RetryPolicyConfig,
    ShareConfig,
    StateConfig,
)
from csv_merger.pipeline.delivery import (
    HttpDelivery,
    ShareDelivery,
    _atomic_copy_to_share,
    _build_notification_payload,
    build_delivery,
)
from csv_merger.pipeline.outbox import OutboxManifest


# --------------------------------------------------------------------------- #
# Test fixtures                                                               #
# --------------------------------------------------------------------------- #


def _manifest(sig: str = "a" * 64, run_id: int = 7) -> OutboxManifest:
    return OutboxManifest(
        batch_signature=sig,
        run_id=run_id,
        source_files=(("/src/a.txt", "h1"), ("/src/b.txt", "h2")),
    )


def _share_config(destination: Path) -> ShareConfig:
    return ShareConfig(
        destination=destination,
        max_attempts=2,
        base_delay_seconds=0.01,
        max_delay_seconds=0.05,
    )


def _mqtt_config(host: str = "broker.test") -> MqttConfig:
    return MqttConfig(
        broker_host=host,
        broker_port=1883,
        topic="csv-merger/delivered",
        max_attempts=2,
        base_delay_seconds=0.01,
        max_delay_seconds=0.05,
    )


# --------------------------------------------------------------------------- #
# HTTP delivery — happy path against a real http.server                       #
# --------------------------------------------------------------------------- #


class _RecordingHandler(BaseHTTPRequestHandler):
    received_requests: list[tuple[str, dict, bytes]] = []

    def do_PUT(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length) if length else b""
        self.received_requests.append((self.path, dict(self.headers), body))
        self.send_response(200)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def log_message(self, format: str, *args: object) -> None:
        pass


def _start_server() -> tuple[HTTPServer, str, Callable[[], None]]:
    _RecordingHandler.received_requests = []
    server = HTTPServer(("127.0.0.1", 0), _RecordingHandler)
    host, port = server.server_address
    url = f"http://{host}:{port}/upload"
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    def stop() -> None:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)

    return server, url, stop


class HttpDeliveryTests(unittest.TestCase):
    def test_delivers_file_and_returns_result_with_no_notification(self) -> None:
        _, url, stop = _start_server()
        try:
            with TemporaryDirectory() as tmp:
                payload = Path(tmp) / "merged.txt"
                payload.write_bytes(b"hello")
                delivery = HttpDelivery(
                    PublishConfig(
                        url=url,
                        max_attempts=2,
                        base_delay_seconds=0.01,
                        max_delay_seconds=0.05,
                    )
                )
                result = delivery.deliver(payload, _manifest(), "abc123")
            self.assertTrue(result.delivered)
            # HttpDelivery has no notification step.
            self.assertIsNone(result.notification_sent)
            self.assertEqual(len(_RecordingHandler.received_requests), 1)
        finally:
            stop()


# --------------------------------------------------------------------------- #
# Share write — file system semantics                                         #
# --------------------------------------------------------------------------- #


class AtomicCopyTests(unittest.TestCase):
    def test_happy_path_copies_with_no_tmp_debris(self) -> None:
        with TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            src = tmp_path / "merged.txt"
            src.write_bytes(b"content")
            dest_dir = tmp_path / "share"

            dest_path = _atomic_copy_to_share(src, dest_dir / src.name)

            self.assertTrue(dest_path.exists())
            self.assertEqual(dest_path.read_bytes(), b"content")
            tmp_files = [p for p in dest_dir.iterdir() if p.name.startswith(".")]
            self.assertEqual(tmp_files, [])

    def test_missing_source_is_permanent(self) -> None:
        with TemporaryDirectory() as tmp:
            dest = Path(tmp) / "out" / "f.txt"
            with self.assertRaises(PermanentError):
                _atomic_copy_to_share(Path(tmp) / "missing.txt", dest)

    def test_replaces_existing_destination(self) -> None:
        """If the destination already exists, atomic rename overwrites it."""
        with TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            src = tmp_path / "src.txt"
            src.write_bytes(b"new")
            dest_dir = tmp_path / "share"
            dest_dir.mkdir()
            existing = dest_dir / "src.txt"
            existing.write_bytes(b"old")

            _atomic_copy_to_share(src, existing)

            self.assertEqual(existing.read_bytes(), b"new")


# --------------------------------------------------------------------------- #
# Share delivery — wires together share write + MQTT notify                   #
# --------------------------------------------------------------------------- #


class ShareDeliveryTests(unittest.TestCase):
    def test_happy_path_delivers_and_notifies(self) -> None:
        with TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            src = tmp_path / "merged.txt"
            src.write_bytes(b"content")
            share_dir = tmp_path / "share"

            published_payloads: list[bytes] = []

            def fake_publish(cfg, payload) -> None:
                published_payloads.append(payload)

            with patch(
                "csv_merger.pipeline.delivery._publish_mqtt",
                side_effect=fake_publish,
            ):
                delivery = ShareDelivery(
                    _share_config(share_dir),
                    _mqtt_config(),
                )
                result = delivery.deliver(src, _manifest(), "key123")

            self.assertTrue(result.delivered)
            self.assertTrue(result.notification_sent)
            self.assertIsNone(result.notification_error)
            # File arrived on the share.
            self.assertTrue((share_dir / "merged.txt").exists())
            # MQTT was called exactly once.
            self.assertEqual(len(published_payloads), 1)
            payload = json.loads(published_payloads[0].decode("utf-8"))
            self.assertEqual(payload["idempotency_key"], "key123")
            self.assertEqual(payload["file"]["name"], "merged.txt")
            self.assertEqual(payload["batch"]["run_id"], 7)
            self.assertEqual(payload["batch"]["source_file_count"], 2)

    def test_mqtt_failure_does_not_undo_file_delivery(self) -> None:
        """Commit point is file-on-share; MQTT failure is logged only."""
        with TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            src = tmp_path / "merged.txt"
            src.write_bytes(b"content")
            share_dir = tmp_path / "share"

            with patch(
                "csv_merger.pipeline.delivery._publish_mqtt",
                side_effect=TransientError("broker unreachable"),
            ):
                delivery = ShareDelivery(
                    _share_config(share_dir),
                    _mqtt_config(),
                )
                result = delivery.deliver(src, _manifest(), "key")

            # File is delivered ...
            self.assertTrue(result.delivered)
            self.assertTrue((share_dir / "merged.txt").exists())
            # ... but notification flag reflects the failure.
            self.assertFalse(result.notification_sent)
            self.assertIn("broker unreachable", result.notification_error)

    def test_share_write_failure_propagates(self) -> None:
        """If file delivery itself fails, the error propagates."""
        with TemporaryDirectory() as tmp:
            # Source doesn't exist → PermanentError from _atomic_copy.
            missing = Path(tmp) / "missing.txt"
            with patch(
                "csv_merger.pipeline.delivery._publish_mqtt",
            ) as mqtt:
                delivery = ShareDelivery(
                    _share_config(Path(tmp) / "share"),
                    _mqtt_config(),
                )
                with self.assertRaises(PermanentError):
                    delivery.deliver(missing, _manifest(), "k")

                # MQTT must not have been called — file never reached share.
                mqtt.assert_not_called()


# --------------------------------------------------------------------------- #
# Payload shape                                                               #
# --------------------------------------------------------------------------- #


class NotificationPayloadTests(unittest.TestCase):
    def test_payload_is_deterministic_json(self) -> None:
        payload = _build_notification_payload(
            Path("/share/abc.txt"),
            _manifest(sig="X" * 64, run_id=42),
            "idem-key",
        )
        # Deterministic: same input → same output (we sort keys).
        again = _build_notification_payload(
            Path("/share/abc.txt"),
            _manifest(sig="X" * 64, run_id=42),
            "idem-key",
        )
        self.assertEqual(payload, again)

    def test_payload_contains_expected_fields(self) -> None:
        payload = _build_notification_payload(
            Path("/share/abc.txt"),
            _manifest(sig="X" * 64, run_id=42),
            "idem-key",
        )
        data = json.loads(payload.decode("utf-8"))
        self.assertEqual(data["schema_version"], 1)
        self.assertEqual(data["idempotency_key"], "idem-key")
        self.assertEqual(data["file"]["name"], "abc.txt")
        self.assertEqual(data["batch"]["signature"], "X" * 64)
        self.assertEqual(data["batch"]["run_id"], 42)


# --------------------------------------------------------------------------- #
# Factory                                                                     #
# --------------------------------------------------------------------------- #


def _base_config(
    tmp: Path,
    mode: str,
    *,
    share_dest: Path | None = None,
    publish_url: str = "",
) -> PipelineConfig:
    folders = FoldersConfig(
        source=tmp / "source",
        staging=tmp / "staging",
        fetched=tmp / "fetched",
        outbox_pending=tmp / "outbox" / "pending",
        outbox_sent=tmp / "outbox" / "sent",
        dead_letter=tmp / "dead_letter",
    )
    state = StateConfig(
        lock_path=tmp / "state" / "pipeline.lock",
    )
    email = EmailConfig(
        smtp_host="smtp.test.invalid",
        smtp_port=587,
        from_address="p@test.invalid",
        to_addresses=("ops@test.invalid",),
    )

    publish = PublishConfig(url=publish_url)
    share = ShareConfig(destination=share_dest or Path())
    mqtt = MqttConfig(
        broker_host="broker.test" if mode == "share" else "",
        topic="csv-merger/delivered" if mode == "share" else "",
    )
    return PipelineConfig(
        folders=folders,
        state=state,
        publish=publish,
        share=share,
        mqtt=mqtt,
        delivery=DeliveryConfig(mode=mode),
        email=email,
        quiescence=QuiescenceConfig(),
        fetch=FetchConfig(),
        retry_policy=RetryPolicyConfig(),
        outbox=OutboxConfig(),
    )


class BuildDeliveryTests(unittest.TestCase):
    def test_http_mode_returns_http_delivery(self) -> None:
        with TemporaryDirectory() as tmp:
            cfg = _base_config(
                Path(tmp), "http", publish_url="https://example.com/ingest"
            )
            delivery = build_delivery(cfg)
            self.assertIsInstance(delivery, HttpDelivery)

    def test_share_mode_returns_share_delivery(self) -> None:
        with TemporaryDirectory() as tmp:
            cfg = _base_config(
                Path(tmp), "share", share_dest=Path(tmp) / "share"
            )
            delivery = build_delivery(cfg)
            self.assertIsInstance(delivery, ShareDelivery)

    def test_http_mode_with_empty_url_rejected_at_config(self) -> None:
        """Validation happens at PipelineConfig construction time."""
        with TemporaryDirectory() as tmp:
            with self.assertRaises(ConfigError):
                _base_config(Path(tmp), "http", publish_url="")

    def test_share_mode_with_no_destination_rejected_at_config(self) -> None:
        with TemporaryDirectory() as tmp:
            with self.assertRaises(ConfigError):
                # ShareConfig.destination defaults to Path() which is empty
                _base_config(Path(tmp), "share", share_dest=Path())


if __name__ == "__main__":
    unittest.main()
