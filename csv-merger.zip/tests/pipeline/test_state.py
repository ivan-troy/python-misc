"""Tests for csv_merger.pipeline.state (Postgres backend)."""

from __future__ import annotations

import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

import psycopg

from csv_merger.pipeline._errors import StateError
from csv_merger.pipeline.state import (
    RUN_STATUS_FAILED,
    RUN_STATUS_SUCCESS,
    STEP_STATUS_FAILED,
    STEP_STATUS_SUCCESS,
    StateStore,
    compute_batch_signature,
    compute_file_hash,
)

from tests.pipeline._pg import PostgresTestCase


def _count_rows(conninfo: str, table: str) -> int:
    """Helper that runs a raw COUNT(*) against the test schema.

    Used for the atomicity test where we want to verify the effects
    of `mark_processed` at the row level without going through the
    higher-level API.
    """
    with psycopg.connect(conninfo, autocommit=True) as conn:
        with conn.cursor() as cur:
            cur.execute(f"SELECT COUNT(*) FROM {table}")
            row = cur.fetchone()
    assert row is not None
    return int(row[0])


class SchemaSetupTests(PostgresTestCase):
    def test_fresh_db_creates_all_tables(self) -> None:
        store = StateStore(self.conninfo)
        try:
            with psycopg.connect(self.conninfo, autocommit=True) as conn:
                with conn.cursor() as cur:
                    # search_path is scoped to the test schema, so this
                    # returns only tables we created.
                    cur.execute(
                        "SELECT table_name FROM information_schema.tables "
                        "WHERE table_schema = current_schema()"
                    )
                    tables = {r[0] for r in cur.fetchall()}
            self.assertEqual(
                tables,
                {
                    "runs",
                    "run_steps",
                    "processed_files",
                    "failed_batches",
                    "alert_history",
                },
            )
        finally:
            store.close()

    def test_pipeline_instance_id_stored_on_runs(self) -> None:
        """The forward-compat column is populated on insert."""
        store = StateStore(self.conninfo, instance_id="host-alpha")
        try:
            run_id = store.start_run()
            with psycopg.connect(self.conninfo, autocommit=True) as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT pipeline_instance_id FROM runs "
                        "WHERE run_id = %s",
                        (run_id,),
                    )
                    row = cur.fetchone()
            self.assertIsNotNone(row)
            self.assertEqual(row[0], "host-alpha")
        finally:
            store.close()


class RunLifecycleTests(PostgresTestCase):
    def test_start_run_returns_increasing_ids(self) -> None:
        store = StateStore(self.conninfo)
        try:
            ids = [store.start_run() for _ in range(3)]
            self.assertEqual(ids, sorted(set(ids)))
        finally:
            store.close()

    def test_finish_run_records_status_and_signature(self) -> None:
        store = StateStore(self.conninfo)
        try:
            run_id = store.start_run()
            store.finish_run(
                run_id,
                status=RUN_STATUS_SUCCESS,
                batch_signature="sig",
            )
            runs = store.recent_runs()
            self.assertEqual(runs[0].status, RUN_STATUS_SUCCESS)
            self.assertEqual(runs[0].batch_signature, "sig")
        finally:
            store.close()

    def test_finish_run_records_error_on_failure(self) -> None:
        store = StateStore(self.conninfo)
        try:
            run_id = store.start_run()
            store.finish_run(
                run_id,
                status=RUN_STATUS_FAILED,
                error_text="boom",
            )
            runs = store.recent_runs()
            self.assertEqual(runs[0].status, RUN_STATUS_FAILED)
            self.assertEqual(runs[0].error_text, "boom")
        finally:
            store.close()


class StepTimingTests(PostgresTestCase):
    def test_successful_step_records_duration(self) -> None:
        store = StateStore(self.conninfo)
        try:
            run_id = store.start_run()
            with store.step(run_id, "fetch"):
                pass
            steps = store.steps_for_run(run_id)
            self.assertEqual(len(steps), 1)
            self.assertEqual(steps[0].step_name, "fetch")
            self.assertEqual(steps[0].status, STEP_STATUS_SUCCESS)
            self.assertIsNotNone(steps[0].duration_ms)
            self.assertGreaterEqual(steps[0].duration_ms, 0)
        finally:
            store.close()

    def test_failed_step_records_exception_and_reraises(self) -> None:
        store = StateStore(self.conninfo)
        try:
            run_id = store.start_run()
            with self.assertRaises(ValueError):
                with store.step(run_id, "merge"):
                    raise ValueError("bad data")
            steps = store.steps_for_run(run_id)
            self.assertEqual(steps[0].status, STEP_STATUS_FAILED)
            self.assertIn("ValueError", steps[0].error_text or "")
            self.assertIn("bad data", steps[0].error_text or "")
        finally:
            store.close()

    def test_steps_returned_in_start_order(self) -> None:
        store = StateStore(self.conninfo)
        try:
            run_id = store.start_run()
            for name in ("a", "b", "c"):
                with store.step(run_id, name):
                    pass
            steps = store.steps_for_run(run_id)
            self.assertEqual(
                [s.step_name for s in steps], ["a", "b", "c"]
            )
        finally:
            store.close()


class ProcessedFilesTests(PostgresTestCase):
    def test_mark_processed_then_is_processed_returns_true(self) -> None:
        store = StateStore(self.conninfo)
        try:
            run_id = store.start_run()
            store.mark_processed(run_id, [("a.txt", "h1")])
            self.assertTrue(store.is_processed("a.txt", "h1"))
        finally:
            store.close()

    def test_is_processed_distinguishes_hash(self) -> None:
        store = StateStore(self.conninfo)
        try:
            run_id = store.start_run()
            store.mark_processed(run_id, [("a.txt", "h1")])
            self.assertTrue(store.is_processed("a.txt", "h1"))
            self.assertFalse(store.is_processed("a.txt", "h2"))
        finally:
            store.close()

    def test_mark_processed_dedupes_via_conflict(self) -> None:
        """ON CONFLICT DO NOTHING → duplicate rows in one call yield one row."""
        store = StateStore(self.conninfo)
        try:
            run_id = store.start_run()
            store.mark_processed(
                run_id, [("a.txt", "h1"), ("a.txt", "h1")]
            )
        finally:
            store.close()
        self.assertEqual(_count_rows(self.conninfo, "processed_files"), 1)

    def test_empty_input_is_noop(self) -> None:
        store = StateStore(self.conninfo)
        try:
            run_id = store.start_run()
            self.assertEqual(store.mark_processed(run_id, []), 0)
        finally:
            store.close()


class FailedBatchTests(PostgresTestCase):
    def test_first_failure_creates_row(self) -> None:
        store = StateStore(self.conninfo)
        try:
            count = store.record_batch_failure(
                "sig", max_attempts=3, error_text="boom"
            )
            self.assertEqual(count, 1)
            self.assertFalse(store.is_batch_quarantined("sig"))
        finally:
            store.close()

    def test_repeated_failures_increment_count(self) -> None:
        store = StateStore(self.conninfo)
        try:
            self.assertEqual(
                store.record_batch_failure("sig", max_attempts=5), 1
            )
            self.assertEqual(
                store.record_batch_failure("sig", max_attempts=5), 2
            )
            self.assertEqual(
                store.record_batch_failure("sig", max_attempts=5), 3
            )
            self.assertFalse(store.is_batch_quarantined("sig"))
        finally:
            store.close()

    def test_reaching_max_attempts_quarantines(self) -> None:
        store = StateStore(self.conninfo)
        try:
            for _ in range(3):
                store.record_batch_failure("sig", max_attempts=3)
            self.assertTrue(store.is_batch_quarantined("sig"))
        finally:
            store.close()

    def test_clear_batch_failure_removes_row(self) -> None:
        store = StateStore(self.conninfo)
        try:
            store.record_batch_failure("sig", max_attempts=3)
            store.clear_batch_failure("sig")
            self.assertFalse(store.is_batch_quarantined("sig"))
            count = store.record_batch_failure("sig", max_attempts=3)
            self.assertEqual(count, 1)
        finally:
            store.close()

    def test_quarantined_batches_returns_only_quarantined(self) -> None:
        store = StateStore(self.conninfo)
        try:
            store.record_batch_failure("retrying", max_attempts=5)
            for _ in range(3):
                store.record_batch_failure("quarantined", max_attempts=3)
            quar = store.quarantined_batches()
            self.assertEqual(len(quar), 1)
            self.assertEqual(quar[0].batch_signature, "quarantined")
        finally:
            store.close()


class BatchSignatureTests(unittest.TestCase):
    """Pure functions — no DB access."""

    def test_signature_is_order_independent(self) -> None:
        a = compute_batch_signature([("a", "h1"), ("b", "h2")])
        b = compute_batch_signature([("b", "h2"), ("a", "h1")])
        self.assertEqual(a, b)

    def test_signature_differs_when_contents_differ(self) -> None:
        a = compute_batch_signature([("a", "h1"), ("b", "h2")])
        b = compute_batch_signature([("a", "h1"), ("b", "DIFFERENT")])
        self.assertNotEqual(a, b)

    def test_signature_differs_for_different_path(self) -> None:
        a = compute_batch_signature([("a", "h1")])
        b = compute_batch_signature([("DIFFERENT", "h1")])
        self.assertNotEqual(a, b)

    def test_empty_input_gives_consistent_hash(self) -> None:
        a = compute_batch_signature([])
        b = compute_batch_signature([])
        self.assertEqual(a, b)


class FileHashTests(unittest.TestCase):
    """Pure function — no DB access."""

    def test_known_content_hash(self) -> None:
        with TemporaryDirectory() as tmp:
            path = Path(tmp) / "f.txt"
            path.write_text("hello", encoding="utf-8")
            expected = (
                "2cf24dba5fb0a30e26e83b2ac5b9e29e"
                "1b161e5c1fa7425e73043362938b9824"
            )
            self.assertEqual(compute_file_hash(path), expected)


class AlertHistoryTests(PostgresTestCase):
    def test_no_alert_returns_none(self) -> None:
        store = StateStore(self.conninfo)
        try:
            self.assertIsNone(
                store.seconds_since_last_alert("quarantine")
            )
        finally:
            store.close()

    def test_recorded_alert_returns_recent_elapsed(self) -> None:
        store = StateStore(self.conninfo)
        try:
            store.record_alert_sent("quarantine", "Subj A")
            elapsed = store.seconds_since_last_alert("quarantine")
            self.assertIsNotNone(elapsed)
            self.assertGreaterEqual(elapsed, 0.0)
            self.assertLess(elapsed, 5.0)
        finally:
            store.close()

    def test_categories_are_independent(self) -> None:
        store = StateStore(self.conninfo)
        try:
            store.record_alert_sent("quarantine", "Q")
            self.assertIsNotNone(
                store.seconds_since_last_alert("quarantine")
            )
            self.assertIsNone(
                store.seconds_since_last_alert("catastrophic")
            )
        finally:
            store.close()


class ConstructionErrorsTests(unittest.TestCase):
    """Not derived from PostgresTestCase — we test the *failure* path."""

    def test_bad_conninfo_raises_state_error(self) -> None:
        with self.assertRaises(StateError):
            StateStore(
                "host=nowhere.invalid port=5432 dbname=x user=x "
                "connect_timeout=1"
            )


if __name__ == "__main__":
    unittest.main()
