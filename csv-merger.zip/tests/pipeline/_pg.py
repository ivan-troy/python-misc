"""Postgres test infrastructure: per-test schema isolation.

Every test that needs a state DB gets its own Postgres schema. All the
tables (``runs``, ``run_steps``, etc.) are created inside that schema
via ``search_path``, so tests can't step on each other. Schemas are
dropped in ``tearDown`` to keep the shared test DB tidy.

Configuration comes from the ``CSV_MERGER_TEST_DSN`` environment
variable. If it's not set, tests skip cleanly. Default developers can
point it at a local Postgres like::

    export CSV_MERGER_TEST_DSN="host=/tmp port=5432 dbname=csv_merger_test user=postgres"

CI systems set it to whatever they've provisioned.
"""

from __future__ import annotations

import os
import unittest
import uuid

import psycopg


TEST_DSN_ENV = "CSV_MERGER_TEST_DSN"


def require_postgres_dsn() -> str:
    """Return the base test DSN, or skip the test if not configured."""
    dsn = os.environ.get(TEST_DSN_ENV)
    if not dsn:
        raise unittest.SkipTest(
            f"{TEST_DSN_ENV} not set; skipping Postgres-backed tests"
        )
    return dsn


def create_test_schema(base_dsn: str) -> tuple[str, str]:
    """Create a fresh schema and return ``(conninfo_for_tests, schema_name)``.

    The returned conninfo has ``options='-c search_path=<schema>'``
    baked in so anything connecting with it operates inside that
    schema. The schema name is returned so ``drop_test_schema`` can
    clean up later.
    """
    schema = "test_" + uuid.uuid4().hex[:12]
    with psycopg.connect(base_dsn, autocommit=True) as admin:
        with admin.cursor() as cur:
            cur.execute(f'CREATE SCHEMA "{schema}"')
    conninfo = f"{base_dsn} options='-c search_path={schema}'"
    return conninfo, schema


def drop_test_schema(base_dsn: str, schema: str) -> None:
    """Drop the schema and everything in it. Safe to call more than once."""
    try:
        with psycopg.connect(base_dsn, autocommit=True) as admin:
            with admin.cursor() as cur:
                cur.execute(f'DROP SCHEMA IF EXISTS "{schema}" CASCADE')
    except psycopg.Error:
        # Best-effort cleanup; a failure here doesn't fail the test.
        pass


class PostgresTestCase(unittest.TestCase):
    """Base class that gives each test a fresh Postgres schema.

    Access ``self.conninfo`` in a test body to open a StateStore
    against the isolated schema. ``self.base_dsn`` is the un-scoped
    admin DSN in case a test needs to run a raw query.
    """

    base_dsn: str = ""
    conninfo: str = ""
    _schema: str = ""

    def setUp(self) -> None:
        super().setUp()
        self.base_dsn = require_postgres_dsn()
        self.conninfo, self._schema = create_test_schema(self.base_dsn)

    def tearDown(self) -> None:
        drop_test_schema(self.base_dsn, self._schema)
        super().tearDown()
