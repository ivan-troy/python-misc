#!/usr/bin/env bash
# Thin wrapper: scripts/run.sh dashboard --host localhost -t 'sensors/#'
set -euo pipefail
cd "$(dirname "$0")/.."
exec uv run mqtt-monitor "$@"
