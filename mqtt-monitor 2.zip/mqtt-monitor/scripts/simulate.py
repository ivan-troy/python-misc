#!/usr/bin/env python3
"""Publish synthetic MQTT traffic so you can watch the dashboard populate.

Usage:
    python scripts/simulate.py --host localhost --rate 20

Requires a reachable broker (e.g. a local Mosquitto, or test.mosquitto.org).
Purely a developer convenience; not part of the shipped package.
"""

from __future__ import annotations

import argparse
import json
import random
import time

import paho.mqtt.client as mqtt
from paho.mqtt.enums import CallbackAPIVersion

SENSORS = ["kitchen", "attic", "garage", "bedroom", "office", "garden"]
KINDS = ["temperature", "humidity", "pressure", "battery"]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--host", default="localhost")
    ap.add_argument("--port", type=int, default=1883)
    ap.add_argument("--rate", type=float, default=15.0, help="messages/second")
    ap.add_argument("--prefix", default="sim", help="root topic prefix")
    args = ap.parse_args()

    client = mqtt.Client(CallbackAPIVersion.VERSION2)
    client.connect(args.host, args.port, 60)
    client.loop_start()
    interval = 1.0 / max(0.1, args.rate)
    print(f"Publishing ~{args.rate:g} msg/s to {args.host}:{args.port} under {args.prefix}/…")
    try:
        while True:
            sensor = random.choice(SENSORS)
            kind = random.choice(KINDS)
            topic = f"{args.prefix}/{sensor}/{kind}"
            payload = json.dumps(
                {"value": round(random.uniform(0, 100), 2), "ts": time.time()}
            )
            client.publish(topic, payload, qos=random.choice([0, 0, 0, 1]))
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\nstopping")
    finally:
        client.loop_stop()
        client.disconnect()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
