#!/usr/bin/env bash
# One-shot environment setup using uv.
set -euo pipefail
cd "$(dirname "$0")/.."
command -v uv >/dev/null 2>&1 || { echo "Install uv first: https://docs.astral.sh/uv/"; exit 1; }
uv venv
uv pip install -e ".[dev]"
echo "✔ Environment ready. Try:  uv run mqtt-monitor themes"
