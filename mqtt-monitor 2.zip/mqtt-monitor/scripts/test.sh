#!/usr/bin/env bash
# Run the full quality gate: tests (+coverage), lint, types.
set -euo pipefail
cd "$(dirname "$0")/.."
uv run pytest --cov=mqtt_monitor --cov-report=term-missing
uv run ruff check .
uv run mypy
