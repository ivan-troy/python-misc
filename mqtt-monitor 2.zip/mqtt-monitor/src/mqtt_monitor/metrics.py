"""Metrics collection for MQTT traffic.

Two independent concerns live here:

* :class:`MetricsRegistry` accumulates *per-topic* statistics (message counts,
  byte volume, throughput and the most recent payload).  Brokers do not expose
  per-topic stats, so we derive them from the message stream itself.
* :class:`BrokerStats` parses the broker-wide ``$SYS`` tree that most brokers
  (Mosquitto, EMQX, HiveMQ, ...) publish.

Everything is written to be safe to update from the paho network thread while a
render thread reads immutable snapshots, so the two never contend on shared
mutable state beyond a short critical section.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Iterable
from dataclasses import dataclass, field, replace

# Exponential-moving-average weight for the instantaneous rate.  A small alpha
# favours stability (less jitter); a larger one reacts faster to bursts.
_RATE_ALPHA = 0.35


@dataclass(frozen=True, slots=True)
class TopicSnapshot:
    """Immutable view of a single topic's statistics, safe to hand to the UI."""

    topic: str
    messages: int
    total_bytes: int
    rate: float  # smoothed messages/second
    byte_rate: float  # smoothed bytes/second
    last_payload: bytes
    last_qos: int
    last_retain: bool
    first_seen: float
    last_seen: float

    @property
    def avg_bytes(self) -> float:
        return self.total_bytes / self.messages if self.messages else 0.0

    @property
    def age(self) -> float:
        """Seconds since the most recent message on this topic."""
        return max(0.0, time.time() - self.last_seen)


@dataclass(slots=True)
class _TopicState:
    """Mutable accumulator; never leaves the registry lock."""

    topic: str
    messages: int = 0
    total_bytes: int = 0
    last_payload: bytes = b""
    last_qos: int = 0
    last_retain: bool = False
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    rate: float = 0.0
    byte_rate: float = 0.0
    # Bookkeeping for rate deltas between ticks.
    _prev_messages: int = 0
    _prev_bytes: int = 0
    _prev_tick: float = field(default_factory=time.time)

    def snapshot(self) -> TopicSnapshot:
        return TopicSnapshot(
            topic=self.topic,
            messages=self.messages,
            total_bytes=self.total_bytes,
            rate=self.rate,
            byte_rate=self.byte_rate,
            last_payload=self.last_payload,
            last_qos=self.last_qos,
            last_retain=self.last_retain,
            first_seen=self.first_seen,
            last_seen=self.last_seen,
        )


SortKey = str  # one of: "rate", "messages", "bytes", "byte_rate", "topic", "recent"


class MetricsRegistry:
    """Thread-safe accumulator of per-topic statistics.

    The paho callback thread calls :meth:`record`; a periodic caller (usually the
    render loop) calls :meth:`tick` to refresh smoothed rates.  Readers call
    :meth:`snapshot` / :meth:`top` to obtain immutable data.
    """

    def __init__(self, *, max_payload_bytes: int = 4096) -> None:
        self._lock = threading.Lock()
        self._topics: dict[str, _TopicState] = {}
        self._max_payload = max_payload_bytes
        self._total_messages = 0
        self._total_bytes = 0
        self._started = time.time()

    # ------------------------------------------------------------------ writes
    def record(self, topic: str, payload: bytes, qos: int = 0, retain: bool = False) -> None:
        """Register one received message. Called from the network thread."""
        size = len(payload)
        stored = payload[: self._max_payload]
        now = time.time()
        with self._lock:
            state = self._topics.get(topic)
            if state is None:
                state = _TopicState(topic=topic, first_seen=now)
                self._topics[topic] = state
            state.messages += 1
            state.total_bytes += size
            state.last_payload = stored
            state.last_qos = qos
            state.last_retain = retain
            state.last_seen = now
            self._total_messages += 1
            self._total_bytes += size

    def tick(self, now: float | None = None) -> None:
        """Recompute smoothed per-topic rates. Call at the UI refresh interval."""
        now = time.time() if now is None else now
        with self._lock:
            for state in self._topics.values():
                dt = now - state._prev_tick
                if dt <= 0:
                    # First tick for this topic, or a non-monotonic clock: just
                    # (re)establish the baseline without emitting a bogus rate.
                    state._prev_messages = state.messages
                    state._prev_bytes = state.total_bytes
                    state._prev_tick = now
                    continue
                inst_msg = (state.messages - state._prev_messages) / dt
                inst_byte = (state.total_bytes - state._prev_bytes) / dt
                state.rate = _ewma(state.rate, inst_msg)
                state.byte_rate = _ewma(state.byte_rate, inst_byte)
                state._prev_messages = state.messages
                state._prev_bytes = state.total_bytes
                state._prev_tick = now

    def reset(self) -> None:
        """Forget all collected topics (mirrors mqtt-stats' 'File -> New')."""
        with self._lock:
            self._topics.clear()
            self._total_messages = 0
            self._total_bytes = 0
            self._started = time.time()

    # ------------------------------------------------------------------- reads
    def snapshot(self) -> list[TopicSnapshot]:
        with self._lock:
            return [s.snapshot() for s in self._topics.values()]

    def top(self, key: SortKey = "rate", limit: int | None = None) -> list[TopicSnapshot]:
        """Return snapshots sorted by ``key`` (descending, except ``topic``)."""
        snaps = self.snapshot()
        snaps.sort(key=_sort_func(key), reverse=key != "topic")
        return snaps[:limit] if limit else snaps

    def get(self, topic: str) -> TopicSnapshot | None:
        with self._lock:
            state = self._topics.get(topic)
            return state.snapshot() if state else None

    @property
    def topic_count(self) -> int:
        with self._lock:
            return len(self._topics)

    @property
    def total_messages(self) -> int:
        with self._lock:
            return self._total_messages

    @property
    def total_bytes(self) -> int:
        with self._lock:
            return self._total_bytes

    @property
    def elapsed(self) -> float:
        return max(1e-9, time.time() - self._started)

    @property
    def overall_rate(self) -> float:
        """Average messages/second since collection started."""
        return self._total_messages / self.elapsed


def _ewma(previous: float, sample: float) -> float:
    if previous == 0.0:
        return sample
    return _RATE_ALPHA * sample + (1 - _RATE_ALPHA) * previous


def _sort_func(key: SortKey):
    mapping = {
        "rate": lambda s: s.rate,
        "byte_rate": lambda s: s.byte_rate,
        "messages": lambda s: s.messages,
        "bytes": lambda s: s.total_bytes,
        "recent": lambda s: s.last_seen,
        "topic": lambda s: s.topic,
    }
    if key not in mapping:
        raise ValueError(f"unknown sort key: {key!r} (choose from {sorted(mapping)})")
    return mapping[key]


# --------------------------------------------------------------------- broker
@dataclass
class BrokerStats:
    """Broker-wide statistics parsed from the ``$SYS`` topic tree.

    Only the raw string values are stored; typed/formatted access is provided by
    :mod:`mqtt_monitor.sys_topics`.  Kept deliberately dumb so it is trivial to
    test and never raises on an unfamiliar broker.
    """

    values: dict[str, str] = field(default_factory=dict)
    updated_at: float = field(default_factory=time.time)

    def update(self, topic: str, payload: bytes) -> None:
        try:
            self.values[topic] = payload.decode("utf-8", errors="replace").strip()
        except Exception:  # pragma: no cover - decode never raises with replace
            self.values[topic] = repr(payload)
        self.updated_at = time.time()

    def get(self, topic: str, default: str | None = None) -> str | None:
        return self.values.get(topic, default)

    def copy(self) -> BrokerStats:
        return replace(self, values=dict(self.values))

    def items(self) -> Iterable[tuple[str, str]]:
        return self.values.items()

    def __len__(self) -> int:
        return len(self.values)
