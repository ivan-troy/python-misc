"""Typed configuration objects.

:class:`ConnectionConfig` describes how to reach the broker; :class:`AppConfig`
adds presentation choices (theme, refresh rate, sort order).  Both validate on
construction so bad input fails fast with a clear message instead of surfacing
as an obscure paho error later.
"""

from __future__ import annotations

import os
import ssl
from dataclasses import dataclass, field

DEFAULT_PORT = 1883
DEFAULT_TLS_PORT = 8883
VALID_PROTOCOLS = ("3.1.1", "5")
VALID_SORT_KEYS = ("rate", "byte_rate", "messages", "bytes", "recent", "topic")


class ConfigError(ValueError):
    """Raised when a configuration value is invalid."""


@dataclass(slots=True)
class ConnectionConfig:
    """Everything required to open (and secure) a broker connection."""

    host: str = "localhost"
    port: int = DEFAULT_PORT
    keepalive: int = 60
    client_id: str = ""
    username: str | None = None
    password: str | None = None
    protocol: str = "5"
    transport: str = "tcp"  # "tcp" or "websockets"
    tls: bool = False
    tls_insecure: bool = False
    ca_certs: str | None = None

    def __post_init__(self) -> None:
        if not self.host:
            raise ConfigError("host must not be empty")
        if not 1 <= self.port <= 65535:
            raise ConfigError(f"port must be in 1..65535, got {self.port}")
        if self.keepalive < 5:
            raise ConfigError("keepalive must be >= 5 seconds")
        if self.protocol not in VALID_PROTOCOLS:
            raise ConfigError(
                f"protocol must be one of {VALID_PROTOCOLS}, got {self.protocol!r}"
            )
        if self.transport not in ("tcp", "websockets"):
            raise ConfigError("transport must be 'tcp' or 'websockets'")
        if self.password and not self.username:
            raise ConfigError("password supplied without a username")

    @property
    def tls_context(self) -> ssl.SSLContext | None:
        """Build an SSL context, or ``None`` when TLS is disabled."""
        if not self.tls:
            return None
        context = ssl.create_default_context(cafile=self.ca_certs)
        if self.tls_insecure:
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        return context

    @classmethod
    def from_env(cls, prefix: str = "MQTT_") -> ConnectionConfig:
        """Read defaults from ``MQTT_*`` environment variables (all optional)."""

        def env(name: str, default: str | None = None) -> str | None:
            return os.environ.get(f"{prefix}{name}", default)

        port = env("PORT")
        return cls(
            host=env("HOST", "localhost") or "localhost",
            port=int(port) if port else DEFAULT_PORT,
            username=env("USERNAME"),
            password=env("PASSWORD"),
            client_id=env("CLIENT_ID", "") or "",
            protocol=env("PROTOCOL", "5") or "5",
            tls=_as_bool(env("TLS")),
        )


@dataclass(slots=True)
class AppConfig:
    """Presentation and behaviour settings for the dashboard."""

    connection: ConnectionConfig = field(default_factory=ConnectionConfig)
    topic_filter: str = "#"
    qos: int = 0
    theme: str = "nord"
    refresh_hz: float = 4.0
    sort_key: str = "rate"
    top: int = 20
    subscribe_sys: bool = True
    max_payload_bytes: int = 4096

    def __post_init__(self) -> None:
        if not self.topic_filter:
            raise ConfigError("topic_filter must not be empty")
        if self.qos not in (0, 1, 2):
            raise ConfigError(f"qos must be 0, 1 or 2, got {self.qos}")
        if not 0.2 <= self.refresh_hz <= 30:
            raise ConfigError("refresh_hz must be between 0.2 and 30")
        if self.sort_key not in VALID_SORT_KEYS:
            raise ConfigError(
                f"sort_key must be one of {VALID_SORT_KEYS}, got {self.sort_key!r}"
            )
        if self.top < 1:
            raise ConfigError("top must be >= 1")

    @property
    def refresh_interval(self) -> float:
        return 1.0 / self.refresh_hz


def _as_bool(value: str | None) -> bool:
    return str(value).strip().lower() in ("1", "true", "yes", "on") if value else False
