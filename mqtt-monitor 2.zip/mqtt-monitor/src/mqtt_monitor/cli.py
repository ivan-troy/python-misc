"""Command-line interface.

Uses argparse (stdlib only) to keep the dependency footprint at exactly
``paho-mqtt`` + ``rich``.  Four subcommands cover the brief:

* ``dashboard`` — live broker ($SYS) + per-topic view (the default).
* ``browse``    — two-pane payload inspector for specific topics.
* ``themes``    — list / preview available themes.
* ``publish``   — publish test messages (handy for smoke-testing a broker).
"""

from __future__ import annotations

import argparse
import sys
import time
from collections.abc import Sequence

from . import __version__
from .config import AppConfig, ConfigError, ConnectionConfig
from .themes import DEFAULT_THEME, THEMES, theme_names


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mqtt-monitor",
        description="Lightweight, themeable terminal dashboard for MQTT brokers and topics.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command")

    conn = _connection_parser()
    view = _view_parser()

    p_dash = sub.add_parser(
        "dashboard",
        parents=[conn, view],
        help="live broker + per-topic dashboard (default)",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p_dash.set_defaults(func=_cmd_dashboard)

    p_browse = sub.add_parser(
        "browse",
        parents=[conn, view],
        help="inspect metrics and decoded payloads for topics",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p_browse.set_defaults(func=_cmd_browse)

    p_themes = sub.add_parser("themes", help="list available themes")
    p_themes.add_argument("--theme", help="preview a single theme by name")
    p_themes.set_defaults(func=_cmd_themes)

    p_pub = sub.add_parser(
        "publish",
        parents=[conn],
        help="publish one or more test messages",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p_pub.add_argument("topic", help="topic to publish to")
    p_pub.add_argument("message", nargs="?", default="hello", help="payload to send")
    p_pub.add_argument("--qos", type=int, choices=(0, 1, 2), default=0)
    p_pub.add_argument("--retain", action="store_true")
    p_pub.add_argument("--count", type=int, default=1, help="number of messages")
    p_pub.add_argument("--interval", type=float, default=0.5, help="seconds between messages")
    p_pub.set_defaults(func=_cmd_publish)

    return parser


def _connection_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(add_help=False)
    g = p.add_argument_group("connection")
    g.add_argument("-H", "--host", default="localhost", help="broker host")
    g.add_argument(
        "-p", "--port", type=int, default=0, help="broker port (default 1883, 8883 for TLS)"
    )
    g.add_argument("-u", "--username", default=None)
    g.add_argument("-P", "--password", default=None)
    g.add_argument("--client-id", default="", help="MQTT client id (auto if empty)")
    g.add_argument("--protocol", choices=("3.1.1", "5"), default="5")
    g.add_argument("--transport", choices=("tcp", "websockets"), default="tcp")
    g.add_argument("--keepalive", type=int, default=60)
    g.add_argument("--tls", action="store_true", help="enable TLS")
    g.add_argument("--tls-insecure", action="store_true", help="skip cert verification")
    g.add_argument("--ca-certs", default=None, help="path to CA bundle")
    return p


def _view_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(add_help=False)
    g = p.add_argument_group("view")
    g.add_argument(
        "-t", "--filter", dest="topic_filter", default="#", help="topic filter to monitor"
    )
    g.add_argument("--qos", type=int, choices=(0, 1, 2), default=0, help="subscription QoS")
    g.add_argument("--theme", choices=theme_names(), default=DEFAULT_THEME)
    g.add_argument("--refresh", type=float, default=4.0, help="refresh rate in Hz")
    g.add_argument(
        "--sort",
        dest="sort_key",
        choices=("rate", "byte_rate", "messages", "bytes", "recent", "topic"),
        default="rate",
    )
    g.add_argument("--top", type=int, default=20, help="max topics to display")
    g.add_argument("--no-sys", dest="subscribe_sys", action="store_false", help="skip $SYS")
    g.add_argument("--once", action="store_true", help="render one frame and exit (non-TTY safe)")
    g.add_argument("--duration", type=float, default=None, help="auto-exit after N seconds")
    return p


# ------------------------------------------------------------------- builders
def _connection_from_args(args: argparse.Namespace) -> ConnectionConfig:
    port = args.port or (8883 if args.tls else 1883)
    return ConnectionConfig(
        host=args.host,
        port=port,
        keepalive=args.keepalive,
        client_id=args.client_id,
        username=args.username,
        password=args.password,
        protocol=args.protocol,
        transport=args.transport,
        tls=args.tls,
        tls_insecure=args.tls_insecure,
        ca_certs=args.ca_certs,
    )


def _app_config_from_args(args: argparse.Namespace) -> AppConfig:
    return AppConfig(
        connection=_connection_from_args(args),
        topic_filter=args.topic_filter,
        qos=args.qos,
        theme=args.theme,
        refresh_hz=args.refresh,
        sort_key=args.sort_key,
        top=args.top,
        subscribe_sys=args.subscribe_sys,
    )


# ------------------------------------------------------------------- commands
def _cmd_dashboard(args: argparse.Namespace) -> int:
    from .client import MqttMonitor
    from .ui import build_console, render_snapshot, run_dashboard

    config = _app_config_from_args(args)
    console = build_console(config.theme)
    monitor = MqttMonitor(config)
    return _run_live(monitor, config, console, args, run_dashboard, render_snapshot)


def _cmd_browse(args: argparse.Namespace) -> int:
    from .client import MqttMonitor
    from .ui import build_console, render_browse_snapshot, run_browser

    config = _app_config_from_args(args)
    console = build_console(config.theme)
    monitor = MqttMonitor(config)
    return _run_live(monitor, config, console, args, run_browser, render_browse_snapshot)


def _run_live(monitor, config, console, args, live_runner, snapshot_runner) -> int:
    from .client import ConnectionState

    console.print(
        f"[muted]connecting to[/] [value]{config.connection.host}:{config.connection.port}[/] …",
        highlight=False,
    )
    try:
        monitor.connect()
    except Exception as exc:  # noqa: BLE001 - present a clean message, not a trace
        console.print(f"[error]Connection failed:[/] {exc}")
        return 2

    if not monitor.wait_until_connected(timeout=5.0):
        console.print(
            f"[warning]Not connected yet[/] (state: {monitor.state.value}). "
            "Continuing; paho will keep retrying."
        )
    try:
        if args.once:
            # Give the broker a moment to deliver retained/$SYS messages first.
            time.sleep(min(1.5, config.refresh_interval * 4))
            snapshot_runner(config, monitor, console)
        else:
            live_runner(config, monitor, console, duration=args.duration)
    finally:
        monitor.disconnect()
    return 0 if monitor.state != ConnectionState.FAILED else 2


def _cmd_themes(args: argparse.Namespace) -> int:
    from rich.console import Console
    from rich.table import Table


    if args.theme:
        if args.theme not in THEMES:
            print(f"unknown theme: {args.theme}", file=sys.stderr)
            return 2
        _preview_theme(args.theme)
        return 0

    console = Console()
    table = Table(title="Available themes", title_style="bold")
    table.add_column("Name", style="cyan")
    table.add_column("Description")
    for name in theme_names():
        table.add_row(name, THEMES[name].description)
    console.print(table)
    console.print("\nPreview one with: [cyan]mqtt-monitor themes --theme <name>[/]")
    return 0


def _preview_theme(name: str) -> None:
    from rich.panel import Panel
    from rich.table import Table

    from .ui import build_console

    console = build_console(name)
    theme = THEMES[name]
    demo = Table(box=theme.box, border_style="border", header_style="heading", expand=True)
    demo.add_column("Topic", style="accent")
    demo.add_column("Rate", style="secondary", justify="right")
    demo.add_column("Status")
    demo.add_row("sensors/temp/kitchen", "12.4/s", "[success]ok[/]")
    demo.add_row("sensors/hum/attic", "0.20/s", "[warning]stale[/]")
    demo.add_row("actuators/valve/main", "3.1k/s", "[error]error[/]")
    console.print(
        Panel(
            demo,
            title=f"[title]{name}[/] [muted]— {theme.description}[/]",
            border_style="border",
            box=theme.box,
        )
    )


def _cmd_publish(args: argparse.Namespace) -> int:
    import paho.mqtt.client as mqtt
    from paho.mqtt.enums import CallbackAPIVersion

    conn = _connection_from_args(args)
    client = mqtt.Client(CallbackAPIVersion.VERSION2, client_id=conn.client_id or "")
    if conn.username:
        client.username_pw_set(conn.username, conn.password)
    if conn.tls:
        client.tls_set_context(conn.tls_context)
    try:
        client.connect(conn.host, conn.port, conn.keepalive)
    except Exception as exc:  # noqa: BLE001
        print(f"Connection failed: {exc}", file=sys.stderr)
        return 2
    client.loop_start()
    try:
        for i in range(args.count):
            payload = args.message if args.count == 1 else f"{args.message} #{i + 1}"
            info = client.publish(args.topic, payload, qos=args.qos, retain=args.retain)
            info.wait_for_publish(timeout=5.0)
            print(f"published to {args.topic!r}: {payload!r}")
            if i + 1 < args.count:
                time.sleep(args.interval)
    finally:
        client.loop_stop()
        client.disconnect()
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if getattr(args, "command", None) is None:
        # No subcommand → default to dashboard with its defaults.
        args = parser.parse_args(["dashboard", *(argv or [])])

    try:
        return int(args.func(args))
    except ConfigError as exc:
        print(f"configuration error: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:  # pragma: no cover
        return 130


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
