"""Human-friendly interpretation of the broker ``$SYS`` tree.

Brokers publish an assortment of gauges and counters under ``$SYS/broker/*``.
The exact set varies between implementations, so this module treats the tree as
best-effort: known topics get a friendly label, a group and a formatter; unknown
topics still render with their raw value.  Nothing here raises on bad input.
"""

from __future__ import annotations

from dataclasses import dataclass

from .metrics import BrokerStats

SYS_FILTER = "$SYS/#"


@dataclass(frozen=True, slots=True)
class SysField:
    topic: str
    label: str
    group: str
    kind: str  # "int" | "float" | "bytes" | "seconds" | "text"


# Curated, ordered catalogue of the most useful Mosquitto/EMQX-style metrics.
# Order within a group is the display order.
_CATALOGUE: tuple[SysField, ...] = (
    SysField("$SYS/broker/version", "Version", "Broker", "text"),
    SysField("$SYS/broker/uptime", "Uptime", "Broker", "text"),
    SysField("$SYS/broker/clients/connected", "Clients connected", "Clients", "int"),
    SysField("$SYS/broker/clients/active", "Clients active", "Clients", "int"),
    SysField("$SYS/broker/clients/inactive", "Clients inactive", "Clients", "int"),
    SysField("$SYS/broker/clients/disconnected", "Clients disconnected", "Clients", "int"),
    SysField("$SYS/broker/clients/total", "Clients total", "Clients", "int"),
    SysField("$SYS/broker/clients/maximum", "Clients maximum", "Clients", "int"),
    SysField("$SYS/broker/subscriptions/count", "Subscriptions", "Clients", "int"),
    SysField("$SYS/broker/messages/received", "Messages received", "Messages", "int"),
    SysField("$SYS/broker/messages/sent", "Messages sent", "Messages", "int"),
    SysField("$SYS/broker/messages/stored", "Messages stored", "Messages", "int"),
    SysField("$SYS/broker/publish/messages/received", "Publish received", "Messages", "int"),
    SysField("$SYS/broker/publish/messages/sent", "Publish sent", "Messages", "int"),
    SysField("$SYS/broker/publish/messages/dropped", "Publish dropped", "Messages", "int"),
    SysField("$SYS/broker/retained messages/count", "Retained messages", "Messages", "int"),
    SysField("$SYS/broker/bytes/received", "Bytes received", "Traffic", "bytes"),
    SysField("$SYS/broker/bytes/sent", "Bytes sent", "Traffic", "bytes"),
    SysField("$SYS/broker/publish/bytes/received", "Publish bytes received", "Traffic", "bytes"),
    SysField("$SYS/broker/publish/bytes/sent", "Publish bytes sent", "Traffic", "bytes"),
    SysField("$SYS/broker/load/messages/received/1min", "Msgs recv/min (1m)", "Load", "float"),
    SysField("$SYS/broker/load/messages/sent/1min", "Msgs sent/min (1m)", "Load", "float"),
    SysField("$SYS/broker/load/bytes/received/1min", "Bytes recv/min (1m)", "Load", "float"),
    SysField("$SYS/broker/load/bytes/sent/1min", "Bytes sent/min (1m)", "Load", "float"),
    SysField("$SYS/broker/heap/current", "Heap current", "Runtime", "bytes"),
    SysField("$SYS/broker/heap/maximum", "Heap maximum", "Runtime", "bytes"),
)

_BY_TOPIC = {f.topic: f for f in _CATALOGUE}
GROUP_ORDER = ("Broker", "Clients", "Messages", "Traffic", "Load", "Runtime")


def format_bytes(value: float) -> str:
    """Render a byte count using binary units (e.g. ``1.5 MiB``)."""
    step = 1024.0
    units = ("B", "KiB", "MiB", "GiB", "TiB", "PiB")
    size = float(value)
    for unit in units:
        if abs(size) < step or unit == units[-1]:
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.2f} {unit}"
        size /= step
    return f"{size:.2f} PiB"  # pragma: no cover - unreachable


def format_rate(value: float) -> str:
    """Compact messages/second formatting."""
    if value >= 1000:
        return f"{value / 1000:.1f}k/s"
    if value >= 10:
        return f"{value:.0f}/s"
    return f"{value:.2f}/s"


def format_duration(seconds: float) -> str:
    seconds = int(max(0, seconds))
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, secs = divmod(rem, 60)
    if days:
        return f"{days}d {hours}h {minutes}m"
    if hours:
        return f"{hours}h {minutes}m {secs}s"
    if minutes:
        return f"{minutes}m {secs}s"
    return f"{secs}s"


def _coerce_number(raw: str) -> float | None:
    try:
        return float(raw.split()[0]) if raw else None
    except (ValueError, IndexError):
        return None


def format_value(field: SysField, raw: str) -> str:
    """Format a raw ``$SYS`` value according to its declared kind."""
    if field.kind == "text":
        return raw
    number = _coerce_number(raw)
    if number is None:
        return raw
    if field.kind == "bytes":
        return format_bytes(number)
    if field.kind == "int":
        return f"{int(number):,}"
    if field.kind == "float":
        return f"{number:,.2f}"
    if field.kind == "seconds":
        return format_duration(number)
    return raw


@dataclass(frozen=True, slots=True)
class SysRow:
    label: str
    value: str
    group: str


def structured_view(stats: BrokerStats) -> dict[str, list[SysRow]]:
    """Group known ``$SYS`` values for display, preserving catalogue order.

    Returns a mapping of group name -> rows, only including groups that have at
    least one known value present in ``stats``.
    """
    grouped: dict[str, list[SysRow]] = {g: [] for g in GROUP_ORDER}
    for field in _CATALOGUE:
        raw = stats.get(field.topic)
        if raw is None:
            continue
        grouped[field.group].append(
            SysRow(label=field.label, value=format_value(field, raw), group=field.group)
        )
    return {g: rows for g, rows in grouped.items() if rows}


def unknown_values(stats: BrokerStats, limit: int | None = None) -> list[SysRow]:
    """Return ``$SYS`` values that are not in the curated catalogue."""
    rows = [
        SysRow(label=topic.removeprefix("$SYS/broker/"), value=value, group="Other")
        for topic, value in sorted(stats.items())
        if topic not in _BY_TOPIC
    ]
    return rows[:limit] if limit else rows


def is_sys_topic(topic: str) -> bool:
    return topic.startswith("$SYS/")
