"""Rich rendering layer.

All builders here are *pure*: they take plain data (snapshots, stats, config)
and return Rich renderables.  That keeps them trivially testable — a recording
:class:`~rich.console.Console` can render them with no broker involved — and
keeps the live loop (:func:`run_dashboard`) small.
"""

from __future__ import annotations

import time
from datetime import datetime

from rich.align import Align
from rich.console import Console, Group, RenderableType
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .client import ConnectionState, MqttMonitor
from .config import AppConfig
from .metrics import BrokerStats, TopicSnapshot
from .payloads import decode_payload, preview
from .sys_topics import (
    format_bytes,
    format_duration,
    format_rate,
    structured_view,
)
from .themes import Theme, get_theme

_STATE_STYLE = {
    ConnectionState.CONNECTED: ("success", "●"),
    ConnectionState.CONNECTING: ("warning", "◌"),
    ConnectionState.RECONNECTING: ("warning", "◌"),
    ConnectionState.DISCONNECTED: ("muted", "○"),
    ConnectionState.FAILED: ("error", "✕"),
}


def build_console(theme_name: str, **kwargs: object) -> Console:
    """Create a Console bound to the chosen theme."""
    theme = get_theme(theme_name)
    return Console(theme=theme.rich_theme(), **kwargs)  # type: ignore[arg-type]


# --------------------------------------------------------------------- header
def header(monitor: MqttMonitor, config: AppConfig, session_start: float) -> RenderableType:
    conn = config.connection
    style, glyph = _STATE_STYLE.get(monitor.state, ("muted", "○"))
    left = Text()
    left.append(f"{glyph} ", style=style)
    left.append(monitor.state.value.upper(), style=f"bold {style}")
    left.append("  ")
    left.append(f"{conn.host}:{conn.port}", style="value")
    left.append(f"  MQTT {conn.protocol}", style="muted")
    if conn.tls:
        left.append("  TLS", style="success")

    right = Text()
    right.append("filter ", style="muted")
    right.append(config.topic_filter, style="accent")
    right.append("   uptime ", style="muted")
    right.append(format_duration(time.time() - session_start), style="value")

    if monitor.last_error and monitor.state in (
        ConnectionState.FAILED,
        ConnectionState.RECONNECTING,
    ):
        right.append("   " + monitor.last_error, style="error")

    grid = Table.grid(expand=True)
    grid.add_column(justify="left")
    grid.add_column(justify="right")
    grid.add_row(left, right)
    return grid


# --------------------------------------------------------------------- broker
def broker_panel(stats: BrokerStats, theme: Theme, *, session_start: float) -> Panel:
    grouped = structured_view(stats)
    body: list[RenderableType] = []
    if not grouped:
        body.append(
            Align.center(
                Text(
                    "Waiting for $SYS metrics…\n(broker may not publish them)",
                    style="muted",
                    justify="center",
                )
            )
        )
    else:
        for group, rows in grouped.items():
            table = Table.grid(padding=(0, 1))
            table.add_column(style="label", no_wrap=True)
            table.add_column(style="value", justify="right")
            for row in rows:
                table.add_row(row.label, row.value)
            body.append(Text(group, style="heading"))
            body.append(table)
            body.append(Text(""))

    return Panel(
        Group(*body),
        title="[title]Broker[/]",
        border_style="border",
        box=theme.box,
        padding=(1, 2),
    )


# --------------------------------------------------------------------- topics
def topics_table(
    snapshots: list[TopicSnapshot],
    config: AppConfig,
    theme: Theme,
    *,
    total_messages: int,
    total_bytes: int,
    overall_rate: float,
) -> Panel:
    table = Table(
        box=theme.box,
        border_style="border",
        header_style="heading",
        expand=True,
        pad_edge=False,
    )
    table.add_column("Topic", style="accent", no_wrap=True, ratio=3)
    table.add_column("Msgs", style="value", justify="right", no_wrap=True)
    table.add_column("Rate", style="secondary", justify="right", no_wrap=True)
    table.add_column("Bytes", style="value", justify="right", no_wrap=True)
    table.add_column("Avg", style="muted", justify="right", no_wrap=True)
    table.add_column("Q", style="muted", justify="center", no_wrap=True)
    table.add_column("Last payload", style="label", ratio=2, no_wrap=True)

    if not snapshots:
        table.add_row("— no messages yet —", "", "", "", "", "", "")
    for snap in snapshots:
        table.add_row(
            snap.topic,
            f"{snap.messages:,}",
            format_rate(snap.rate),
            format_bytes(snap.total_bytes),
            format_bytes(snap.avg_bytes),
            _qos_glyph(snap.last_qos, snap.last_retain),
            preview(snap.last_payload),
        )

    subtitle = (
        f"[muted]topics[/] [value]{len(snapshots)}[/]   "
        f"[muted]msgs[/] [value]{total_messages:,}[/]   "
        f"[muted]vol[/] [value]{format_bytes(total_bytes)}[/]   "
        f"[muted]avg[/] [value]{format_rate(overall_rate)}[/]   "
        f"[muted]sort[/] [accent]{config.sort_key}[/]"
    )
    return Panel(
        table,
        title=f"[title]Topics[/] [muted]({config.topic_filter})[/]",
        subtitle=subtitle,
        border_style="border",
        box=theme.box,
        padding=(0, 1),
    )


def _qos_glyph(qos: int, retain: bool) -> str:
    tag = str(qos)
    return f"{tag}[success]R[/]" if retain else tag


# ----------------------------------------------------------------- dashboard
class Dashboard:
    """Assembles the full-screen dashboard layout from live monitor state."""

    def __init__(self, config: AppConfig, monitor: MqttMonitor) -> None:
        self.config = config
        self.monitor = monitor
        self.theme = get_theme(config.theme)
        self.session_start = time.time()

    def renderable(self) -> RenderableType:
        monitor, config = self.monitor, self.config
        snapshots = monitor.registry.top(config.sort_key, config.top)

        layout = Layout()
        layout.split_column(
            Layout(name="header", size=1),
            Layout(name="body"),
            Layout(name="footer", size=1),
        )
        layout["header"].update(header(monitor, config, self.session_start))
        layout["body"].split_row(
            Layout(
                broker_panel(
                    monitor.broker_stats, self.theme, session_start=self.session_start
                ),
                name="broker",
                size=44,
            ),
            Layout(
                topics_table(
                    snapshots,
                    config,
                    self.theme,
                    total_messages=monitor.registry.total_messages,
                    total_bytes=monitor.registry.total_bytes,
                    overall_rate=monitor.registry.overall_rate,
                ),
                name="topics",
                ratio=1,
            ),
        )
        layout["footer"].update(_footer(config))
        return layout


def _footer(config: AppConfig) -> RenderableType:
    now = datetime.now().strftime("%H:%M:%S")
    text = Text(justify="right")
    text.append("theme ", style="muted")
    text.append(config.theme, style="accent")
    text.append("   refresh ", style="muted")
    text.append(f"{config.refresh_hz:g}Hz", style="value")
    text.append("   ", style="muted")
    text.append(now, style="muted")
    text.append("   Ctrl-C to quit", style="muted")
    return text


# ------------------------------------------------------------------- browse
def browse_view(
    snapshots: list[TopicSnapshot],
    config: AppConfig,
    theme: Theme,
    *,
    detail: TopicSnapshot | None,
) -> RenderableType:
    """A two-pane browser: topic list on the left, decoded payload on the right."""
    table = Table(
        box=theme.box,
        border_style="border",
        header_style="heading",
        expand=True,
        pad_edge=False,
    )
    table.add_column("Topic", style="accent", no_wrap=True, ratio=2)
    table.add_column("Msgs", style="value", justify="right")
    table.add_column("Rate", style="secondary", justify="right")
    for snap in snapshots or []:
        table.add_row(snap.topic, f"{snap.messages:,}", format_rate(snap.rate))
    if not snapshots:
        table.add_row("— no messages yet —", "", "")

    left = Panel(
        table,
        title=f"[title]Topics[/] [muted]({config.topic_filter})[/]",
        border_style="border",
        box=theme.box,
        padding=(0, 1),
    )
    right = _detail_panel(detail, theme)

    layout = Layout()
    layout.split_row(
        Layout(left, name="list", ratio=1),
        Layout(right, name="detail", ratio=1),
    )
    return layout


def _detail_panel(detail: TopicSnapshot | None, theme: Theme) -> Panel:
    if detail is None:
        content: RenderableType = Align.center(
            Text("Select a topic with --topic to inspect payloads", style="muted")
        )
        title = "[title]Payload[/]"
    else:
        decoded = decode_payload(detail.last_payload)
        meta = Table.grid(padding=(0, 1))
        meta.add_column(style="label")
        meta.add_column(style="value")
        meta.add_row("Topic", detail.topic)
        meta.add_row("Messages", f"{detail.messages:,}")
        meta.add_row("Total bytes", format_bytes(detail.total_bytes))
        meta.add_row("QoS / retain", f"{detail.last_qos} / {detail.last_retain}")
        meta.add_row("Payload type", decoded.kind)
        meta.add_row("Last seen", f"{detail.age:.1f}s ago")
        body = Text(decoded.text, style="value")
        content = Group(meta, Text(""), Text("Last payload", style="heading"), body)
        title = f"[title]Payload[/] [muted]{detail.topic}[/]"
    return Panel(
        content, title=title, border_style="border", box=theme.box, padding=(1, 2)
    )


# ------------------------------------------------------------------- runners
def run_dashboard(
    config: AppConfig,
    monitor: MqttMonitor,
    console: Console,
    *,
    duration: float | None = None,
) -> None:
    """Blocking live loop; returns on Ctrl-C or after ``duration`` seconds."""
    dashboard = Dashboard(config, monitor)
    interval = config.refresh_interval
    deadline = time.time() + duration if duration else None
    with Live(
        dashboard.renderable(),
        console=console,
        screen=True,
        refresh_per_second=config.refresh_hz,
        transient=True,
    ) as live:
        try:
            while deadline is None or time.time() < deadline:
                monitor.registry.tick()
                live.update(dashboard.renderable())
                time.sleep(interval)
        except KeyboardInterrupt:
            pass


def run_browser(
    config: AppConfig,
    monitor: MqttMonitor,
    console: Console,
    *,
    duration: float | None = None,
) -> None:
    """Live payload browser. If ``--filter`` names one concrete topic, its
    payloads are shown in the detail pane; otherwise the most recently active
    topic is shown."""
    theme = get_theme(config.theme)
    interval = config.refresh_interval
    deadline = time.time() + duration if duration else None
    focus = (
        config.topic_filter
        if "#" not in config.topic_filter and "+" not in config.topic_filter
        else None
    )

    def frame() -> RenderableType:
        snaps = monitor.registry.top("recent", config.top)
        detail = monitor.registry.get(focus) if focus else (snaps[0] if snaps else None)
        return browse_view(snaps, config, theme, detail=detail)

    with Live(
        frame(),
        console=console,
        screen=True,
        refresh_per_second=config.refresh_hz,
        transient=True,
    ) as live:
        try:
            while deadline is None or time.time() < deadline:
                monitor.registry.tick()
                live.update(frame())
                time.sleep(interval)
        except KeyboardInterrupt:
            pass


def render_snapshot(config: AppConfig, monitor: MqttMonitor, console: Console) -> None:
    """Render a single static dashboard frame (non-TTY output / --once)."""
    dashboard = Dashboard(config, monitor)
    monitor.registry.tick()
    console.print(dashboard.renderable())


def render_browse_snapshot(config: AppConfig, monitor: MqttMonitor, console: Console) -> None:
    """Render a single static browse frame (non-TTY output / --once)."""
    theme = get_theme(config.theme)
    monitor.registry.tick()
    focus = (
        config.topic_filter
        if "#" not in config.topic_filter and "+" not in config.topic_filter
        else None
    )
    snaps = monitor.registry.top("recent", config.top)
    detail = monitor.registry.get(focus) if focus else (snaps[0] if snaps else None)
    console.print(browse_view(snaps, config, theme, detail=detail))
