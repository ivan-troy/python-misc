"""Best-effort decoding of MQTT payloads for display.

Payloads are arbitrary bytes.  We try, in order: pretty JSON, plain UTF-8 text,
then a hex+ASCII dump for binary.  The result is always a printable string plus
a short ``kind`` tag the UI can colour/label.
"""

from __future__ import annotations

import json
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class DecodedPayload:
    kind: str  # "json" | "text" | "binary" | "empty"
    text: str


def decode_payload(payload: bytes, *, max_chars: int = 2000) -> DecodedPayload:
    """Decode ``payload`` into a human-readable representation."""
    if not payload:
        return DecodedPayload("empty", "<empty>")

    text: str | None
    try:
        text = payload.decode("utf-8")
    except UnicodeDecodeError:
        text = None

    if text is not None:
        stripped = text.strip()
        if stripped and stripped[0] in "{[":
            try:
                parsed = json.loads(stripped)
                pretty = json.dumps(parsed, indent=2, ensure_ascii=False, sort_keys=True)
                return DecodedPayload("json", _truncate(pretty, max_chars))
            except (json.JSONDecodeError, ValueError):
                pass
        return DecodedPayload("text", _truncate(text, max_chars))

    return DecodedPayload("binary", _hexdump(payload, max_bytes=max_chars // 4))


def preview(payload: bytes, *, width: int = 48) -> str:
    """A compact single-line preview for table cells."""
    decoded = decode_payload(payload, max_chars=width * 2)
    single = " ".join(decoded.text.split())
    if len(single) > width:
        return single[: width - 1] + "\u2026"  # ellipsis
    return single


def _truncate(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + f"\n… (+{len(text) - max_chars} more chars)"


def _hexdump(data: bytes, *, max_bytes: int = 256) -> str:
    chunk = data[:max_bytes]
    lines: list[str] = []
    for offset in range(0, len(chunk), 16):
        row = chunk[offset : offset + 16]
        hex_part = " ".join(f"{b:02x}" for b in row)
        ascii_part = "".join(chr(b) if 32 <= b < 127 else "." for b in row)
        lines.append(f"{offset:08x}  {hex_part:<47}  {ascii_part}")
    if len(data) > max_bytes:
        lines.append(f"… (+{len(data) - max_bytes} more bytes)")
    return "\n".join(lines)
