"""Thin, well-behaved wrapper around the paho-mqtt 2.x client.

Design goals:

* Use the modern ``CallbackAPIVersion.VERSION2`` API exclusively.
* Keep all message-routing logic in a single pure method
  (:meth:`MqttMonitor.handle_message`) that can be unit-tested without a broker.
* Let paho own reconnection (it does exponential back-off by default) while we
  track a clean, observable :class:`ConnectionState`.
* Allow a ``client_factory`` to be injected so tests can supply a fake.
"""

from __future__ import annotations

import enum
import threading
from collections.abc import Callable
from typing import Any

import paho.mqtt.client as mqtt
from paho.mqtt.enums import CallbackAPIVersion

from .config import AppConfig
from .metrics import BrokerStats, MetricsRegistry
from .sys_topics import SYS_FILTER, is_sys_topic

ClientFactory = Callable[[], mqtt.Client]


class ConnectionState(enum.Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"
    FAILED = "failed"


_PROTOCOL_MAP = {"3.1.1": mqtt.MQTTv311, "5": mqtt.MQTTv5}


class MqttMonitor:
    """Connect to a broker and feed a :class:`MetricsRegistry` + broker stats."""

    def __init__(
        self,
        config: AppConfig,
        *,
        registry: MetricsRegistry | None = None,
        broker_stats: BrokerStats | None = None,
        client_factory: ClientFactory | None = None,
    ) -> None:
        self.config = config
        self.registry = registry or MetricsRegistry(
            max_payload_bytes=config.max_payload_bytes
        )
        self.broker_stats = broker_stats or BrokerStats()
        self._client_factory = client_factory or self._default_client_factory
        self._client: mqtt.Client | None = None
        self._state = ConnectionState.DISCONNECTED
        self._state_lock = threading.Lock()
        self._connected_event = threading.Event()
        self.last_error: str | None = None

    # --------------------------------------------------------------- lifecycle
    @property
    def state(self) -> ConnectionState:
        with self._state_lock:
            return self._state

    def _set_state(self, state: ConnectionState) -> None:
        with self._state_lock:
            self._state = state

    def _default_client_factory(self) -> mqtt.Client:
        conn = self.config.connection
        client = mqtt.Client(
            CallbackAPIVersion.VERSION2,
            client_id=conn.client_id or "",
            protocol=_PROTOCOL_MAP[conn.protocol],
            transport=conn.transport,
        )
        if conn.username:
            client.username_pw_set(conn.username, conn.password)
        if conn.tls:
            client.tls_set_context(conn.tls_context)
            if conn.tls_insecure:
                client.tls_insecure_set(True)
        return client

    def _wire_callbacks(self, client: mqtt.Client) -> None:
        client.on_connect = self._on_connect
        client.on_disconnect = self._on_disconnect
        client.on_message = self._on_message
        client.on_connect_fail = self._on_connect_fail

    def connect(self) -> None:
        """Open the connection and start the network loop (non-blocking)."""
        conn = self.config.connection
        self._client = self._client_factory()
        self._wire_callbacks(self._client)
        self._set_state(ConnectionState.CONNECTING)
        self.last_error = None
        try:
            self._client.connect(conn.host, conn.port, conn.keepalive)
        except Exception as exc:  # network/DNS/refused errors surface here
            self._set_state(ConnectionState.FAILED)
            self.last_error = f"{type(exc).__name__}: {exc}"
            raise
        self._client.loop_start()

    def wait_until_connected(self, timeout: float | None = None) -> bool:
        """Block until connected (or timeout). Returns True if connected."""
        return self._connected_event.wait(timeout)

    def disconnect(self) -> None:
        """Stop the loop and disconnect cleanly. Idempotent."""
        client, self._client = self._client, None
        if client is not None:
            try:
                client.disconnect()
            finally:
                client.loop_stop()
        self._connected_event.clear()
        self._set_state(ConnectionState.DISCONNECTED)

    def __enter__(self) -> MqttMonitor:
        self.connect()
        return self

    def __exit__(self, *exc: object) -> None:
        self.disconnect()

    # --------------------------------------------------------------- callbacks
    def _subscriptions(self) -> list[tuple[str, int]]:
        subs = [(self.config.topic_filter, self.config.qos)]
        if self.config.subscribe_sys and not is_sys_topic(self.config.topic_filter):
            subs.append((SYS_FILTER, 0))
        return subs

    def _on_connect(
        self,
        client: mqtt.Client,
        userdata: Any,
        flags: Any,
        reason_code: Any,
        properties: Any = None,
    ) -> None:
        if getattr(reason_code, "is_failure", False):
            self._set_state(ConnectionState.FAILED)
            self.last_error = f"connect refused: {reason_code}"
            return
        self._set_state(ConnectionState.CONNECTED)
        self._connected_event.set()
        for topic, qos in self._subscriptions():
            client.subscribe(topic, qos)

    def _on_disconnect(
        self,
        client: mqtt.Client,
        userdata: Any,
        flags: Any = None,
        reason_code: Any = None,
        properties: Any = None,
    ) -> None:
        self._connected_event.clear()
        # A non-zero reason code means an unexpected drop; paho will retry.
        if reason_code is not None and getattr(reason_code, "value", reason_code):
            self._set_state(ConnectionState.RECONNECTING)
            self.last_error = f"disconnected: {reason_code}"
        else:
            self._set_state(ConnectionState.DISCONNECTED)

    def _on_connect_fail(self, client: mqtt.Client, userdata: Any = None) -> None:
        self._set_state(ConnectionState.RECONNECTING)
        self.last_error = "connection attempt failed; retrying"

    def _on_message(self, client: mqtt.Client, userdata: Any, message: Any) -> None:
        self.handle_message(
            message.topic,
            message.payload,
            qos=getattr(message, "qos", 0),
            retain=getattr(message, "retain", False),
        )

    # ------------------------------------------------------------- core router
    def handle_message(
        self, topic: str, payload: bytes, *, qos: int = 0, retain: bool = False
    ) -> None:
        """Route one message to the right sink. Pure and unit-testable.

        ``$SYS`` traffic feeds broker stats; everything else feeds the per-topic
        registry. Never raises on malformed input.
        """
        if not isinstance(payload, (bytes, bytearray)):
            payload = str(payload).encode("utf-8", errors="replace")
        if is_sys_topic(topic):
            self.broker_stats.update(topic, bytes(payload))
        else:
            self.registry.record(topic, bytes(payload), qos=qos, retain=retain)
