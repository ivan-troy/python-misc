"""Colour themes for the dashboard.

Each :class:`Theme` maps a small set of *semantic roles* (accent, value, label,
success, ...) to concrete colours, plus a Rich box style for panels/tables.  The
UI only ever refers to roles, so adding a theme never touches rendering code.

Themes intentionally cover a spectrum: saturated modern palettes (nord, dracula,
gruvbox), a couple of light options, and genuinely minimalist monochrome styles
for people who want signal without decoration.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from rich import box
from rich.theme import Theme as RichTheme


@dataclass(frozen=True, slots=True)
class Theme:
    """A named palette. Colours are Rich style strings (hex or named)."""

    name: str
    description: str
    accent: str
    secondary: str
    value: str
    label: str
    muted: str
    success: str
    warning: str
    error: str
    border: str
    box: box.Box = field(default=box.ROUNDED)
    title_style: str = "bold"

    def rich_theme(self) -> RichTheme:
        """Build the Rich :class:`~rich.theme.Theme` used by the console."""
        return RichTheme(
            {
                "accent": self.accent,
                "secondary": self.secondary,
                "value": self.value,
                "label": self.label,
                "muted": self.muted,
                "success": self.success,
                "warning": self.warning,
                "error": self.error,
                "border": self.border,
                "title": f"{self.title_style} {self.accent}",
                "heading": f"bold {self.secondary}",
                "bar.complete": self.accent,
                "bar.back": self.muted,
            }
        )


THEMES: dict[str, Theme] = {
    "nord": Theme(
        name="nord",
        description="Cool arctic blues — the modern default.",
        accent="#88c0d0",
        secondary="#81a1c1",
        value="#eceff4",
        label="#d8dee9",
        muted="#4c566a",
        success="#a3be8c",
        warning="#ebcb8b",
        error="#bf616a",
        border="#4c566a",
        box=box.ROUNDED,
    ),
    "dracula": Theme(
        name="dracula",
        description="Vivid purple/pink night palette.",
        accent="#bd93f9",
        secondary="#ff79c6",
        value="#f8f8f2",
        label="#a4a7c0",
        muted="#6272a4",
        success="#50fa7b",
        warning="#f1fa8c",
        error="#ff5555",
        border="#44475a",
        box=box.ROUNDED,
    ),
    "gruvbox": Theme(
        name="gruvbox",
        description="Warm retro earth tones.",
        accent="#fabd2f",
        secondary="#83a598",
        value="#ebdbb2",
        label="#bdae93",
        muted="#665c54",
        success="#b8bb26",
        warning="#fe8019",
        error="#fb4934",
        border="#504945",
        box=box.HEAVY_HEAD,
    ),
    "matrix": Theme(
        name="matrix",
        description="Monochrome terminal green.",
        accent="#33ff66",
        secondary="#22aa44",
        value="#aaffaa",
        label="#55cc77",
        muted="#0f5f2f",
        success="#33ff66",
        warning="#ccff33",
        error="#ff5544",
        border="#0f5f2f",
        box=box.SQUARE,
    ),
    "dawn": Theme(
        name="dawn",
        description="Light theme for bright terminals.",
        accent="#286983",
        secondary="#56949f",
        value="#575279",
        label="#797593",
        muted="#9893a5",
        success="#618774",
        warning="#b4637a",
        error="#b4212f",
        border="#cecacd",
        box=box.ROUNDED,
    ),
    "minimal": Theme(
        name="minimal",
        description="Minimalist greyscale with hairline rules.",
        accent="#e6e6e6",
        secondary="#b0b0b0",
        value="#f2f2f2",
        label="#8a8a8a",
        muted="#5a5a5a",
        success="#c9c9c9",
        warning="#d9d9d9",
        error="#ffffff",
        border="#3a3a3a",
        box=box.SIMPLE,
        title_style="bold",
    ),
    "mono": Theme(
        name="mono",
        description="Pure text, no colour — maximum portability.",
        accent="default",
        secondary="default",
        value="default",
        label="default",
        muted="dim",
        success="default",
        warning="default",
        error="bold",
        border="dim",
        box=box.MINIMAL,
        title_style="bold",
    ),
    "ascii": Theme(
        name="ascii",
        description="ASCII-only borders for legacy/log-safe output.",
        accent="cyan",
        secondary="blue",
        value="white",
        label="bright_black",
        muted="bright_black",
        success="green",
        warning="yellow",
        error="red",
        border="bright_black",
        box=box.ASCII,
    ),
}

DEFAULT_THEME = "nord"


def get_theme(name: str) -> Theme:
    """Look up a theme by name, raising a helpful error otherwise."""
    try:
        return THEMES[name]
    except KeyError:
        available = ", ".join(sorted(THEMES))
        raise KeyError(f"unknown theme {name!r}; available: {available}") from None


def theme_names() -> list[str]:
    return sorted(THEMES)
