"""mqtt-monitor: a lightweight, themeable terminal dashboard for MQTT.

Public API surface kept intentionally small so the package is easy to embed:

    from mqtt_monitor import MqttMonitor, ConnectionConfig, MetricsRegistry

The command-line entry point lives in :mod:`mqtt_monitor.cli`.
"""

from __future__ import annotations

from .client import ConnectionState, MqttMonitor
from .config import AppConfig, ConnectionConfig
from .metrics import BrokerStats, MetricsRegistry, TopicSnapshot
from .themes import THEMES, Theme, get_theme

__all__ = [
    "AppConfig",
    "ConnectionConfig",
    "ConnectionState",
    "MqttMonitor",
    "BrokerStats",
    "MetricsRegistry",
    "TopicSnapshot",
    "THEMES",
    "Theme",
    "get_theme",
]

__version__ = "0.1.0"
