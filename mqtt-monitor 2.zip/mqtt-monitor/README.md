# mqtt-monitor

A lightweight, themeable **terminal dashboard for MQTT** — monitor a broker,
watch per-topic throughput, and inspect decoded payloads, all from the command
line. Built on the latest [paho-mqtt 2.x](https://pypi.org/project/paho-mqtt/)
and [Rich](https://github.com/Textualize/rich).

Only two runtime dependencies (`paho-mqtt`, `rich`), a clean `src/` layout, full
type hints, and a test suite that runs **without a broker**.

```
● CONNECTED  localhost:1883  MQTT 5            filter #   uptime 12s
╭─ Broker ─────────────────╮ ╭─ Topics (#) ───────────────────────────────────╮
│ Broker                   │ │ Topic                Msgs  Rate   Bytes  …      │
│ Version   mosquitto 2.0… │ │ sim/kitchen/temp      142  11/s   3.9 KiB …     │
│ Uptime    12 s           │ │ sim/attic/humidity     98   8/s   2.6 KiB …     │
│ Clients                  │ │ sim/garage/pressure    71   6/s   1.9 KiB …     │
│ Clients connected   3    │ │ …                                               │
╰──────────────────────────╯ ╰─────────────────────────────────────────────────╯
```

## Features

- **Broker overview** from the `$SYS/#` tree (clients, messages, traffic, load,
  uptime, heap) — grouped and human-formatted.
- **Per-topic statistics** the broker does *not* give you: message counts, byte
  volume, smoothed messages/sec and bytes/sec, average size, QoS/retain — sorted
  by whatever matters (`rate`, `bytes`, `messages`, …).
- **Payload browser**: two-pane view that pretty-prints JSON, shows text, and
  hex-dumps binary payloads.
- **8 themes**, from saturated modern palettes (`nord`, `dracula`, `gruvbox`) to
  genuinely minimalist ones (`minimal`, `mono`, `ascii`).
- **Safe defaults**: MQTT v5, automatic reconnection (handled by paho), TLS,
  username/password, WebSockets, config validation with clear errors.

## Install & run with `uv`

[`uv`](https://docs.astral.sh/uv/) is the fastest way to set this up.

```bash
# 1. create the environment and install the package + dev tools
uv venv
uv pip install -e ".[dev]"

# 2. run it (installs the `mqtt-monitor` / `mqttmon` console scripts)
uv run mqtt-monitor dashboard --host test.mosquitto.org
```

Or run without installing the scripts:

```bash
uv run python -m mqtt_monitor dashboard --host localhost
```

### One-liners (no clone needed)

```bash
uv run --with paho-mqtt --with rich python -m mqtt_monitor themes
```

## Usage

```bash
mqtt-monitor <command> [options]
```

| Command      | What it does                                              |
|--------------|-----------------------------------------------------------|
| `dashboard`  | Live broker (`$SYS`) + per-topic view. **Default.**       |
| `browse`     | Inspect metrics and decoded payloads for topics.          |
| `themes`     | List themes, or preview one with `--theme <name>`.        |
| `publish`    | Publish test messages (handy for smoke-testing a broker). |

### Examples

```bash
# Overall broker + everything published under '#'
mqtt-monitor dashboard --host localhost

# Monitor a specific subtree, sorted by throughput, dark minimal theme
mqtt-monitor dashboard -t 'sensors/#' --sort rate --theme minimal

# Topics only (skip the $SYS broker panel subscription)
mqtt-monitor dashboard -t 'devices/#' --no-sys

# Browse and pretty-print payloads for one concrete topic
mqtt-monitor browse -t 'sensors/temp/kitchen' --theme dracula

# Secure connection with auth
mqtt-monitor dashboard -H broker.example.com --tls -u alice -P s3cret

# Preview a theme, or list them all
mqtt-monitor themes
mqtt-monitor themes --theme gruvbox

# Render a single frame (non-interactive / CI / piping to a file)
mqtt-monitor dashboard --once --duration 3
```

### Common options

```
connection:  -H/--host  -p/--port  -u/--username  -P/--password
             --protocol {3.1.1,5}  --transport {tcp,websockets}
             --tls  --tls-insecure  --ca-certs  --client-id  --keepalive
view:        -t/--filter  --qos {0,1,2}  --theme  --refresh <Hz>
             --sort {rate,byte_rate,messages,bytes,recent,topic}
             --top <N>  --no-sys  --once  --duration <seconds>
```

Connection defaults can also come from the environment: `MQTT_HOST`,
`MQTT_PORT`, `MQTT_USERNAME`, `MQTT_PASSWORD`, `MQTT_TLS`, `MQTT_PROTOCOL`.

## Try it locally in 30 seconds

With a local [Mosquitto](https://mosquitto.org/) broker running:

```bash
# terminal 1 — generate synthetic traffic
uv run python scripts/simulate.py --host localhost --rate 20

# terminal 2 — watch it live
uv run mqtt-monitor dashboard --host localhost -t 'sim/#' --sort rate
```

No broker handy? Point it at the public test broker:
`--host test.mosquitto.org`.

## Development

```bash
uv pip install -e ".[dev]"
uv run pytest                 # run the test suite
uv run pytest --cov=mqtt_monitor --cov-report=term-missing
uv run ruff check .           # lint
uv run ruff format .          # format
uv run mypy                   # type-check
```

The suite exercises metrics, `$SYS` parsing, payload decoding, themes, config
validation, the client's message routing (via an injected fake paho client), the
Rich renderables (rendered headless to a recording console), and the CLI — all
**without touching the network**.

### Project layout

```
src/mqtt_monitor/
  cli.py        argparse CLI (dashboard / browse / themes / publish)
  client.py     paho-mqtt 2.x wrapper (VERSION2 callbacks) + message router
  metrics.py    thread-safe per-topic registry, EWMA rates, broker stats
  sys_topics.py $SYS catalogue, grouping, human formatting
  payloads.py   JSON / text / binary payload decoding
  themes.py     semantic theme → Rich styles + box characters
  ui.py         pure Rich renderables + the live loop
  config.py     validated ConnectionConfig / AppConfig
tests/          pytest suite (broker-free)
scripts/        simulate.py traffic generator
```

## Design notes & alternatives considered

**Threaded paho loop (`loop_start`) vs asyncio.** We use paho's background thread
and hand immutable snapshots to a Rich render loop. It's the simplest thing that
composes cleanly with Rich's `Live`, needs no event-loop plumbing, and lets paho
own reconnection. If you were embedding this in an existing asyncio app,
[`aiomqtt`](https://pypi.org/project/aiomqtt/) (async wrapper over paho) would be
the better fit — the metrics/UI layers here are I/O-agnostic and would port with
little change.

**Rich `Live` vs Textual.** Rich keeps the dependency footprint tiny and is
perfect for an auto-refreshing dashboard. The trade-off is limited keyboard
interactivity (sorting/filtering are CLI flags, not live keypresses). If you want
click-to-sort columns, scrolling and focus, [Textual](https://textual.textualize.io/)
is the natural upgrade — again, the pure renderables here transfer over.

**argparse vs Typer/Click.** argparse is stdlib, so runtime deps stay at exactly
two. Typer would give slightly nicer help and shell completion at the cost of two
more dependencies; easy to swap since the command functions are already isolated.

**Rate calculation.** Per-topic rates use an exponential moving average of the
count delta between refresh ticks — O(topics) per tick and memory-flat, versus
storing per-message timestamps (accurate but unbounded under high throughput).

## License

MIT
