from __future__ import annotations

import pytest

from mqtt_monitor.metrics import BrokerStats
from mqtt_monitor.sys_topics import (
    _BY_TOPIC,  # type: ignore
    format_bytes,
    format_duration,
    format_rate,
    format_value,
    is_sys_topic,
    structured_view,
    unknown_values,
)


@pytest.mark.parametrize(
    "value,expected",
    [(0, "0 B"), (512, "512 B"), (1024, "1.00 KiB"), (1536, "1.50 KiB"), (1048576, "1.00 MiB")],
)
def test_format_bytes(value: int, expected: str) -> None:
    assert format_bytes(value) == expected


@pytest.mark.parametrize(
    "value,expected",
    [(0.2, "0.20/s"), (5.0, "5.00/s"), (42.0, "42/s"), (1500.0, "1.5k/s")],
)
def test_format_rate(value: float, expected: str) -> None:
    assert format_rate(value) == expected


@pytest.mark.parametrize(
    "seconds,expected",
    [(5, "5s"), (65, "1m 5s"), (3661, "1h 1m 1s"), (90061, "1d 1h 1m")],
)
def test_format_duration(seconds: int, expected: str) -> None:
    assert format_duration(seconds) == expected


def test_format_value_by_kind() -> None:
    version = _BY_TOPIC["$SYS/broker/version"]
    assert format_value(version, "mosquitto 2.0") == "mosquitto 2.0"

    clients = _BY_TOPIC["$SYS/broker/clients/connected"]
    assert format_value(clients, "1234") == "1,234"

    recv = _BY_TOPIC["$SYS/broker/bytes/received"]
    assert format_value(recv, "2048") == "2.00 KiB"

    load = _BY_TOPIC["$SYS/broker/load/messages/received/1min"]
    assert format_value(load, "12.5") == "12.50"


def test_format_value_tolerates_garbage() -> None:
    clients = _BY_TOPIC["$SYS/broker/clients/connected"]
    assert format_value(clients, "not-a-number") == "not-a-number"


def test_structured_view_groups_and_orders() -> None:
    stats = BrokerStats()
    stats.update("$SYS/broker/version", b"mosquitto 2.0.18")
    stats.update("$SYS/broker/clients/connected", b"3")
    stats.update("$SYS/broker/bytes/received", b"4096")
    view = structured_view(stats)
    assert list(view.keys()) == ["Broker", "Clients", "Traffic"]  # catalogue order
    assert view["Clients"][0].value == "3"
    assert view["Traffic"][0].value == "4.00 KiB"


def test_structured_view_empty_when_no_known_values() -> None:
    stats = BrokerStats()
    stats.update("$SYS/some/custom/thing", b"1")
    assert structured_view(stats) == {}


def test_unknown_values_reported() -> None:
    stats = BrokerStats()
    stats.update("$SYS/broker/version", b"x")  # known
    stats.update("$SYS/broker/custom/metric", b"9")  # unknown
    unknown = unknown_values(stats)
    labels = [r.label for r in unknown]
    assert "custom/metric" in labels
    assert "version" not in labels


def test_is_sys_topic() -> None:
    assert is_sys_topic("$SYS/broker/uptime")
    assert not is_sys_topic("sensors/temp")
