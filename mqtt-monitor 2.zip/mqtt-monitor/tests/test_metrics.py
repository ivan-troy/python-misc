from __future__ import annotations

import pytest

from mqtt_monitor.metrics import BrokerStats, MetricsRegistry


def test_record_accumulates_counts_and_bytes() -> None:
    reg = MetricsRegistry()
    reg.record("a/b", b"hello", qos=1, retain=True)
    reg.record("a/b", b"world!!")
    snap = reg.get("a/b")
    assert snap is not None
    assert snap.messages == 2
    assert snap.total_bytes == len(b"hello") + len(b"world!!")
    assert snap.last_payload == b"world!!"
    assert snap.last_qos == 0  # second message had default qos
    assert reg.total_messages == 2
    assert reg.topic_count == 1


def test_avg_bytes_and_zero_division_safe() -> None:
    reg = MetricsRegistry()
    assert reg.get("missing") is None
    reg.record("t", b"1234")
    reg.record("t", b"12")
    assert reg.get("t").avg_bytes == 3.0


def test_payload_is_truncated_but_size_is_full() -> None:
    reg = MetricsRegistry(max_payload_bytes=4)
    reg.record("t", b"abcdefgh")
    snap = reg.get("t")
    assert snap.last_payload == b"abcd"  # stored truncated
    assert snap.total_bytes == 8  # but full size counted


def test_tick_computes_positive_rate() -> None:
    reg = MetricsRegistry()
    now = 1000.0
    reg.record("t", b"x")
    reg.tick(now=now)
    for _ in range(10):
        reg.record("t", b"x")
    reg.tick(now=now + 1.0)
    snap = reg.get("t")
    assert snap.rate > 0


def test_top_sorts_descending_by_key() -> None:
    reg = MetricsRegistry()
    for _ in range(5):
        reg.record("busy", b"x")
    reg.record("quiet", b"x")
    top = reg.top("messages")
    assert [s.topic for s in top] == ["busy", "quiet"]
    assert reg.top("messages", limit=1)[0].topic == "busy"


def test_top_by_topic_is_ascending() -> None:
    reg = MetricsRegistry()
    reg.record("zeta", b"x")
    reg.record("alpha", b"x")
    assert [s.topic for s in reg.top("topic")] == ["alpha", "zeta"]


def test_unknown_sort_key_raises() -> None:
    reg = MetricsRegistry()
    reg.record("t", b"x")
    with pytest.raises(ValueError):
        reg.top("nope")


def test_reset_clears_everything() -> None:
    reg = MetricsRegistry()
    reg.record("t", b"x")
    reg.reset()
    assert reg.topic_count == 0
    assert reg.total_messages == 0
    assert reg.snapshot() == []


def test_overall_rate_is_nonnegative() -> None:
    reg = MetricsRegistry()
    reg.record("t", b"x")
    assert reg.overall_rate >= 0


def test_broker_stats_update_and_copy() -> None:
    stats = BrokerStats()
    stats.update("$SYS/broker/version", b"mosquitto 2.0.18")
    stats.update("$SYS/broker/clients/connected", b" 7 ")
    assert stats.get("$SYS/broker/version") == "mosquitto 2.0.18"
    assert stats.get("$SYS/broker/clients/connected") == "7"
    assert stats.get("missing") is None
    clone = stats.copy()
    clone.update("$SYS/broker/version", b"changed")
    assert stats.get("$SYS/broker/version") == "mosquitto 2.0.18"  # original intact
    assert len(stats) == 2


def test_broker_stats_handles_non_utf8() -> None:
    stats = BrokerStats()
    stats.update("$SYS/x", b"\xff\xfe")
    assert stats.get("$SYS/x") is not None  # never raises
