from __future__ import annotations

import pytest
from rich.theme import Theme as RichTheme

from mqtt_monitor.themes import THEMES, get_theme, theme_names


def test_default_themes_present() -> None:
    for expected in ("nord", "minimal", "mono", "dracula"):
        assert expected in THEMES


def test_get_theme_returns_theme() -> None:
    theme = get_theme("nord")
    assert theme.name == "nord"


def test_get_theme_unknown_raises_with_hint() -> None:
    with pytest.raises(KeyError) as exc:
        get_theme("does-not-exist")
    assert "available" in str(exc.value)


def test_every_theme_builds_a_rich_theme() -> None:
    for name in theme_names():
        rich_theme = get_theme(name).rich_theme()
        assert isinstance(rich_theme, RichTheme)
        # Required semantic roles must resolve to styles.
        for role in ("accent", "value", "success", "warning", "error", "border"):
            assert role in rich_theme.styles


def test_theme_names_sorted() -> None:
    names = theme_names()
    assert names == sorted(names)
