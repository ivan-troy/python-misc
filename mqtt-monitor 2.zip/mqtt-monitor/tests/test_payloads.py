from __future__ import annotations

from mqtt_monitor.payloads import decode_payload, preview


def test_decode_empty() -> None:
    d = decode_payload(b"")
    assert d.kind == "empty"


def test_decode_json_is_pretty_and_sorted() -> None:
    d = decode_payload(b'{"b":1,"a":2}')
    assert d.kind == "json"
    # sorted keys → "a" appears before "b"
    assert d.text.index('"a"') < d.text.index('"b"')
    assert "\n" in d.text  # indented


def test_decode_plain_text() -> None:
    d = decode_payload(b"hello world")
    assert d.kind == "text"
    assert d.text == "hello world"


def test_invalid_json_falls_back_to_text() -> None:
    d = decode_payload(b"{not valid json")
    assert d.kind == "text"


def test_decode_binary_hexdump() -> None:
    d = decode_payload(b"\x00\x01\xff\xfe")
    assert d.kind == "binary"
    assert "00000000" in d.text  # offset column


def test_text_truncation() -> None:
    d = decode_payload(b"x" * 5000, max_chars=100)
    assert "more chars" in d.text


def test_preview_is_single_line_and_bounded() -> None:
    p = preview(b"line one\nline two\nline three", width=20)
    assert "\n" not in p
    assert len(p) <= 20


def test_preview_adds_ellipsis_when_long() -> None:
    p = preview(b"a" * 200, width=30)
    assert p.endswith("\u2026")
