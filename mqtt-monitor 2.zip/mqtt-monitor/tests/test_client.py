from __future__ import annotations

from conftest import FakeClient, FakeMessage, FakeReasonCode

from mqtt_monitor.client import ConnectionState, MqttMonitor
from mqtt_monitor.config import AppConfig, ConnectionConfig


def _monitor(fake: FakeClient, **app_kwargs) -> MqttMonitor:
    config = AppConfig(connection=ConnectionConfig(), **app_kwargs)
    return MqttMonitor(config, client_factory=lambda: fake)


def test_handle_message_routes_topics_to_registry(fake_client: FakeClient) -> None:
    mon = _monitor(fake_client)
    mon.handle_message("sensors/temp", b"21.5", qos=1, retain=True)
    snap = mon.registry.get("sensors/temp")
    assert snap is not None and snap.messages == 1
    assert snap.last_qos == 1 and snap.last_retain is True
    assert len(mon.broker_stats) == 0


def test_handle_message_routes_sys_to_broker_stats(fake_client: FakeClient) -> None:
    mon = _monitor(fake_client)
    mon.handle_message("$SYS/broker/clients/connected", b"5")
    assert mon.registry.topic_count == 0
    assert mon.broker_stats.get("$SYS/broker/clients/connected") == "5"


def test_handle_message_accepts_non_bytes(fake_client: FakeClient) -> None:
    mon = _monitor(fake_client)
    mon.handle_message("t", "plain string")  # type: ignore[arg-type]
    assert mon.registry.get("t").total_bytes == len(b"plain string")


def test_connect_starts_loop_and_sets_state(fake_client: FakeClient) -> None:
    mon = _monitor(fake_client)
    mon.connect()
    assert fake_client.connected is True
    assert fake_client.loop_running is True
    assert mon.state == ConnectionState.CONNECTING


def test_on_connect_subscribes_to_filter_and_sys(fake_client: FakeClient) -> None:
    mon = _monitor(fake_client, topic_filter="sensors/#", qos=1, subscribe_sys=True)
    mon.connect()
    mon._on_connect(fake_client, None, None, FakeReasonCode(is_failure=False), None)
    assert ("sensors/#", 1) in fake_client.subscriptions
    assert ("$SYS/#", 0) in fake_client.subscriptions
    assert mon.state == ConnectionState.CONNECTED
    assert mon.wait_until_connected(timeout=0) is True


def test_on_connect_failure_sets_failed(fake_client: FakeClient) -> None:
    mon = _monitor(fake_client)
    mon.connect()
    mon._on_connect(fake_client, None, None, FakeReasonCode(is_failure=True), None)
    assert mon.state == ConnectionState.FAILED
    assert mon.last_error is not None


def test_no_sys_subscription_when_disabled(fake_client: FakeClient) -> None:
    mon = _monitor(fake_client, topic_filter="a/#", subscribe_sys=False)
    mon.connect()
    mon._on_connect(fake_client, None, None, FakeReasonCode(), None)
    assert all(topic != "$SYS/#" for topic, _ in fake_client.subscriptions)


def test_on_message_dispatches(fake_client: FakeClient) -> None:
    mon = _monitor(fake_client)
    mon._on_message(fake_client, None, FakeMessage("a/b", b"hi", qos=2, retain=False))
    assert mon.registry.get("a/b").last_qos == 2


def test_disconnect_is_idempotent(fake_client: FakeClient) -> None:
    mon = _monitor(fake_client)
    mon.connect()
    mon.disconnect()
    mon.disconnect()  # no error second time
    assert mon.state == ConnectionState.DISCONNECTED


def test_context_manager(fake_client: FakeClient) -> None:
    mon = _monitor(fake_client)
    with mon as m:
        assert m.state == ConnectionState.CONNECTING
    assert mon.state == ConnectionState.DISCONNECTED


def test_unexpected_disconnect_triggers_reconnecting(fake_client: FakeClient) -> None:
    mon = _monitor(fake_client)
    mon.connect()
    mon._on_disconnect(fake_client, None, None, FakeReasonCode(value=7), None)
    assert mon.state == ConnectionState.RECONNECTING
