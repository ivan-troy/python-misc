from __future__ import annotations

import pytest

from mqtt_monitor.cli import (
    _app_config_from_args,
    _connection_from_args,
    build_parser,
    main,
)


def test_parser_builds() -> None:
    parser = build_parser()
    args = parser.parse_args(["dashboard", "--host", "example.com", "--filter", "a/#"])
    assert args.host == "example.com"
    assert args.topic_filter == "a/#"
    assert args.command == "dashboard"


def test_tls_selects_default_secure_port() -> None:
    parser = build_parser()
    args = parser.parse_args(["dashboard", "--tls"])
    conn = _connection_from_args(args)
    assert conn.port == 8883
    assert conn.tls is True


def test_explicit_port_wins() -> None:
    parser = build_parser()
    args = parser.parse_args(["dashboard", "--port", "1999"])
    assert _connection_from_args(args).port == 1999


def test_app_config_from_args() -> None:
    parser = build_parser()
    args = parser.parse_args(
        ["dashboard", "--theme", "minimal", "--sort", "bytes", "--top", "5", "--no-sys"]
    )
    cfg = _app_config_from_args(args)
    assert cfg.theme == "minimal"
    assert cfg.sort_key == "bytes"
    assert cfg.top == 5
    assert cfg.subscribe_sys is False


def test_themes_command_lists(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["themes"]) == 0
    out = capsys.readouterr().out
    assert "nord" in out and "minimal" in out


def test_themes_preview_unknown_returns_error() -> None:
    assert main(["themes", "--theme", "no-such-theme"]) == 2


def test_themes_preview_known_ok() -> None:
    assert main(["themes", "--theme", "dracula"]) == 0


def test_invalid_config_returns_exit_code(capsys: pytest.CaptureFixture[str]) -> None:
    # refresh out of range → ConfigError surfaced as exit code 2.
    assert main(["dashboard", "--refresh", "999"]) == 2
    assert "configuration error" in capsys.readouterr().err


def test_version_flag() -> None:
    with pytest.raises(SystemExit) as exc:
        build_parser().parse_args(["--version"])
    assert exc.value.code == 0
