from __future__ import annotations

from conftest import FakeClient
from rich.console import Console
from rich.style import Style

from mqtt_monitor.client import MqttMonitor
from mqtt_monitor.config import AppConfig
from mqtt_monitor.themes import get_theme, theme_names
from mqtt_monitor.ui import (
    Dashboard,
    broker_panel,
    browse_view,
    build_console,
    render_browse_snapshot,
    render_snapshot,
    topics_table,
)


def _console(theme: str = "nord") -> Console:
    # Themed, fixed-width, non-terminal, recording — deterministic & headless.
    # Semantic style names (accent/border/value/…) only resolve on a themed
    # console, so tests render through one, exactly like production does.
    return build_console(theme, width=120, record=True, force_terminal=False)


def _monitor() -> MqttMonitor:
    fake = FakeClient()
    return MqttMonitor(AppConfig(), client_factory=lambda: fake)


def _render(console: Console, renderable) -> str:
    console.print(renderable)
    return console.export_text()


def test_build_console_applies_theme() -> None:
    console = build_console("nord")
    assert isinstance(console.get_style("accent"), Style)


def test_broker_panel_empty_state_renders() -> None:
    mon = _monitor()
    out = _render(
        _console(), broker_panel(mon.broker_stats, get_theme("nord"), session_start=0)
    )
    assert "Waiting" in out


def test_broker_panel_with_data_renders() -> None:
    mon = _monitor()
    mon.broker_stats.update("$SYS/broker/version", b"mosquitto 2.0")
    mon.broker_stats.update("$SYS/broker/clients/connected", b"4")
    out = _render(
        _console(), broker_panel(mon.broker_stats, get_theme("nord"), session_start=0)
    )
    assert "Broker" in out and "mosquitto" in out


def test_topics_table_renders_rows() -> None:
    mon = _monitor()
    mon.registry.record("sensors/temp", b"21.5")
    mon.registry.record("sensors/hum", b"55")
    snaps = mon.registry.top("messages")
    out = _render(
        _console(),
        topics_table(
            snaps,
            AppConfig(),
            get_theme("nord"),
            total_messages=2,
            total_bytes=8,
            overall_rate=1.0,
        ),
    )
    assert "sensors/temp" in out


def test_topics_table_empty_renders() -> None:
    out = _render(
        _console("minimal"),
        topics_table(
            [],
            AppConfig(theme="minimal"),
            get_theme("minimal"),
            total_messages=0,
            total_bytes=0,
            overall_rate=0.0,
        ),
    )
    assert "no messages yet" in out


def test_dashboard_renderable_builds_for_all_themes() -> None:
    for name in theme_names():
        mon = _monitor()
        mon.registry.record("a/b", b"x")
        dash = Dashboard(AppConfig(theme=name), mon)
        _render(_console(name), dash.renderable())  # must not raise for any theme


def test_browse_view_with_detail() -> None:
    mon = _monitor()
    mon.registry.record("sensors/temp", b'{"c": 21.5}')
    snaps = mon.registry.snapshot()
    out = _render(
        _console("dracula"),
        browse_view(snaps, AppConfig(theme="dracula"), get_theme("dracula"), detail=snaps[0]),
    )
    assert "sensors/temp" in out


def test_render_snapshot_runs() -> None:
    mon = _monitor()
    mon.registry.record("x", b"1")
    console = _console()
    render_snapshot(AppConfig(), mon, console)
    assert "Topics" in console.export_text()


def test_render_browse_snapshot_focused_topic() -> None:
    mon = _monitor()
    mon.registry.record("sensors/temp", b'{"c": 21.5}')
    console = _console()
    render_browse_snapshot(AppConfig(topic_filter="sensors/temp"), mon, console)
    out = console.export_text()
    assert "sensors/temp" in out and "Payload" in out


def test_render_browse_snapshot_wildcard_uses_latest() -> None:
    mon = _monitor()
    mon.registry.record("a/b", b"hi")
    console = _console()
    render_browse_snapshot(AppConfig(topic_filter="#"), mon, console)
    assert "a/b" in console.export_text()
