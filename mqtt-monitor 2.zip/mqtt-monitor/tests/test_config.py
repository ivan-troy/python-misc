from __future__ import annotations

import ssl

import pytest

from mqtt_monitor.config import AppConfig, ConfigError, ConnectionConfig


def test_defaults_are_valid() -> None:
    cfg = ConnectionConfig()
    assert cfg.host == "localhost"
    assert cfg.port == 1883
    app = AppConfig()
    assert app.refresh_interval == pytest.approx(0.25)


@pytest.mark.parametrize(
    "kwargs",
    [
        {"host": ""},
        {"port": 0},
        {"port": 70000},
        {"keepalive": 1},
        {"protocol": "9"},
        {"transport": "carrier-pigeon"},
        {"password": "secret"},  # no username
    ],
)
def test_invalid_connection_configs(kwargs: dict) -> None:
    with pytest.raises(ConfigError):
        ConnectionConfig(**kwargs)


@pytest.mark.parametrize(
    "kwargs",
    [
        {"topic_filter": ""},
        {"qos": 3},
        {"refresh_hz": 0.0},
        {"refresh_hz": 100},
        {"sort_key": "nonsense"},
        {"top": 0},
    ],
)
def test_invalid_app_configs(kwargs: dict) -> None:
    with pytest.raises(ConfigError):
        AppConfig(**kwargs)


def test_tls_context_none_when_disabled() -> None:
    assert ConnectionConfig(tls=False).tls_context is None


def test_tls_context_built_when_enabled() -> None:
    ctx = ConnectionConfig(tls=True).tls_context
    assert isinstance(ctx, ssl.SSLContext)


def test_tls_insecure_disables_verification() -> None:
    ctx = ConnectionConfig(tls=True, tls_insecure=True).tls_context
    assert ctx is not None
    assert ctx.verify_mode == ssl.CERT_NONE


def test_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("MQTT_HOST", "broker.example.com")
    monkeypatch.setenv("MQTT_PORT", "1884")
    monkeypatch.setenv("MQTT_TLS", "true")
    cfg = ConnectionConfig.from_env()
    assert cfg.host == "broker.example.com"
    assert cfg.port == 1884
    assert cfg.tls is True
