"""Shared pytest fixtures.

Provides a fake paho client so the whole stack can be exercised without a
running broker.  The fake records subscriptions and lets tests drive callbacks
directly.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import pytest


@dataclass
class FakeReasonCode:
    """Mimics paho 2.x ReasonCode for the bits we read."""

    is_failure: bool = False
    value: int = 0

    def __str__(self) -> str:  # pragma: no cover - cosmetic
        return "Success" if not self.is_failure else "Refused"


@dataclass
class FakeMessage:
    """Mimics paho's MQTTMessage."""

    topic: str
    payload: bytes
    qos: int = 0
    retain: bool = False


@dataclass
class FakeClient:
    """Records interactions instead of touching the network."""

    subscriptions: list[tuple[str, int]] = field(default_factory=list)
    published: list[tuple[str, object, int, bool]] = field(default_factory=list)
    connected: bool = False
    loop_running: bool = False
    on_connect = None
    on_disconnect = None
    on_message = None
    on_connect_fail = None

    def connect(self, host: str, port: int, keepalive: int) -> None:
        self.connected = True

    def loop_start(self) -> None:
        self.loop_running = True

    def loop_stop(self) -> None:
        self.loop_running = False

    def disconnect(self) -> None:
        self.connected = False

    def subscribe(self, topic: str, qos: int = 0) -> None:
        self.subscriptions.append((topic, qos))

    def publish(self, topic, payload, qos=0, retain=False):  # pragma: no cover
        self.published.append((topic, payload, qos, retain))


@pytest.fixture
def fake_client() -> FakeClient:
    return FakeClient()
