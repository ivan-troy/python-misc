import { useState } from 'react';

import { ConnectionForm } from './components/ConnectionForm';
import { Dashboard } from './components/Dashboard';
import { ThemePicker } from './components/ThemePicker';
import { useTheme } from './hooks/useTheme';
import type { MonitorConfig } from './lib/config';

export function App() {
  const { theme, setTheme, cycleTheme } = useTheme();
  const [config, setConfig] = useState<MonitorConfig | null>(null);

  return (
    <div className="app">
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      {config ? (
        <Dashboard
          config={config}
          theme={theme}
          onSetTheme={setTheme}
          onCycleTheme={cycleTheme}
          onDisconnect={() => setConfig(null)}
        />
      ) : (
        <div className="landing">
          <header className="landing__bar">
            <Wordmark />
            <ThemePicker theme={theme} onChange={setTheme} />
          </header>
          <main id="main" className="landing__body">
            <ConnectionForm onConnect={setConfig} />
          </main>
          <footer className="landing__footer">
            <span>MQTT over WebSockets</span>
            <span aria-hidden="true">·</span>
            <span>Runs entirely in your browser</span>
          </footer>
        </div>
      )}
    </div>
  );
}

export function Wordmark() {
  return (
    <div className="wordmark" aria-label="mqtt-monitor">
      <span className="wordmark__pulse" aria-hidden="true" />
      <span className="wordmark__text">
        mqtt<span className="wordmark__dim">-monitor</span>
      </span>
    </div>
  );
}
