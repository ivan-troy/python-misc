import { useState } from 'react';

import { defaultConfig, validateConfig, type MonitorConfig } from '../lib/config';

interface Props {
  onConnect: (config: MonitorConfig) => void;
}

/** The pre-flight form: where to connect, what to watch, and how it looks. */
export function ConnectionForm({ onConnect }: Props) {
  const [url, setUrl] = useState('wss://test.mosquitto.org:8081');
  const [topicsText, setTopicsText] = useState('#');
  const [qos, setQos] = useState<0 | 1 | 2>(0);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [trackBroker, setTrackBroker] = useState(true);
  const [errors, setErrors] = useState<string[]>([]);

  function build(demo: boolean): MonitorConfig {
    const topics = topicsText
      .split(/[\n,]/)
      .map((t) => t.trim())
      .filter(Boolean);
    return defaultConfig({
      url,
      topics: topics.length ? topics : ['#'],
      qos,
      username,
      password,
      trackBroker,
      demo,
    });
  }

  function submit(demo: boolean) {
    const config = build(demo);
    const problems = validateConfig(config);
    setErrors(problems);
    if (problems.length === 0) onConnect(config);
  }

  return (
    <section className="panel form" aria-labelledby="form-title">
      <div className="form__head">
        <p className="eyebrow">Connection</p>
        <h1 id="form-title" className="form__title">
          Point it at a broker
        </h1>
        <p className="form__lede">
          Connect over WebSockets to watch topic activity and broker vitals in real time — or run a
          local demo with synthetic traffic.
        </p>
      </div>

      <div className="field">
        <label htmlFor="url">Broker URL</label>
        <input
          id="url"
          className="mono"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="wss://host:port/mqtt"
          spellCheck={false}
          autoComplete="off"
        />
        <p className="field__hint">Must be a ws:// or wss:// endpoint the broker exposes.</p>
      </div>

      <div className="field">
        <label htmlFor="topics">Topics</label>
        <input
          id="topics"
          className="mono"
          value={topicsText}
          onChange={(e) => setTopicsText(e.target.value)}
          placeholder="sensors/#, devices/#"
          spellCheck={false}
          autoComplete="off"
        />
        <p className="field__hint">Comma or newline separated. Wildcards + and # are supported.</p>
      </div>

      <div className="field-row">
        <div className="field field--narrow">
          <label htmlFor="qos">QoS</label>
          <select
            id="qos"
            value={qos}
            onChange={(e) => setQos(Number(e.target.value) as 0 | 1 | 2)}
          >
            <option value={0}>0 — at most once</option>
            <option value={1}>1 — at least once</option>
            <option value={2}>2 — exactly once</option>
          </select>
        </div>
        <div className="field">
          <label htmlFor="username">Username</label>
          <input
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            autoComplete="off"
          />
        </div>
        <div className="field">
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="off"
          />
        </div>
      </div>

      <label className="toggle">
        <input
          type="checkbox"
          checked={trackBroker}
          onChange={(e) => setTrackBroker(e.target.checked)}
        />
        <span>Track broker vitals ($SYS)</span>
      </label>

      {errors.length > 0 && (
        <ul className="form__errors" role="alert">
          {errors.map((err) => (
            <li key={err}>{err}</li>
          ))}
        </ul>
      )}

      <div className="form__actions">
        <button type="button" className="btn btn--primary" onClick={() => submit(false)}>
          Connect
        </button>
        <button type="button" className="btn btn--ghost" onClick={() => submit(true)}>
          Try demo mode
        </button>
      </div>
    </section>
  );
}
