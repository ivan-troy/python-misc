import type { SysRow } from '../lib/sysTopics';

interface Props {
  rows: SysRow[];
}

export function BrokerPanel({ rows }: Props) {
  return (
    <section className="panel broker" aria-labelledby="broker-title">
      <div className="panel__head">
        <p className="eyebrow">Broker</p>
        <h2 id="broker-title" className="panel__title">
          Vitals <span className="panel__title-dim">$SYS</span>
        </h2>
      </div>
      {rows.length === 0 ? (
        <p className="empty">
          Waiting for <code>$SYS</code> data. Not every broker publishes it, or it may be disabled.
        </p>
      ) : (
        <dl className="broker__grid">
          {rows.map((row) => (
            <div key={row.key} className="broker__row">
              <dt>{row.label}</dt>
              <dd className="mono tnum">{row.value}</dd>
            </div>
          ))}
        </dl>
      )}
    </section>
  );
}
