import { formatBytes, humanCount, humanRate } from '../lib/format';
import { overallRate, type StoreSnapshot } from '../lib/metrics';
import { ConnectionState } from '../lib/mqttClient';
import { Wordmark } from '../App';
import { SignalRibbon } from './SignalRibbon';
import { ThemePicker } from './ThemePicker';

interface Props {
  state: ConnectionState;
  detail: string;
  snapshot: StoreSnapshot;
  rateHistory: number[];
  paused: boolean;
  theme: string;
  onSetTheme: (name: string) => void;
  onTogglePause: () => void;
  onReset: () => void;
  onDisconnect: () => void;
}

const STATE_LABEL: Record<ConnectionState, string> = {
  [ConnectionState.Initial]: 'starting',
  [ConnectionState.Connecting]: 'connecting',
  [ConnectionState.Connected]: 'connected',
  [ConnectionState.Reconnecting]: 'reconnecting',
  [ConnectionState.Disconnected]: 'disconnected',
  [ConnectionState.Failed]: 'failed',
};

export function ConnectionBar({
  state,
  detail,
  snapshot,
  rateHistory,
  paused,
  theme,
  onSetTheme,
  onTogglePause,
  onReset,
  onDisconnect,
}: Props) {
  const live = state === ConnectionState.Connected;
  return (
    <header className="connbar">
      <div className="connbar__identity">
        <Wordmark />
        <div className={`status status--${state}`}>
          <span className="status__led" aria-hidden="true" />
          <span className="status__text">{STATE_LABEL[state]}</span>
          <span className="status__detail mono" title={detail}>
            {detail}
          </span>
        </div>
      </div>

      <div className="connbar__signal">
        <SignalRibbon history={rateHistory} live={live} />
      </div>

      <dl className="counters" aria-label="Overall statistics">
        <Counter label="topics" value={humanCount(snapshot.topics.length)} />
        <Counter label="messages" value={humanCount(snapshot.totalMessages)} />
        <Counter label="volume" value={formatBytes(snapshot.totalBytes)} />
        <Counter label="rate" value={humanRate(overallRate(snapshot))} highlight />
      </dl>

      <div className="connbar__controls">
        <button
          type="button"
          className={`btn btn--icon ${paused ? 'is-active' : ''}`}
          onClick={onTogglePause}
          aria-pressed={paused}
          title={paused ? 'Resume (p)' : 'Pause (p)'}
        >
          {paused ? 'Resume' : 'Pause'}
        </button>
        <button type="button" className="btn btn--icon" onClick={onReset} title="Reset stats (r)">
          Reset
        </button>
        <ThemePicker theme={theme} onChange={onSetTheme} />
        <button type="button" className="btn btn--ghost" onClick={onDisconnect}>
          Disconnect
        </button>
      </div>
    </header>
  );
}

function Counter({
  label,
  value,
  highlight = false,
}: {
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div className={`counter ${highlight ? 'counter--accent' : ''}`}>
      <dt>{label}</dt>
      <dd className="mono tnum">{value}</dd>
    </div>
  );
}
