import { useEffect, useRef } from 'react';

interface Props {
  /** Recent samples, oldest first. */
  history: number[];
  /** Whether the connection is live (drives colour intensity). */
  live: boolean;
}

/**
 * The signature element: a phosphor-style trace of overall message throughput.
 * It reads straight from the sample buffer, so it animates as data arrives.
 * Respects prefers-reduced-motion by simply not adding any transition — the
 * trace still updates but nothing eases or glows aggressively.
 */
export function SignalRibbon({ history, live }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);

    const styles = getComputedStyle(canvas);
    const signal = styles.getPropertyValue('--signal').trim() || '#88c0d0';
    const grid = styles.getPropertyValue('--border').trim() || '#333';

    // baseline grid
    ctx.strokeStyle = grid;
    ctx.globalAlpha = 0.5;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, height - 0.5);
    ctx.lineTo(width, height - 0.5);
    ctx.stroke();
    ctx.globalAlpha = 1;

    if (history.length < 2) return;

    const max = Math.max(1, ...history);
    const step = width / (history.length - 1);
    const y = (v: number) => height - (v / max) * (height - 4) - 2;

    // area fill
    ctx.beginPath();
    ctx.moveTo(0, height);
    history.forEach((v, i) => ctx.lineTo(i * step, y(v)));
    ctx.lineTo((history.length - 1) * step, height);
    ctx.closePath();
    ctx.fillStyle = signal;
    ctx.globalAlpha = live ? 0.14 : 0.06;
    ctx.fill();
    ctx.globalAlpha = 1;

    // trace
    ctx.beginPath();
    history.forEach((v, i) => {
      const px = i * step;
      const py = y(v);
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    });
    ctx.strokeStyle = signal;
    ctx.lineWidth = 1.5;
    ctx.globalAlpha = live ? 1 : 0.45;
    ctx.shadowColor = signal;
    ctx.shadowBlur = live ? 6 : 0;
    ctx.stroke();
  }, [history, live]);

  return <canvas ref={canvasRef} className="signal-ribbon" aria-hidden="true" />;
}
