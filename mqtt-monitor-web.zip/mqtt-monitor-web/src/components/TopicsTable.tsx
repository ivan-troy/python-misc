import { formatBytes, humanCount, humanRate, payloadPreview } from '../lib/format';
import { lifetimeRate, sortMetrics, type StoreSnapshot, type TopicRate } from '../lib/metrics';
import type { SortKey } from '../lib/config';

interface Props {
  snapshot: StoreSnapshot;
  rates: Map<string, TopicRate>;
  sortKey: SortKey;
  onSortChange: (key: SortKey) => void;
  topN: number;
  maxPayloadPreview: number;
  selectedTopic: string | null;
  onSelect: (topic: string) => void;
}

const COLUMNS: { key: SortKey; label: string; align: 'left' | 'right' }[] = [
  { key: 'topic', label: 'Topic', align: 'left' },
  { key: 'count', label: 'Count', align: 'right' },
  { key: 'rate', label: 'Msg/s', align: 'right' },
  { key: 'bytes', label: 'Bytes', align: 'right' },
  { key: 'last', label: 'Last payload', align: 'left' },
];

export function TopicsTable({
  snapshot,
  rates,
  sortKey,
  onSortChange,
  topN,
  maxPayloadPreview,
  selectedTopic,
  onSelect,
}: Props) {
  const sorted = sortMetrics(snapshot.topics, sortKey, rates);
  const visible = sorted.slice(0, topN);
  const hidden = sorted.length - visible.length;
  const peakRate = Math.max(
    1,
    ...visible.map((m) => rates.get(m.topic)?.msgRate ?? lifetimeRate(m)),
  );

  return (
    <section className="panel topics" aria-labelledby="topics-title">
      <div className="panel__head panel__head--row">
        <div>
          <p className="eyebrow">Topics</p>
          <h2 id="topics-title" className="panel__title">
            Activity <span className="panel__title-dim">({snapshot.topics.length})</span>
          </h2>
        </div>
        <p className="topics__meta mono">
          sorted by {sortKey}
          {hidden > 0 ? ` · +${hidden} more` : ''}
        </p>
      </div>

      {visible.length === 0 ? (
        <p className="empty">No messages yet. Waiting for the broker to publish.</p>
      ) : (
        <div className="table-wrap" role="region" aria-label="Topic activity" tabIndex={0}>
          <table className="table">
            <thead>
              <tr>
                {COLUMNS.map((col) => (
                  <th
                    key={col.key}
                    className={col.align === 'right' ? 'ta-right' : ''}
                    aria-sort={sortKey === col.key ? 'descending' : 'none'}
                  >
                    <button
                      type="button"
                      className={`th-btn ${sortKey === col.key ? 'is-active' : ''}`}
                      onClick={() => onSortChange(col.key)}
                    >
                      {col.label}
                      {sortKey === col.key && <span aria-hidden="true"> ▾</span>}
                    </button>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {visible.map((metric) => {
                const rate = rates.get(metric.topic)?.msgRate ?? lifetimeRate(metric);
                const meter = Math.min(100, (rate / peakRate) * 100);
                const selected = metric.topic === selectedTopic;
                return (
                  <tr
                    key={metric.topic}
                    className={selected ? 'is-selected' : ''}
                    onClick={() => onSelect(metric.topic)}
                  >
                    <td className="td-topic mono">{metric.topic}</td>
                    <td className="ta-right mono tnum">{humanCount(metric.count)}</td>
                    <td className="ta-right mono tnum td-rate">
                      <span className="meter" style={{ width: `${meter}%` }} aria-hidden="true" />
                      <span className="td-rate__value">{humanRate(rate)}</span>
                    </td>
                    <td className="ta-right mono tnum">{formatBytes(metric.bytes)}</td>
                    <td className="td-payload mono">
                      {metric.lastPayload
                        ? payloadPreview(metric.lastPayload, maxPayloadPreview)
                        : '∅'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
