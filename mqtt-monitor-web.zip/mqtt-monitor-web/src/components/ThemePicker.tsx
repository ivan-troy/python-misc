import { THEMES } from '../lib/themes';

interface Props {
  theme: string;
  onChange: (name: string) => void;
}

export function ThemePicker({ theme, onChange }: Props) {
  return (
    <label className="theme-picker">
      <span className="theme-picker__label">Theme</span>
      <select value={theme} onChange={(e) => onChange(e.target.value)} aria-label="Theme">
        {THEMES.map((t) => (
          <option key={t.name} value={t.name}>
            {t.label}
          </option>
        ))}
      </select>
    </label>
  );
}
