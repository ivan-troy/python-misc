import { decodePayload, formatBytes, formatClock, payloadSize, tryPrettyJson } from '../lib/format';
import type { PayloadRecord } from '../lib/metrics';

interface Props {
  topic: string;
  history: PayloadRecord[];
  onClose: () => void;
}

/** Slide-in inspector: the latest payload pretty-printed, plus recent history. */
export function BrowseDrawer({ topic, history, onClose }: Props) {
  const ordered = [...history].reverse(); // newest first
  const latest = ordered[0];
  const pretty = latest ? tryPrettyJson(latest.payload) : null;

  return (
    <aside className="drawer" aria-label={`Payloads for ${topic}`}>
      <div className="drawer__head">
        <div>
          <p className="eyebrow">Inspect</p>
          <h2 className="drawer__title mono">{topic}</h2>
        </div>
        <button type="button" className="btn btn--icon" onClick={onClose} aria-label="Close">
          Close
        </button>
      </div>

      {!latest ? (
        <p className="empty">No payloads retained for this topic yet.</p>
      ) : (
        <>
          <div className="drawer__latest">
            <div className="drawer__latest-meta mono">
              <span>{formatClock(latest.t)}</span>
              <span>{formatBytes(payloadSize(latest.payload))}</span>
              <span>{pretty ? 'JSON' : 'text'}</span>
            </div>
            <pre className={`payload ${pretty ? 'payload--json' : ''}`}>
              {pretty ?? decodePayload(latest.payload)}
            </pre>
          </div>

          <p className="eyebrow drawer__section">Recent ({ordered.length})</p>
          <ul className="drawer__history">
            {ordered.map((record, i) => (
              <li key={`${record.t}-${i}`} className="drawer__history-item mono">
                <span className="drawer__history-time">{formatClock(record.t)}</span>
                <span className="drawer__history-payload">
                  {payloadPreviewInline(record.payload)}
                </span>
              </li>
            ))}
          </ul>
        </>
      )}
    </aside>
  );
}

function payloadPreviewInline(payload: Uint8Array): string {
  const text = decodePayload(payload).replace(/\s+/g, ' ').trim();
  return text.length > 80 ? `${text.slice(0, 79)}…` : text || '∅';
}
