interface Props {
  interactive: boolean;
}

const KEYS = [
  { key: 'p', label: 'pause' },
  { key: 'r', label: 'reset' },
  { key: 't', label: 'theme' },
  { key: 's', label: 'sort' },
];

export function StatusFooter({ interactive }: Props) {
  return (
    <footer className="status-footer">
      {interactive ? (
        KEYS.map((k) => (
          <span key={k.key} className="keyhint">
            <kbd>{k.key}</kbd>
            {k.label}
          </span>
        ))
      ) : (
        <span className="keyhint">Read-only view</span>
      )}
    </footer>
  );
}
