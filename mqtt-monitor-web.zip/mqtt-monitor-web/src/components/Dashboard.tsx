import { useCallback, useMemo, useState } from 'react';

import { ConnectionBar } from './ConnectionBar';
import { BrokerPanel } from './BrokerPanel';
import { TopicsTable } from './TopicsTable';
import { BrowseDrawer } from './BrowseDrawer';
import { StatusFooter } from './StatusFooter';
import { useKeyboard } from '../hooks/useKeyboard';
import { useMonitor } from '../hooks/useMonitor';
import { SORT_KEYS, type MonitorConfig, type SortKey } from '../lib/config';
import type { ClientFactory } from '../lib/mqttClient';

interface Props {
  config: MonitorConfig;
  theme: string;
  onSetTheme: (name: string) => void;
  onCycleTheme: () => void;
  onDisconnect: () => void;
  /** Test seam: inject a fake MQTT client factory. */
  factory?: ClientFactory;
}

export function Dashboard({
  config,
  theme,
  onSetTheme,
  onCycleTheme,
  onDisconnect,
  factory,
}: Props) {
  const monitor = useMonitor(config, factory);
  const [sortKey, setSortKey] = useState<SortKey>(config.sortKey);
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);

  const cycleSort = useCallback(() => {
    setSortKey((current) => {
      const idx = SORT_KEYS.indexOf(current);
      return SORT_KEYS[(idx + 1) % SORT_KEYS.length] ?? 'rate';
    });
  }, []);

  const shortcuts = useMemo(
    () => ({
      p: monitor.togglePause,
      ' ': monitor.togglePause,
      r: monitor.resetStats,
      t: onCycleTheme,
      s: cycleSort,
      Escape: () => setSelectedTopic(null),
    }),
    [monitor.togglePause, monitor.resetStats, onCycleTheme, cycleSort],
  );
  useKeyboard(shortcuts);

  const history = selectedTopic ? monitor.historyFor(selectedTopic) : [];

  return (
    <div className={`dashboard ${config.trackBroker ? 'dashboard--with-broker' : ''}`}>
      <ConnectionBar
        state={monitor.state}
        detail={monitor.detail}
        snapshot={monitor.snapshot}
        rateHistory={monitor.rateHistory}
        paused={monitor.paused}
        theme={theme}
        onSetTheme={onSetTheme}
        onTogglePause={monitor.togglePause}
        onReset={monitor.resetStats}
        onDisconnect={onDisconnect}
      />

      <main id="main" className="dashboard__body">
        {config.trackBroker && <BrokerPanel rows={monitor.sysRows} />}
        <TopicsTable
          snapshot={monitor.snapshot}
          rates={monitor.rates}
          sortKey={sortKey}
          onSortChange={setSortKey}
          topN={config.topN}
          maxPayloadPreview={config.maxPayloadPreview}
          selectedTopic={selectedTopic}
          onSelect={setSelectedTopic}
        />
        {selectedTopic && (
          <BrowseDrawer
            topic={selectedTopic}
            history={history}
            onClose={() => setSelectedTopic(null)}
          />
        )}
      </main>

      <StatusFooter interactive />
    </div>
  );
}
