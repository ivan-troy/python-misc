import { act, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { BrokerPanel } from './BrokerPanel';
import { BrowseDrawer } from './BrowseDrawer';
import { ConnectionForm } from './ConnectionForm';
import { Dashboard } from './Dashboard';
import { TopicsTable } from './TopicsTable';
import { defaultConfig } from '../lib/config';
import { MetricsStore } from '../lib/metrics';
import type { ClientFactory, MqttLike } from '../lib/mqttClient';
import type { PayloadRecord } from '../lib/metrics';

const enc = (s: string) => new TextEncoder().encode(s);

function snapshotWith(records: [string, string][]) {
  const store = new MetricsStore();
  for (const [topic, payload] of records) store.record(topic, enc(payload));
  return store.snapshot();
}

describe('ConnectionForm', () => {
  it('connects with a valid default config', () => {
    const onConnect = vi.fn();
    render(<ConnectionForm onConnect={onConnect} />);
    fireEvent.click(screen.getByRole('button', { name: 'Connect' }));
    expect(onConnect).toHaveBeenCalledOnce();
    expect(onConnect.mock.calls[0]?.[0].demo).toBe(false);
  });

  it('surfaces validation errors and blocks connection', () => {
    const onConnect = vi.fn();
    render(<ConnectionForm onConnect={onConnect} />);
    fireEvent.change(screen.getByLabelText('Broker URL'), { target: { value: 'not-a-ws-url' } });
    fireEvent.click(screen.getByRole('button', { name: 'Connect' }));
    expect(onConnect).not.toHaveBeenCalled();
    expect(screen.getByRole('alert')).toBeInTheDocument();
  });

  it('starts demo mode regardless of the URL', () => {
    const onConnect = vi.fn();
    render(<ConnectionForm onConnect={onConnect} />);
    fireEvent.click(screen.getByRole('button', { name: 'Try demo mode' }));
    expect(onConnect).toHaveBeenCalledOnce();
    expect(onConnect.mock.calls[0]?.[0].demo).toBe(true);
  });
});

describe('BrokerPanel', () => {
  it('renders rows', () => {
    render(<BrokerPanel rows={[{ key: 'uptime', label: 'Uptime', value: '1d 01:00:00' }]} />);
    expect(screen.getByText('Uptime')).toBeInTheDocument();
    expect(screen.getByText('1d 01:00:00')).toBeInTheDocument();
  });
  it('shows an empty state', () => {
    render(<BrokerPanel rows={[]} />);
    expect(screen.getByText(/Waiting for/i)).toBeInTheDocument();
  });
});

describe('TopicsTable', () => {
  const snapshot = snapshotWith([
    ['sensors/a', '{"c":21}'],
    ['sensors/b', 'x'],
  ]);

  it('renders topic rows', () => {
    render(
      <TopicsTable
        snapshot={snapshot}
        rates={new Map()}
        sortKey="rate"
        onSortChange={vi.fn()}
        topN={100}
        maxPayloadPreview={64}
        selectedTopic={null}
        onSelect={vi.fn()}
      />,
    );
    expect(screen.getByText('sensors/a')).toBeInTheDocument();
    expect(screen.getByText('sensors/b')).toBeInTheDocument();
  });

  it('calls onSortChange when a header is clicked', () => {
    const onSortChange = vi.fn();
    render(
      <TopicsTable
        snapshot={snapshot}
        rates={new Map()}
        sortKey="rate"
        onSortChange={onSortChange}
        topN={100}
        maxPayloadPreview={64}
        selectedTopic={null}
        onSelect={vi.fn()}
      />,
    );
    fireEvent.click(screen.getByRole('button', { name: /Count/ }));
    expect(onSortChange).toHaveBeenCalledWith('count');
  });

  it('calls onSelect when a row is clicked', () => {
    const onSelect = vi.fn();
    render(
      <TopicsTable
        snapshot={snapshot}
        rates={new Map()}
        sortKey="topic"
        onSortChange={vi.fn()}
        topN={100}
        maxPayloadPreview={64}
        selectedTopic={null}
        onSelect={onSelect}
      />,
    );
    fireEvent.click(screen.getByText('sensors/a'));
    expect(onSelect).toHaveBeenCalledWith('sensors/a');
  });
});

describe('BrowseDrawer', () => {
  const history: PayloadRecord[] = [
    { t: Date.now() - 1000, payload: enc('{"c":20}') },
    { t: Date.now(), payload: enc('{"c":21}') },
  ];

  it('pretty-prints the latest JSON payload and lists history', () => {
    render(<BrowseDrawer topic="sensors/a" history={history} onClose={vi.fn()} />);
    expect(screen.getByText('sensors/a')).toBeInTheDocument();
    expect(screen.getByText('JSON')).toBeInTheDocument();
    // two history rows
    expect(screen.getAllByText(/"c":/).length).toBeGreaterThanOrEqual(1);
  });

  it('invokes onClose', () => {
    const onClose = vi.fn();
    render(<BrowseDrawer topic="sensors/a" history={history} onClose={onClose} />);
    fireEvent.click(screen.getByRole('button', { name: 'Close' }));
    expect(onClose).toHaveBeenCalledOnce();
  });
});

describe('Dashboard (integration)', () => {
  afterEach(() => vi.useRealTimers());

  function fakeFactory(messages: [string, string][]): ClientFactory {
    return () => {
      const handlers = new Map<string, ((...a: any[]) => void)[]>();
      const client: MqttLike = {
        on(event: string, handler: (...a: any[]) => void) {
          const list = handlers.get(event) ?? [];
          list.push(handler);
          handlers.set(event, list);
        },
        subscribe() {},
        end() {},
      };
      // Emit after connect() wires all handlers.
      setTimeout(() => {
        for (const h of handlers.get('connect') ?? []) h();
        for (const [topic, payload] of messages) {
          for (const h of handlers.get('message') ?? []) h(topic, enc(payload));
        }
      }, 0);
      return client;
    };
  }

  it('wires MQTT traffic through to the table end to end', () => {
    vi.useFakeTimers();
    const config = defaultConfig({ demo: true, trackBroker: false, refreshHz: 8 });
    render(
      <Dashboard
        config={config}
        theme="nord"
        onSetTheme={vi.fn()}
        onCycleTheme={vi.fn()}
        onDisconnect={vi.fn()}
        factory={fakeFactory([
          ['sensors/kitchen', '{"c":21}'],
          ['sensors/garden', '{"m":40}'],
        ])}
      />,
    );

    act(() => {
      vi.advanceTimersByTime(1); // fire the client's scheduled emit
      vi.advanceTimersByTime(200); // fire the refresh sampler
    });

    expect(screen.getByText('sensors/kitchen')).toBeInTheDocument();
    expect(screen.getByText('sensors/garden')).toBeInTheDocument();
  });

  it('toggles pause from the keyboard', () => {
    vi.useFakeTimers();
    const config = defaultConfig({ demo: true, trackBroker: false });
    render(
      <Dashboard
        config={config}
        theme="nord"
        onSetTheme={vi.fn()}
        onCycleTheme={vi.fn()}
        onDisconnect={vi.fn()}
        factory={fakeFactory([['sensors/a', '1']])}
      />,
    );
    act(() => {
      vi.advanceTimersByTime(1);
    });
    expect(screen.getByRole('button', { name: /Pause/ })).toBeInTheDocument();
    act(() => {
      fireEvent.keyDown(window, { key: 'p' });
    });
    expect(screen.getByRole('button', { name: /Resume/ })).toBeInTheDocument();
  });
});
