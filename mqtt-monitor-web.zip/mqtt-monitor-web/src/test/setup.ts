import '@testing-library/jest-dom/vitest';
import { vi } from 'vitest';

// jsdom has no canvas backend; the signal ribbon degrades to a no-op when
// getContext returns null, which is exactly what we want under test.
vi.spyOn(HTMLCanvasElement.prototype, 'getContext').mockReturnValue(null);
