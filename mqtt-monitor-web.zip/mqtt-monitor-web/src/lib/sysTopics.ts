/**
 * Parsing and presentation of broker `$SYS/#` statistics.
 *
 * Brokers publish their vitals under `$SYS/broker/...` with inconsistent key
 * sets, so we curate the well-known ones with friendly labels + formatters and
 * fall back to showing anything unrecognised verbatim (nothing is dropped).
 */

import { formatBytes, formatDuration, humanCount } from './format';

const SYS_PREFIX = '$SYS/broker/';

type Formatter = (raw: string) => string;

const asBytes: Formatter = (raw) => {
  const n = Number(raw);
  return Number.isFinite(n) ? formatBytes(n) : raw;
};
const asDuration: Formatter = (raw) => {
  const n = Number(raw);
  return Number.isFinite(n) ? formatDuration(n) : raw;
};
const asCount: Formatter = (raw) => {
  const n = Number(raw);
  return Number.isFinite(n) ? humanCount(n) : raw;
};
const asText: Formatter = (raw) => raw;

interface SysField {
  suffix: string;
  label: string;
  format: Formatter;
}

/** Curated, ordered set of well-known `$SYS/broker/*` keys. */
const KNOWN_FIELDS: readonly SysField[] = [
  { suffix: 'version', label: 'Version', format: asText },
  { suffix: 'uptime', label: 'Uptime', format: asDuration },
  { suffix: 'clients/connected', label: 'Clients connected', format: asCount },
  { suffix: 'clients/total', label: 'Clients total', format: asCount },
  { suffix: 'clients/maximum', label: 'Clients peak', format: asCount },
  { suffix: 'subscriptions/count', label: 'Subscriptions', format: asCount },
  { suffix: 'messages/received', label: 'Messages received', format: asCount },
  { suffix: 'messages/sent', label: 'Messages sent', format: asCount },
  { suffix: 'messages/stored', label: 'Messages stored', format: asCount },
  { suffix: 'publish/messages/received', label: 'Publishes received', format: asCount },
  { suffix: 'publish/messages/sent', label: 'Publishes sent', format: asCount },
  { suffix: 'bytes/received', label: 'Bytes received', format: asBytes },
  { suffix: 'bytes/sent', label: 'Bytes sent', format: asBytes },
  { suffix: 'load/messages/received/1min', label: 'Load in (1m)', format: asText },
  { suffix: 'load/messages/sent/1min', label: 'Load out (1m)', format: asText },
  { suffix: 'heap/current', label: 'Heap current', format: asBytes },
  { suffix: 'heap/maximum', label: 'Heap maximum', format: asBytes },
];

const KNOWN_BY_SUFFIX = new Map(KNOWN_FIELDS.map((f) => [f.suffix, f]));
const KNOWN_ORDER = new Map(KNOWN_FIELDS.map((f, i) => [f.suffix, i]));

export interface SysRow {
  key: string;
  label: string;
  value: string;
}

export function isSysTopic(topic: string): boolean {
  return topic.startsWith('$SYS/');
}

/** Thread-of-execution-safe by virtue of the single-threaded event loop. */
export class SysMetrics {
  private readonly raw = new Map<string, string>();

  /** Record a `$SYS` message. Non-`$SYS` topics are ignored. */
  update(topic: string, value: string): void {
    if (!isSysTopic(topic)) return;
    const suffix = topic.startsWith(SYS_PREFIX) ? topic.slice(SYS_PREFIX.length) : topic;
    this.raw.set(suffix, value);
  }

  get size(): number {
    return this.raw.size;
  }

  reset(): void {
    this.raw.clear();
  }

  entries(): Record<string, string> {
    return Object.fromEntries(this.raw);
  }

  /**
   * Rows for display: curated keys first (in canonical order) with friendly
   * labels, then any remaining keys sorted alphabetically.
   */
  friendlyRows(): SysRow[] {
    const known: SysRow[] = [];
    const extra: SysRow[] = [];
    for (const [suffix, value] of this.raw) {
      const field = KNOWN_BY_SUFFIX.get(suffix);
      if (field) {
        known.push({ key: suffix, label: field.label, value: field.format(value) });
      } else {
        extra.push({ key: suffix, label: suffix, value });
      }
    }
    known.sort((a, b) => (KNOWN_ORDER.get(a.key) ?? 0) - (KNOWN_ORDER.get(b.key) ?? 0));
    extra.sort((a, b) => a.key.localeCompare(b.key));
    return [...known, ...extra];
  }
}
