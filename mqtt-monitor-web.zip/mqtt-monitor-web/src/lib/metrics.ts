/**
 * Per-topic metrics accumulation, immutable snapshots, and rate computation.
 *
 * The `MetricsStore` is written to by MQTT message callbacks and read by the
 * render loop via `snapshot()`, which returns a frozen, structurally-shared
 * value object. Because the browser event loop is single-threaded there is no
 * locking to do — a message callback can never interleave with a snapshot read.
 */

import { payloadSize } from './format';
import type { SortKey } from './config';

export interface PayloadRecord {
  readonly t: number; // epoch ms
  readonly payload: Uint8Array;
}

export interface TopicMetric {
  readonly topic: string;
  readonly count: number;
  readonly bytes: number;
  readonly firstSeen: number;
  readonly lastSeen: number;
  readonly lastPayload: Uint8Array | null;
}

export function avgSize(metric: TopicMetric): number {
  return metric.count > 0 ? metric.bytes / metric.count : 0;
}

/** Average rate across a topic's whole observed lifetime (messages/second). */
export function lifetimeRate(metric: TopicMetric): number {
  const span = (metric.lastSeen - metric.firstSeen) / 1000;
  return span > 0 ? (metric.count - 1) / span : 0;
}

export interface StoreSnapshot {
  readonly capturedAt: number;
  readonly startedAt: number;
  readonly totalMessages: number;
  readonly totalBytes: number;
  readonly topics: readonly TopicMetric[];
}

export function elapsedSeconds(snap: StoreSnapshot): number {
  return (snap.capturedAt - snap.startedAt) / 1000;
}

export function overallRate(snap: StoreSnapshot): number {
  const secs = elapsedSeconds(snap);
  return secs > 0 ? snap.totalMessages / secs : 0;
}

interface Accumulator {
  count: number;
  bytes: number;
  firstSeen: number;
  lastSeen: number;
  lastPayload: Uint8Array | null;
  history: PayloadRecord[];
}

export interface MetricsStoreOptions {
  historySize?: number;
  clock?: () => number;
}

export class MetricsStore {
  private readonly topics = new Map<string, Accumulator>();
  private readonly historySize: number;
  private readonly clock: () => number;
  private totalMessages = 0;
  private totalBytes = 0;
  private startedAt: number;
  private cached: StoreSnapshot | null = null;

  constructor({ historySize = 50, clock = Date.now }: MetricsStoreOptions = {}) {
    this.historySize = historySize;
    this.clock = clock;
    this.startedAt = clock();
  }

  record(topic: string, payload: Uint8Array): void {
    const now = this.clock();
    const size = payloadSize(payload);
    let acc = this.topics.get(topic);
    if (!acc) {
      acc = { count: 0, bytes: 0, firstSeen: now, lastSeen: now, lastPayload: null, history: [] };
      this.topics.set(topic, acc);
    }
    acc.count += 1;
    acc.bytes += size;
    acc.lastSeen = now;
    acc.lastPayload = payload;
    acc.history.push({ t: now, payload });
    if (acc.history.length > this.historySize) acc.history.shift();

    this.totalMessages += 1;
    this.totalBytes += size;
    this.cached = null;
  }

  reset(): void {
    this.topics.clear();
    this.totalMessages = 0;
    this.totalBytes = 0;
    this.startedAt = this.clock();
    this.cached = null;
  }

  get messageCount(): number {
    return this.totalMessages;
  }

  /** Retained payloads for every topic matching `prefix` (newest last). */
  history(prefix: string): PayloadRecord[] {
    const out: PayloadRecord[] = [];
    for (const [topic, acc] of this.topics) {
      if (topic === prefix || topic.startsWith(`${prefix}/`) || prefix === '#') {
        out.push(...acc.history);
      }
    }
    out.sort((a, b) => a.t - b.t);
    return out;
  }

  /**
   * Immutable snapshot of current state. The result is cached and only rebuilt
   * after a mutation, so repeated reads within one render frame are cheap.
   */
  snapshot(): StoreSnapshot {
    if (this.cached) return this.cached;
    const topics: TopicMetric[] = [];
    for (const [topic, acc] of this.topics) {
      topics.push({
        topic,
        count: acc.count,
        bytes: acc.bytes,
        firstSeen: acc.firstSeen,
        lastSeen: acc.lastSeen,
        lastPayload: acc.lastPayload,
      });
    }
    this.cached = Object.freeze({
      capturedAt: this.clock(),
      startedAt: this.startedAt,
      totalMessages: this.totalMessages,
      totalBytes: this.totalBytes,
      topics: Object.freeze(topics),
    });
    return this.cached;
  }
}

export interface TopicRate {
  readonly msgRate: number;
  readonly byteRate: number;
}

/**
 * Computes instantaneous rates by differencing two consecutive snapshots. This
 * is O(1) per topic and bounded in memory, unlike keeping per-message
 * timestamp windows.
 */
export class RateComputer {
  private prev: StoreSnapshot | null = null;
  private prevCounts = new Map<string, { count: number; bytes: number }>();

  update(snap: StoreSnapshot): Map<string, TopicRate> {
    const rates = new Map<string, TopicRate>();
    const dt = this.prev ? (snap.capturedAt - this.prev.capturedAt) / 1000 : 0;
    const counts = new Map<string, { count: number; bytes: number }>();

    for (const topic of snap.topics) {
      counts.set(topic.topic, { count: topic.count, bytes: topic.bytes });
      if (dt > 0) {
        const before = this.prevCounts.get(topic.topic);
        const dCount = topic.count - (before?.count ?? 0);
        const dBytes = topic.bytes - (before?.bytes ?? 0);
        rates.set(topic.topic, {
          msgRate: Math.max(0, dCount / dt),
          byteRate: Math.max(0, dBytes / dt),
        });
      }
    }

    this.prev = snap;
    this.prevCounts = counts;
    return rates;
  }

  reset(): void {
    this.prev = null;
    this.prevCounts = new Map();
  }
}

/**
 * Sort topic metrics by the requested key. The live rate map, when supplied,
 * drives the "rate" ordering; otherwise it falls back to lifetime rate.
 */
export function sortMetrics(
  metrics: readonly TopicMetric[],
  key: SortKey,
  rates?: Map<string, TopicRate>,
): TopicMetric[] {
  const copy = [...metrics];
  switch (key) {
    case 'count':
      copy.sort((a, b) => b.count - a.count);
      break;
    case 'bytes':
      copy.sort((a, b) => b.bytes - a.bytes);
      break;
    case 'topic':
      copy.sort((a, b) => a.topic.localeCompare(b.topic));
      break;
    case 'last':
      copy.sort((a, b) => b.lastSeen - a.lastSeen);
      break;
    case 'rate':
      copy.sort((a, b) => {
        const ra = rates?.get(a.topic)?.msgRate ?? lifetimeRate(a);
        const rb = rates?.get(b.topic)?.msgRate ?? lifetimeRate(b);
        return rb - ra;
      });
      break;
  }
  return copy;
}
