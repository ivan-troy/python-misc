/**
 * Presentation helpers shared across the UI.
 *
 * These are pure functions with no DOM or React dependency so they can be unit
 * tested in isolation and reused anywhere (table cells, the browse drawer, the
 * broker panel).
 */

const decoder = new TextDecoder('utf-8', { fatal: false });

/** Coerce an MQTT payload (bytes or string) into a decoded string. */
export function decodePayload(payload: Uint8Array | string): string {
  return typeof payload === 'string' ? payload : decoder.decode(payload);
}

/** Byte length of a payload regardless of representation. */
export function payloadSize(payload: Uint8Array | string): number {
  return typeof payload === 'string'
    ? new TextEncoder().encode(payload).length
    : payload.byteLength;
}

/** Compact counts: 42, 1.5K, 3.2M, 1.1B. */
export function humanCount(n: number): string {
  if (!Number.isFinite(n)) return '—';
  const abs = Math.abs(n);
  if (abs < 1000) return String(Math.round(n));
  if (abs < 1e6) return `${(n / 1e3).toFixed(1)}K`;
  if (abs < 1e9) return `${(n / 1e6).toFixed(1)}M`;
  return `${(n / 1e9).toFixed(1)}B`;
}

/** Message rate with a units suffix; zero renders as an em dash. */
export function humanRate(rate: number): string {
  if (!Number.isFinite(rate) || rate <= 0) return '—';
  if (rate < 1) return `${rate.toFixed(2)}/s`;
  if (rate < 100) return `${rate.toFixed(1)}/s`;
  return `${humanCount(rate)}/s`;
}

const BYTE_UNITS = ['B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB'] as const;

/** IEC byte formatting (1024-based): 512 B, 4.9 KiB, 1.2 MiB. */
export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
  if (bytes < 1024) return `${Math.round(bytes)} B`;
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < BYTE_UNITS.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value.toFixed(1)} ${BYTE_UNITS[unit]}`;
}

/** Human duration: "3d 04:15:09" or "00:07:42". */
export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '—';
  const total = Math.floor(seconds);
  const days = Math.floor(total / 86400);
  const h = Math.floor((total % 86400) / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (v: number) => String(v).padStart(2, '0');
  const clock = `${pad(h)}:${pad(m)}:${pad(s)}`;
  return days > 0 ? `${days}d ${clock}` : clock;
}

/**
 * Single-line payload preview: decodes, collapses whitespace, and truncates
 * with an ellipsis. Empty payloads render as ∅ so an empty row is unmistakable.
 */
export function payloadPreview(payload: Uint8Array | string, maxLength = 64): string {
  const text = decodePayload(payload).replace(/\s+/g, ' ').trim();
  if (text.length === 0) return '∅';
  if (text.length <= maxLength) return text;
  return `${text.slice(0, Math.max(0, maxLength - 1))}…`;
}

/** Try to pretty-print a payload as JSON; returns null when it is not JSON. */
export function tryPrettyJson(payload: Uint8Array | string): string | null {
  const text = decodePayload(payload).trim();
  if (!text || !/^[[{"]/.test(text)) return null;
  try {
    return JSON.stringify(JSON.parse(text), null, 2);
  } catch {
    return null;
  }
}

/** Wall-clock time as HH:MM:SS for a millisecond epoch. */
export function formatClock(epochMs: number): string {
  const d = new Date(epochMs);
  const pad = (v: number) => String(v).padStart(2, '0');
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}
