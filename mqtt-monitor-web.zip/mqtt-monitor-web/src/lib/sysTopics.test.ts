import { describe, expect, it } from 'vitest';

import { SysMetrics, isSysTopic } from './sysTopics';

describe('isSysTopic', () => {
  it('recognises $SYS topics', () => {
    expect(isSysTopic('$SYS/broker/uptime')).toBe(true);
    expect(isSysTopic('sensors/temp')).toBe(false);
  });
});

describe('SysMetrics', () => {
  it('ignores non-$SYS updates', () => {
    const sys = new SysMetrics();
    sys.update('sensors/temp', '22');
    expect(sys.size).toBe(0);
  });

  it('strips the broker prefix and stores raw values', () => {
    const sys = new SysMetrics();
    sys.update('$SYS/broker/uptime', '120');
    expect(sys.entries()).toEqual({ uptime: '120' });
  });

  it('orders known fields canonically and formats them', () => {
    const sys = new SysMetrics();
    sys.update('$SYS/broker/uptime', '90000');
    sys.update('$SYS/broker/version', 'mosquitto 2.0');
    const rows = sys.friendlyRows();
    // version is defined before uptime in the canonical order
    expect(rows.map((r) => r.label)).toEqual(['Version', 'Uptime']);
    expect(rows[1]?.value).toBe('1d 01:00:00');
  });

  it('keeps unknown fields, sorted after known ones', () => {
    const sys = new SysMetrics();
    sys.update('$SYS/broker/version', 'x');
    sys.update('$SYS/broker/zeta/custom', 'z');
    sys.update('$SYS/broker/alpha/custom', 'a');
    const keys = sys.friendlyRows().map((r) => r.key);
    expect(keys[0]).toBe('version');
    expect(keys.slice(1)).toEqual(['alpha/custom', 'zeta/custom']);
  });

  it('resets', () => {
    const sys = new SysMetrics();
    sys.update('$SYS/broker/uptime', '1');
    sys.reset();
    expect(sys.size).toBe(0);
  });
});
