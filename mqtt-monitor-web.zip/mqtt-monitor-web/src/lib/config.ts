/**
 * Connection + monitor configuration: a plain, validated value object.
 *
 * In the browser MQTT can only travel over WebSockets, so the transport is
 * always ws:// or wss:// — there is no raw-TCP option to model.
 */

export type SortKey = 'rate' | 'count' | 'bytes' | 'topic' | 'last';

export const SORT_KEYS: readonly SortKey[] = ['rate', 'count', 'bytes', 'topic', 'last'];

export const SYS_WILDCARD = '$SYS/#';
export const DEFAULT_TOPIC = '#';

export interface MonitorConfig {
  /** Broker WebSocket endpoint, e.g. ws://localhost:9001 or wss://host:8081/mqtt */
  url: string;
  /** Topic filters to subscribe to. */
  topics: string[];
  /** Subscription QoS (0, 1, or 2). */
  qos: 0 | 1 | 2;
  username: string;
  password: string;
  /** Explicit client id; a random one is generated when empty. */
  clientId: string;
  /** Also subscribe to $SYS/# and surface broker vitals. */
  trackBroker: boolean;
  /** UI refresh rate in frames per second (also the rate-sampling cadence). */
  refreshHz: number;
  /** Max characters shown in a payload preview cell. */
  maxPayloadPreview: number;
  /** Ring-buffer length of retained payloads per topic. */
  payloadHistory: number;
  /** Max topic rows shown in the table. */
  topN: number;
  theme: string;
  sortKey: SortKey;
  /** Generate synthetic traffic locally instead of dialing a real broker. */
  demo: boolean;
}

export function defaultConfig(overrides: Partial<MonitorConfig> = {}): MonitorConfig {
  return {
    url: 'ws://localhost:9001',
    topics: [DEFAULT_TOPIC],
    qos: 0,
    username: '',
    password: '',
    clientId: '',
    trackBroker: true,
    refreshHz: 8,
    maxPayloadPreview: 64,
    payloadHistory: 50,
    topN: 100,
    theme: 'nord',
    sortKey: 'rate',
    demo: false,
    ...overrides,
  };
}

/** A stable-ish random client id, matching the CLI's `mqtt-monitor-XXXX` shape. */
export function generateClientId(): string {
  const rand = Math.random().toString(16).slice(2, 10);
  return `mqtt-monitor-${rand}`;
}

/** Effective subscription list: user topics plus $SYS/# when tracking the broker. */
export function subscriptions(config: MonitorConfig): string[] {
  const set = new Set(config.topics.filter((t) => t.trim().length > 0));
  if (config.trackBroker) set.add(SYS_WILDCARD);
  return [...set];
}

/**
 * Validate a config, returning a list of human-readable problems. An empty
 * array means the config is good to connect with.
 */
export function validateConfig(config: MonitorConfig): string[] {
  const errors: string[] = [];

  if (!config.demo) {
    if (!/^wss?:\/\//i.test(config.url)) {
      errors.push('Broker URL must start with ws:// or wss://');
    }
    try {
      void new URL(config.url);
    } catch {
      errors.push('Broker URL is not a valid URL');
    }
  }

  if (config.topics.filter((t) => t.trim().length > 0).length === 0) {
    errors.push('Add at least one topic filter');
  }
  if (![0, 1, 2].includes(config.qos)) {
    errors.push('QoS must be 0, 1, or 2');
  }
  if (config.refreshHz <= 0 || config.refreshHz > 60) {
    errors.push('Refresh rate must be between 0 and 60 Hz');
  }
  if (config.topN <= 0) {
    errors.push('Row limit must be positive');
  }
  return errors;
}
