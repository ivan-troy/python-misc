import { describe, expect, it } from 'vitest';

import { defaultConfig, generateClientId, subscriptions, validateConfig } from './config';

describe('defaultConfig', () => {
  it('applies overrides on top of sensible defaults', () => {
    const cfg = defaultConfig({ topics: ['a/b'], qos: 2 });
    expect(cfg.topics).toEqual(['a/b']);
    expect(cfg.qos).toBe(2);
    expect(cfg.trackBroker).toBe(true);
  });
});

describe('subscriptions', () => {
  it('adds $SYS/# when tracking the broker', () => {
    const subs = subscriptions(defaultConfig({ topics: ['sensors/#'], trackBroker: true }));
    expect(subs).toContain('sensors/#');
    expect(subs).toContain('$SYS/#');
  });
  it('omits $SYS when not tracking, and dedupes', () => {
    const subs = subscriptions(defaultConfig({ topics: ['a', 'a', ''], trackBroker: false }));
    expect(subs).toEqual(['a']);
  });
});

describe('validateConfig', () => {
  it('accepts a good config', () => {
    expect(validateConfig(defaultConfig({ url: 'wss://host:8081' }))).toEqual([]);
  });
  it('rejects a non-ws url', () => {
    expect(validateConfig(defaultConfig({ url: 'http://host' }))).not.toEqual([]);
  });
  it('rejects empty topics', () => {
    expect(validateConfig(defaultConfig({ topics: [' ', ''] }))).not.toEqual([]);
  });
  it('skips url checks in demo mode', () => {
    expect(validateConfig(defaultConfig({ demo: true, url: 'nonsense' }))).toEqual([]);
  });
  it('rejects an out-of-range refresh rate', () => {
    expect(validateConfig(defaultConfig({ refreshHz: 0 }))).not.toEqual([]);
  });
});

describe('generateClientId', () => {
  it('produces unique prefixed ids', () => {
    const a = generateClientId();
    const b = generateClientId();
    expect(a).toMatch(/^mqtt-monitor-/);
    expect(a).not.toBe(b);
  });
});
