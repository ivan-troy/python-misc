/**
 * Theme registry. The actual colour tokens live in CSS (see styles/themes.css)
 * keyed by `[data-theme="..."]`; this module owns the catalogue and selection
 * logic so it can be unit tested and reused by the picker.
 */

export interface ThemeInfo {
  name: string;
  label: string;
  description: string;
}

export const THEMES: readonly ThemeInfo[] = [
  { name: 'nord', label: 'Nord', description: 'Cool arctic blues — the default.' },
  { name: 'dracula', label: 'Dracula', description: 'High-contrast purple night.' },
  { name: 'solarized', label: 'Solarized', description: 'Muted, easy-on-the-eyes tones.' },
  { name: 'matrix', label: 'Matrix', description: 'Phosphor green on black.' },
  { name: 'minimal', label: 'Minimal', description: 'Near-monochrome, low chrome.' },
  { name: 'mono-light', label: 'Mono Light', description: 'Clean light mode for daytime.' },
  { name: 'slate', label: 'Slate', description: 'Neutral slate with a teal accent.' },
] as const;

export const DEFAULT_THEME = 'nord';

const BY_NAME = new Map(THEMES.map((t) => [t.name, t]));

export function themeNames(): string[] {
  return THEMES.map((t) => t.name);
}

const FALLBACK: ThemeInfo = THEMES[0]!;

export function getTheme(name: string): ThemeInfo {
  return BY_NAME.get(name) ?? FALLBACK;
}

/** Next theme in the catalogue, wrapping around; unknown names start at index 0. */
export function nextTheme(name: string): string {
  const idx = THEMES.findIndex((t) => t.name === name);
  const next = THEMES[(idx + 1) % THEMES.length] ?? FALLBACK;
  return next.name;
}
