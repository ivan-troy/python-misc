import { describe, expect, it } from 'vitest';

import { MetricsStore, RateComputer, lifetimeRate, overallRate, sortMetrics } from './metrics';

const enc = (s: string) => new TextEncoder().encode(s);

function fixedClock(times: number[]): () => number {
  let i = 0;
  return () => times[Math.min(i++, times.length - 1)]!;
}

describe('MetricsStore', () => {
  it('accumulates counts and bytes per topic', () => {
    const store = new MetricsStore();
    store.record('a', enc('hello'));
    store.record('a', enc('yo'));
    store.record('b', enc('x'));
    const snap = store.snapshot();
    expect(snap.totalMessages).toBe(3);
    expect(snap.totalBytes).toBe(8);
    const a = snap.topics.find((t) => t.topic === 'a');
    expect(a?.count).toBe(2);
    expect(a?.bytes).toBe(7);
  });

  it('caches snapshots until the next mutation', () => {
    const store = new MetricsStore();
    store.record('a', enc('1'));
    const first = store.snapshot();
    expect(store.snapshot()).toBe(first); // same identity
    store.record('a', enc('2'));
    expect(store.snapshot()).not.toBe(first);
  });

  it('bounds per-topic history and matches by prefix', () => {
    const store = new MetricsStore({ historySize: 2 });
    store.record('sensors/temp', enc('1'));
    store.record('sensors/temp', enc('2'));
    store.record('sensors/temp', enc('3'));
    store.record('other', enc('x'));
    expect(store.history('sensors/temp')).toHaveLength(2); // trimmed to 2
    expect(store.history('sensors')).toHaveLength(2); // prefix match
    expect(store.history('#')).toHaveLength(3); // everything
  });

  it('resets to an empty state', () => {
    const store = new MetricsStore();
    store.record('a', enc('1'));
    store.reset();
    expect(store.snapshot().totalMessages).toBe(0);
  });
});

describe('rates', () => {
  it('computes overall rate from elapsed time', () => {
    const store = new MetricsStore({ clock: fixedClock([0, 1000, 2000, 2000]) });
    store.record('a', enc('1')); // t=0 start captured
    store.record('a', enc('2')); // t=1000
    const snap = store.snapshot(); // t=2000
    // startedAt=0, capturedAt=2000 -> 2 msgs / 2s = 1/s
    expect(overallRate(snap)).toBeCloseTo(1);
  });

  it('differences two snapshots into per-topic rates', () => {
    const t = [0, 0, 0, 1000, 1000];
    const store = new MetricsStore({ clock: fixedClock(t) });
    const rc = new RateComputer();
    store.record('a', enc('1'));
    expect(rc.update(store.snapshot()).size).toBe(0); // first update -> no dt
    store.record('a', enc('2'));
    store.record('a', enc('3'));
    const rates = rc.update(store.snapshot());
    // 2 new messages over 1 second
    expect(rates.get('a')?.msgRate).toBeCloseTo(2);
  });
});

describe('sortMetrics', () => {
  const store = new MetricsStore({ clock: fixedClock([0, 10, 20, 30, 40, 50, 60, 70]) });
  store.record('b', enc('xx'));
  store.record('b', enc('xx'));
  store.record('a', enc('xxxxxx'));
  const topics = store.snapshot().topics;

  it('sorts by count descending', () => {
    expect(sortMetrics(topics, 'count')[0]?.topic).toBe('b');
  });
  it('sorts by bytes descending', () => {
    expect(sortMetrics(topics, 'bytes')[0]?.topic).toBe('a');
  });
  it('sorts by topic name', () => {
    expect(sortMetrics(topics, 'topic')[0]?.topic).toBe('a');
  });
  it('uses supplied live rates for rate ordering', () => {
    const rates = new Map([
      ['a', { msgRate: 99, byteRate: 0 }],
      ['b', { msgRate: 1, byteRate: 0 }],
    ]);
    expect(sortMetrics(topics, 'rate', rates)[0]?.topic).toBe('a');
  });
});

describe('lifetimeRate', () => {
  it('is zero for a single observation', () => {
    const store = new MetricsStore({ clock: fixedClock([0, 0, 0]) });
    store.record('a', enc('1'));
    expect(lifetimeRate(store.snapshot().topics[0]!)).toBe(0);
  });
});
