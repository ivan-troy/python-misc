/**
 * In-browser synthetic broker used by "Demo mode" (and by tests). It implements
 * the same {@link MqttLike} surface as mqtt.js, emitting realistic sensor
 * traffic plus periodic `$SYS/broker/*` stats, so the whole UI can run with no
 * infrastructure at all.
 */

import type { MonitorConfig } from './config';
import type { MqttLike } from './mqttClient';

interface Stream {
  topic: string;
  hz: number;
  make: () => string;
}

const encoder = new TextEncoder();

const STREAMS: Stream[] = [
  { topic: 'sensors/livingroom/temperature', hz: 2, make: () => json({ c: rand(18, 26, 2) }) },
  { topic: 'sensors/livingroom/humidity', hz: 1, make: () => json({ rh: rand(30, 70, 1) }) },
  { topic: 'sensors/kitchen/temperature', hz: 0.5, make: () => json({ c: rand(18, 30, 2) }) },
  {
    topic: 'sensors/garden/soil',
    hz: 0.3,
    make: () => json({ moisture: Math.round(rand(0, 100)) }),
  },
  {
    topic: 'devices/thermostat/state',
    hz: 0.4,
    make: () => json({ on: Math.random() > 0.5, set: 21 }),
  },
  {
    topic: 'telemetry/gps/position',
    hz: 3,
    make: () => json({ lat: rand(-90, 90, 5), lon: rand(-180, 180, 5) }),
  },
  {
    topic: 'logs/app/events',
    hz: 6,
    make: () =>
      json({ level: pick(['INFO', 'WARN', 'ERROR']), msg: 'x'.repeat(Math.round(rand(10, 90))) }),
  },
];

function rand(min: number, max: number, decimals = 0): number {
  const v = min + Math.random() * (max - min);
  return decimals ? Number(v.toFixed(decimals)) : Math.round(v);
}
function pick<T>(items: T[]): T {
  return items[Math.floor(Math.random() * items.length)]!;
}
function json(body: Record<string, unknown>): string {
  return JSON.stringify({ ts: Date.now(), ...body });
}

type Handler = (...args: never[]) => void;

/** A fake MQTT client that generates traffic on a timer. */
export class SimulatorClient implements MqttLike {
  private readonly handlers = new Map<string, Handler[]>();
  private timers: ReturnType<typeof setInterval>[] = [];
  private startedAt = Date.now();
  private received = 0;
  private sent = 0;

  constructor(private readonly config: MonitorConfig) {}

  on(event: string, handler: (...args: never[]) => void): void {
    const list = this.handlers.get(event) ?? [];
    list.push(handler);
    this.handlers.set(event, list);
    if (event === 'connect') {
      // Emit connect on the next tick so listeners are all wired first.
      setTimeout(() => this.start(), 0);
    }
  }

  subscribe(): void {
    // No-op: the simulator emits everything regardless of subscription.
  }

  end(): void {
    this.timers.forEach(clearInterval);
    this.timers = [];
    this.handlers.clear();
  }

  private emit(event: string, ...args: unknown[]): void {
    for (const handler of this.handlers.get(event) ?? []) {
      (handler as (...a: unknown[]) => void)(...args);
    }
  }

  private start(): void {
    this.emit('connect');
    for (const stream of STREAMS) {
      const period = 1000 / stream.hz;
      const timer = setInterval(
        () => {
          const payload = encoder.encode(stream.make());
          this.received += 1;
          this.sent += 1;
          this.emit('message', stream.topic, payload);
        },
        period * (0.7 + Math.random() * 0.6),
      );
      this.timers.push(timer);
    }
    if (this.config.trackBroker) {
      const sys = setInterval(() => this.publishSys(), 1000);
      this.timers.push(sys);
    }
  }

  private publishSys(): void {
    const uptime = Math.floor((Date.now() - this.startedAt) / 1000);
    const stats: Record<string, string> = {
      version: 'simulator 1.0',
      uptime: String(uptime),
      'clients/connected': '1',
      'clients/total': '1',
      'messages/received': String(this.received),
      'messages/sent': String(this.sent),
      'bytes/received': String(this.received * 48),
      'bytes/sent': String(this.sent * 48),
      'subscriptions/count': String(this.config.topics.length),
    };
    for (const [suffix, value] of Object.entries(stats)) {
      this.emit('message', `$SYS/broker/${suffix}`, encoder.encode(value));
    }
  }
}

export function simulatorFactory(config: MonitorConfig): MqttLike {
  return new SimulatorClient(config);
}
