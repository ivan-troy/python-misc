/**
 * Thin wrapper around mqtt.js that drives the metrics + $SYS stores and exposes
 * a small connection state machine. The MQTT client is created through an
 * injectable factory so the wrapper can be unit tested with a fake and reused
 * with the in-browser simulator.
 */

import mqtt, { type IClientOptions } from 'mqtt';

import { decodePayload } from './format';
import { generateClientId, subscriptions, type MonitorConfig } from './config';
import type { MetricsStore } from './metrics';
import { isSysTopic, type SysMetrics } from './sysTopics';

export enum ConnectionState {
  Initial = 'initial',
  Connecting = 'connecting',
  Connected = 'connected',
  Reconnecting = 'reconnecting',
  Disconnected = 'disconnected',
  Failed = 'failed',
}

/** The minimal surface of an MQTT client we rely on (mqtt.js is a superset). */
export interface MqttLike {
  on(event: 'connect', handler: () => void): void;
  on(event: 'message', handler: (topic: string, payload: Uint8Array) => void): void;
  on(event: 'reconnect', handler: () => void): void;
  on(event: 'close', handler: () => void): void;
  on(event: 'offline', handler: () => void): void;
  on(event: 'error', handler: (error: Error) => void): void;
  subscribe(topic: string, opts: { qos: 0 | 1 | 2 }): void;
  end(force?: boolean): void;
}

export type ClientFactory = (config: MonitorConfig) => MqttLike;

/** Default factory: a real mqtt.js WebSocket connection. */
export const realClientFactory: ClientFactory = (config) => {
  const options: IClientOptions = {
    clientId: config.clientId || generateClientId(),
    reconnectPeriod: 2000,
    connectTimeout: 8000,
    clean: true,
    ...(config.username ? { username: config.username } : {}),
    ...(config.password ? { password: config.password } : {}),
  };
  return mqtt.connect(config.url, options);
};

export interface MqttMonitorDeps {
  store: MetricsStore;
  sys: SysMetrics;
  factory?: ClientFactory;
  onStateChange?: (state: ConnectionState, detail: string) => void;
  onMessage?: (topic: string, payload: Uint8Array) => void;
}

const AUTH_FAILURE = /not authorized|bad username|password|refused|unacceptable/i;

export class MqttMonitor {
  private readonly config: MonitorConfig;
  private readonly store: MetricsStore;
  private readonly sys: SysMetrics;
  private readonly factory: ClientFactory;
  private readonly onStateChange: ((state: ConnectionState, detail: string) => void) | undefined;
  private readonly onMessage: ((topic: string, payload: Uint8Array) => void) | undefined;

  private client: MqttLike | null = null;
  private currentState: ConnectionState = ConnectionState.Initial;
  private currentDetail = '';

  constructor(config: MonitorConfig, deps: MqttMonitorDeps) {
    this.config = config;
    this.store = deps.store;
    this.sys = deps.sys;
    this.factory = deps.factory ?? realClientFactory;
    this.onStateChange = deps.onStateChange;
    this.onMessage = deps.onMessage;
  }

  get state(): ConnectionState {
    return this.currentState;
  }

  get detail(): string {
    return this.currentDetail;
  }

  connect(): void {
    this.setState(ConnectionState.Connecting, this.config.url);
    const client = this.factory(this.config);
    this.client = client;

    client.on('connect', () => {
      this.setState(ConnectionState.Connected, this.config.url);
      for (const topic of subscriptions(this.config)) {
        client.subscribe(topic, { qos: this.config.qos });
      }
    });
    client.on('message', (topic, payload) => this.handleMessage(topic, payload));
    client.on('reconnect', () => this.setState(ConnectionState.Reconnecting, 'retrying…'));
    client.on('offline', () => this.setState(ConnectionState.Reconnecting, 'offline'));
    client.on('close', () => {
      if (this.currentState !== ConnectionState.Disconnected) {
        this.setState(ConnectionState.Reconnecting, 'connection closed');
      }
    });
    client.on('error', (error) => {
      this.currentDetail = error.message;
      if (AUTH_FAILURE.test(error.message)) {
        // Terminal: stop retrying, but keep the Failed state visible.
        this.setState(ConnectionState.Failed, error.message);
        this.client?.end(true);
        this.client = null;
      } else {
        this.setState(this.currentState, error.message);
      }
    });
  }

  disconnect(): void {
    this.setState(ConnectionState.Disconnected, 'disconnected');
    this.client?.end(true);
    this.client = null;
  }

  private handleMessage(topic: string, payload: Uint8Array): void {
    if (isSysTopic(topic)) {
      this.sys.update(topic, decodePayload(payload));
    } else {
      this.store.record(topic, payload);
    }
    this.onMessage?.(topic, payload);
  }

  private setState(state: ConnectionState, detail: string): void {
    this.currentState = state;
    this.currentDetail = detail;
    this.onStateChange?.(state, detail);
  }
}
