import { describe, expect, it } from 'vitest';

import { DEFAULT_THEME, THEMES, getTheme, nextTheme, themeNames } from './themes';

describe('themes', () => {
  it('exposes seven themes with nord as default', () => {
    expect(THEMES).toHaveLength(7);
    expect(themeNames()).toContain(DEFAULT_THEME);
    expect(DEFAULT_THEME).toBe('nord');
  });

  it('falls back to the first theme for unknown names', () => {
    expect(getTheme('does-not-exist').name).toBe('nord');
    expect(getTheme('dracula').name).toBe('dracula');
  });

  it('cycles through themes and wraps around', () => {
    expect(nextTheme('nord')).toBe('dracula');
    const last = THEMES[THEMES.length - 1]!.name;
    expect(nextTheme(last)).toBe('nord');
    expect(nextTheme('unknown')).toBe('nord'); // unknown -> index 0
  });
});
