import { describe, expect, it } from 'vitest';

import {
  decodePayload,
  formatBytes,
  formatDuration,
  humanCount,
  humanRate,
  payloadPreview,
  payloadSize,
  tryPrettyJson,
} from './format';

const enc = (s: string) => new TextEncoder().encode(s);

describe('humanCount', () => {
  it.each([
    [42, '42'],
    [999, '999'],
    [1500, '1.5K'],
    [2_400_000, '2.4M'],
    [3_100_000_000, '3.1B'],
  ])('formats %d as %s', (n, expected) => {
    expect(humanCount(n)).toBe(expected);
  });
});

describe('humanRate', () => {
  it.each([
    [0, '—'],
    [0.25, '0.25/s'],
    [12.5, '12.5/s'],
    [250, '250/s'],
    [1500, '1.5K/s'],
  ])('formats %d as %s', (rate, expected) => {
    expect(humanRate(rate)).toBe(expected);
  });
});

describe('formatBytes', () => {
  it.each([
    [0, '0 B'],
    [512, '512 B'],
    [1024, '1.0 KiB'],
    [1536, '1.5 KiB'],
    [1_048_576, '1.0 MiB'],
  ])('formats %d as %s', (n, expected) => {
    expect(formatBytes(n)).toBe(expected);
  });
});

describe('formatDuration', () => {
  it('formats sub-day durations as a clock', () => {
    expect(formatDuration(462)).toBe('00:07:42');
  });
  it('includes days when present', () => {
    expect(formatDuration(90000)).toBe('1d 01:00:00');
  });
});

describe('payloadPreview', () => {
  it('collapses whitespace', () => {
    expect(payloadPreview(enc('a\n  b\tc'))).toBe('a b c');
  });
  it('truncates with an ellipsis', () => {
    expect(payloadPreview(enc('abcdefghij'), 5)).toBe('abcd…');
  });
  it('marks empty payloads', () => {
    expect(payloadPreview(enc(''))).toBe('∅');
  });
  it('never throws on invalid utf-8', () => {
    expect(() => payloadPreview(new Uint8Array([0xff, 0xfe, 0x00]))).not.toThrow();
  });
});

describe('json + size helpers', () => {
  it('pretty-prints JSON payloads', () => {
    expect(tryPrettyJson(enc('{"a":1}'))).toBe('{\n  "a": 1\n}');
  });
  it('returns null for non-JSON', () => {
    expect(tryPrettyJson(enc('hello'))).toBeNull();
  });
  it('reports payload size and decodes bytes', () => {
    expect(payloadSize(enc('abc'))).toBe(3);
    expect(decodePayload(enc('hi'))).toBe('hi');
  });
});
