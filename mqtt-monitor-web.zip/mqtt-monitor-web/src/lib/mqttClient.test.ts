import { beforeEach, describe, expect, it } from 'vitest';

import { defaultConfig } from './config';
import { MetricsStore } from './metrics';
import { ConnectionState, MqttMonitor, type ClientFactory, type MqttLike } from './mqttClient';
import { SysMetrics } from './sysTopics';

const enc = (s: string) => new TextEncoder().encode(s);

class FakeClient implements MqttLike {
  handlers = new Map<string, ((...args: any[]) => void)[]>();
  subs: { topic: string; qos: number }[] = [];
  ended = false;

  on(event: string, handler: (...args: any[]) => void): void {
    const list = this.handlers.get(event) ?? [];
    list.push(handler);
    this.handlers.set(event, list);
  }
  subscribe(topic: string, opts: { qos: 0 | 1 | 2 }): void {
    this.subs.push({ topic, qos: opts.qos });
  }
  end(): void {
    this.ended = true;
  }
  emit(event: string, ...args: any[]): void {
    for (const h of this.handlers.get(event) ?? []) h(...args);
  }
}

describe('MqttMonitor', () => {
  let store: MetricsStore;
  let sys: SysMetrics;
  let fake: FakeClient;
  let factory: ClientFactory;

  beforeEach(() => {
    store = new MetricsStore();
    sys = new SysMetrics();
    fake = new FakeClient();
    factory = () => fake;
  });

  it('subscribes to user topics and $SYS on connect', () => {
    const monitor = new MqttMonitor(defaultConfig({ topics: ['sensors/#'], trackBroker: true }), {
      store,
      sys,
      factory,
    });
    monitor.connect();
    fake.emit('connect');
    expect(monitor.state).toBe(ConnectionState.Connected);
    const topics = fake.subs.map((s) => s.topic);
    expect(topics).toContain('sensors/#');
    expect(topics).toContain('$SYS/#');
  });

  it('routes $SYS and regular messages to the right stores', () => {
    const monitor = new MqttMonitor(defaultConfig(), { store, sys, factory });
    monitor.connect();
    fake.emit('connect');
    fake.emit('message', 'sensors/temp', enc('22'));
    fake.emit('message', '$SYS/broker/uptime', enc('300'));
    expect(store.messageCount).toBe(1);
    expect(sys.entries()).toEqual({ uptime: '300' });
  });

  it('reports auth failures as a terminal Failed state', () => {
    const changes: ConnectionState[] = [];
    const monitor = new MqttMonitor(defaultConfig(), {
      store,
      sys,
      factory,
      onStateChange: (s) => changes.push(s),
    });
    monitor.connect();
    fake.emit('error', new Error('Connection refused: Not authorized'));
    expect(monitor.state).toBe(ConnectionState.Failed);
    expect(fake.ended).toBe(true);
    expect(changes).toContain(ConnectionState.Failed);
  });

  it('moves to reconnecting on offline/close', () => {
    const monitor = new MqttMonitor(defaultConfig(), { store, sys, factory });
    monitor.connect();
    fake.emit('connect');
    fake.emit('offline');
    expect(monitor.state).toBe(ConnectionState.Reconnecting);
  });

  it('ends the client on disconnect', () => {
    const monitor = new MqttMonitor(defaultConfig(), { store, sys, factory });
    monitor.connect();
    monitor.disconnect();
    expect(monitor.state).toBe(ConnectionState.Disconnected);
    expect(fake.ended).toBe(true);
  });
});
