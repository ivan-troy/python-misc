import { afterEach, describe, expect, it, vi } from 'vitest';

import { defaultConfig } from './config';
import { SimulatorClient } from './simulator';

afterEach(() => {
  vi.useRealTimers();
});

describe('SimulatorClient', () => {
  it('emits connect then a stream of messages including $SYS', () => {
    vi.useFakeTimers();
    const client = new SimulatorClient(defaultConfig({ demo: true, trackBroker: true }));
    let connected = false;
    const topics: string[] = [];
    client.on('connect', () => {
      connected = true;
    });
    client.on('message', (topic: string) => {
      topics.push(topic);
    });

    vi.advanceTimersByTime(0); // fire the scheduled start()
    expect(connected).toBe(true);

    vi.advanceTimersByTime(3000); // let streams + $SYS tick
    expect(topics.length).toBeGreaterThan(0);
    expect(topics.some((t) => t.startsWith('$SYS/'))).toBe(true);

    client.end();
    const count = topics.length;
    vi.advanceTimersByTime(3000);
    expect(topics.length).toBe(count); // no more after end()
  });
});
