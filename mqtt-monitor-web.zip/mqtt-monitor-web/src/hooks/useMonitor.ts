import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import type { MonitorConfig } from '../lib/config';
import {
  MetricsStore,
  RateComputer,
  type StoreSnapshot,
  type TopicRate,
  overallRate,
} from '../lib/metrics';
import {
  ConnectionState,
  MqttMonitor,
  realClientFactory,
  type ClientFactory,
} from '../lib/mqttClient';
import { simulatorFactory } from '../lib/simulator';
import { SysMetrics, type SysRow } from '../lib/sysTopics';

export interface MonitorView {
  state: ConnectionState;
  detail: string;
  snapshot: StoreSnapshot;
  rates: Map<string, TopicRate>;
  sysRows: SysRow[];
  /** Recent overall message-rate samples, oldest first (for the signal ribbon). */
  rateHistory: number[];
  paused: boolean;
  togglePause: () => void;
  resetStats: () => void;
  historyFor: (topic: string) => { t: number; payload: Uint8Array }[];
}

const RATE_HISTORY_LENGTH = 160;

/**
 * Owns the metrics/$SYS stores and the MQTT connection, and republishes an
 * immutable view of them to React on a fixed cadence (config.refreshHz). Data
 * accumulates continuously; only the *rendered* view is throttled — the same
 * design as the terminal app's live loop.
 */
export function useMonitor(config: MonitorConfig, factoryOverride?: ClientFactory): MonitorView {
  const store = useRef<MetricsStore>(null as unknown as MetricsStore);
  const sys = useRef(new SysMetrics());
  const rateComputer = useRef(new RateComputer());
  if (store.current === null) {
    store.current = new MetricsStore({ historySize: config.payloadHistory });
  }

  const [state, setState] = useState<ConnectionState>(ConnectionState.Initial);
  const [detail, setDetail] = useState('');
  const [snapshot, setSnapshot] = useState<StoreSnapshot>(() => store.current.snapshot());
  const [rates, setRates] = useState<Map<string, TopicRate>>(new Map());
  const [sysRows, setSysRows] = useState<SysRow[]>([]);
  const [rateHistory, setRateHistory] = useState<number[]>([]);
  const [paused, setPaused] = useState(false);
  const pausedRef = useRef(paused);
  pausedRef.current = paused;

  const factory: ClientFactory = useMemo(
    () => factoryOverride ?? (config.demo ? simulatorFactory : realClientFactory),
    [factoryOverride, config.demo],
  );

  // (Re)establish the connection whenever the effective config changes.
  useEffect(() => {
    const monitor = new MqttMonitor(config, {
      store: store.current,
      sys: sys.current,
      factory,
      onStateChange: (s, d) => {
        setState(s);
        setDetail(d);
      },
    });
    monitor.connect();
    return () => monitor.disconnect();
  }, [config, factory]);

  // Render loop: sample the stores at refreshHz.
  useEffect(() => {
    const period = 1000 / Math.max(1, config.refreshHz);
    const id = setInterval(() => {
      if (pausedRef.current) return;
      const snap = store.current.snapshot();
      setSnapshot(snap);
      setRates(rateComputer.current.update(snap));
      setSysRows(sys.current.friendlyRows());
      setRateHistory((prev) => {
        const next = [...prev, overallRate(snap)];
        return next.length > RATE_HISTORY_LENGTH ? next.slice(-RATE_HISTORY_LENGTH) : next;
      });
    }, period);
    return () => clearInterval(id);
  }, [config.refreshHz]);

  const togglePause = useCallback(() => setPaused((p) => !p), []);

  const resetStats = useCallback(() => {
    store.current.reset();
    sys.current.reset();
    rateComputer.current.reset();
    setSnapshot(store.current.snapshot());
    setRates(new Map());
    setSysRows([]);
    setRateHistory([]);
  }, []);

  const historyFor = useCallback((topic: string) => store.current.history(topic), []);

  return {
    state,
    detail,
    snapshot,
    rates,
    sysRows,
    rateHistory,
    paused,
    togglePause,
    resetStats,
    historyFor,
  };
}
