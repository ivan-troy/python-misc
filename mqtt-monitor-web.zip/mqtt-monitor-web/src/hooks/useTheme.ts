import { useCallback, useEffect, useState } from 'react';

import { DEFAULT_THEME, getTheme, nextTheme } from '../lib/themes';

const STORAGE_KEY = 'mqtt-monitor:theme';

function readInitial(): string {
  if (typeof localStorage === 'undefined') return DEFAULT_THEME;
  const saved = localStorage.getItem(STORAGE_KEY);
  return saved ? getTheme(saved).name : DEFAULT_THEME;
}

/** Applies the theme to <html data-theme> and persists the choice. */
export function useTheme(): {
  theme: string;
  setTheme: (name: string) => void;
  cycleTheme: () => void;
} {
  const [theme, setThemeState] = useState<string>(readInitial);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    if (typeof localStorage !== 'undefined') localStorage.setItem(STORAGE_KEY, theme);
  }, [theme]);

  const setTheme = useCallback((name: string) => setThemeState(getTheme(name).name), []);
  const cycleTheme = useCallback(() => setThemeState((t) => nextTheme(t)), []);

  return { theme, setTheme, cycleTheme };
}
