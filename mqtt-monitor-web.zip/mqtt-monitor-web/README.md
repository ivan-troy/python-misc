# mqtt-monitor (web)

A modern, themeable dashboard for watching an MQTT broker in real time from the
browser: overall broker health via `$SYS`, live per-topic metrics (rate, count,
volume, last payload), and a payload inspector with JSON pretty-printing. It is
the web counterpart to the `mqtt-monitor` terminal app and follows the same
design: a framework-agnostic metrics core, immutable snapshots, and a render
loop that samples on a fixed cadence rather than on every message.

Because browsers cannot open raw MQTT/TCP sockets, the transport is **MQTT over
WebSockets** using [mqtt.js](https://github.com/mqttjs/MQTT.js) v5.

## Highlights

- **Broker vitals** — subscribes to `$SYS/#` and renders curated, human-readable
  stats (uptime, clients, throughput, bytes, heap).
- **Live topic table** — message count, instantaneous rate, byte volume, and a
  one-line payload preview, with a rate-meter bar behind each row so the busiest
  topics read as a heatmap. Sort by rate, count, bytes, name, or recency.
- **Payload inspector** — click any topic to see the latest payload
  pretty-printed (JSON-aware) plus a scrollable history.
- **Signal ribbon** — a live sparkline of overall throughput, tinted by
  connection state.
- **Seven themes** — nord (default), dracula, solarized, matrix, minimal,
  mono-light, and slate. Choice is persisted.
- **Demo mode** — an in-browser simulator generates realistic sensor traffic and
  `$SYS` stats, so you can explore the whole UI with no broker at all.
- **Keyboard control** — `p` pause, `r` reset, `t` cycle theme, `s` cycle sort.

## Requirements

- Node.js 20 or newer.

## Setup

```bash
npm install
```

## Run

```bash
npm run dev        # start the Vite dev server (prints a local URL)
npm run build      # type-check and produce a production build in dist/
npm run preview    # serve the production build locally
```

Open the printed URL, then either fill in a broker URL and press **Connect**, or
press **Try demo mode** to watch synthetic traffic immediately.

## Quality gate

```bash
npm run check         # typecheck + lint + test (run this before committing)
npm run typecheck     # tsc -b --noEmit (strict)
npm run lint          # eslint (type-aware)
npm run test          # vitest run
npm run test:coverage # vitest with V8 coverage
npm run format        # prettier --write
```

The project is TypeScript in `strict` mode with the extra `noUncheckedIndexedAccess`
and `exactOptionalPropertyTypes` guards, linted with type-aware `typescript-eslint`,
and tested with Vitest + Testing Library (71 tests, ~95% line coverage of the
library, hooks, and components).

## Connecting to a real broker

You need a broker that exposes a **WebSocket** listener.

**Public test broker (no setup):**

```
wss://test.mosquitto.org:8081
```

**Local Mosquitto with WebSockets** — a sample config is included at
`mosquitto.dev.conf`:

```conf
listener 1883                # normal MQTT
listener 9001
protocol websockets          # MQTT over WebSockets for the browser
allow_anonymous true
```

Run it with:

```bash
mosquitto -c mosquitto.dev.conf -v
```

then connect the app to `ws://localhost:9001`. Publish some traffic with any
client, e.g. `mosquitto_pub -h localhost -t sensors/room/temp -m '{"c":21.5}'`.

Notes on transport: use `ws://` for local/plaintext and `wss://` when the page
is served over HTTPS (browsers block mixed content). Not every broker publishes
`$SYS`; if the broker panel stays empty, that data is disabled or unsupported.

## Architecture

```
src/
  lib/            framework-agnostic core (no React)
    format.ts       number/byte/rate/payload formatting
    config.ts       connection config value object + validation
    metrics.ts      MetricsStore, immutable snapshots, RateComputer, sorting
    sysTopics.ts    $SYS parsing + curated friendly rows
    themes.ts       theme catalogue + selection logic
    mqttClient.ts   mqtt.js wrapper + connection state machine (injectable factory)
    simulator.ts    in-browser synthetic broker (demo mode + test fixture)
  hooks/
    useMonitor.ts   owns the stores + connection; samples them at refreshHz
    useTheme.ts     applies + persists the theme
    useKeyboard.ts  global shortcuts
  components/       presentational React (Dashboard, TopicsTable, BrokerPanel, …)
  styles/           themes.css (tokens per theme) + global.css
```

The `MetricsStore` is a plain class written by MQTT callbacks and read via
`snapshot()`, which returns a frozen, cached value object. `useMonitor` samples
that snapshot on an interval (the configured refresh rate) and computes rates by
differencing consecutive snapshots — so render cost is bounded by the refresh
rate, not the message rate. Because the browser event loop is single-threaded,
no locking is required. The MQTT client is created through an injectable
factory, which is how the demo simulator and the tests swap in a fake without
touching the network.

## License

MIT — see [LICENSE](./LICENSE).
