"""Pipeline runner — orchestrates one execution.

This module is the only place where the various pipeline modules
(state, locking, quiescence, transport, outbox, alerting) are wired
together. The runner is invoked once per scheduled tick by the
operating-system scheduler (Windows Task Scheduler, cron, systemd).

Architecture:

* :func:`run_pipeline` is the public entry point. It handles the two
  concerns that exist *before* a run can start: acquiring the
  cross-process lock, and opening the state store. If either fails,
  no :class:`PipelineRun` is constructed and we return an appropriate
  :class:`RunResult`.

* :class:`PipelineRun` owns one execution. Each phase of the run is a
  method on the class, sharing per-run state (run_id, batch signature,
  result struct) via attributes rather than threading through every
  function signature. :meth:`PipelineRun.execute` walks the lifecycle.

Run lifecycle (each named phase is recorded in ``state.run_steps``):

1. acquire lock (skipped run if held by another process)
2. ``cleanup`` — clean stale staging .tmp + age out old outbox/sent
3. record_run_start
4. ``drain_outbox`` — publish any prior-run files left in outbox/pending
5. ``quiescence`` — wait for source folder to settle
6. ``discover`` — list source files, filter against processed_files
7. ``fetch`` — parallel copy to local fetched/, with retry
8. ``parse`` — parse all fetched files
9. ``merge`` — run the merge pipeline (CsvMerger)
10. ``write_outbox`` — durable write of merged output + manifest
11. ``publish`` — HTTP PUT, on success move outbox file to sent/
12. ``mark_processed`` — record (path, hash) tuples in state
13. record_run_finished
14. release lock

Resilience:
* Lock held → exit cleanly without recording a failed run.
* Quiescence timeout → catastrophic alert (the source isn't behaving).
* Drain failure → abort current run (conservative ordering policy).
* Fetch/parse/merge/publish failure → record batch failure, increment
  attempt count, quarantine + alert if max attempts reached.
* Any unexpected exception → record run as failed, alert as catastrophic
  if no batch signature was assigned yet (failed pre-batch).
"""

from __future__ import annotations

import logging
import traceback
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Iterator

from csv_merger.merger import CsvMerger
from csv_merger.pipeline._errors import (
    LockHeldError,
    PermanentError,
    PipelineError,
    QuiescenceTimeout,
    TransientError,
)
from csv_merger.pipeline.alerting import (
    ALERT_CATASTROPHIC,
    ALERT_QUARANTINE,
    Alerter,
)
from csv_merger.pipeline.config import PipelineConfig
from csv_merger.pipeline.locking import FileLock
from csv_merger.pipeline.delivery import (
    Delivery,
    DeliveryResult,
    build_delivery,
)
from csv_merger.pipeline.outbox import (
    OutboxManifest,
    cleanup_old_sent,
    cleanup_staging_debris,
    list_pending,
    mark_published,
    read_manifest,
    write_to_outbox,
)
from csv_merger.pipeline.quiescence import wait_for_quiescence
from csv_merger.pipeline.state import (
    RUN_STATUS_FAILED,
    RUN_STATUS_SUCCESS,
    STEP_STATUS_SKIPPED,
    StateStore,
    compute_batch_signature,
    compute_file_hash,
)
from csv_merger.pipeline.transport import (
    fetch_files,
)

logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------- #
# Run result                                                                  #
# --------------------------------------------------------------------------- #


@dataclass
class RunResult:
    """Outcome of a single pipeline run, useful for tests and operators."""

    run_id: int | None = None
    status: str = RUN_STATUS_FAILED  # default to failed; success is explicit
    batch_signature: str | None = None
    files_processed: int = 0
    drained_outbox_count: int = 0
    error: str | None = None
    skipped_lock_held: bool = False
    skipped_quarantined: bool = False
    quarantined_now: bool = False
    alerts_sent: list[str] = field(default_factory=list)


# --------------------------------------------------------------------------- #
# Public entry point                                                          #
# --------------------------------------------------------------------------- #


def run_pipeline(config: PipelineConfig) -> RunResult:
    """Execute one pipeline run.

    Returns a :class:`RunResult` describing the outcome. **Never
    raises** for operational conditions (lock held, batch failed,
    publish blocked by pending) — those are surfaced via the result.
    Genuine programming bugs (e.g. ``AttributeError``) still propagate.
    """
    result = RunResult()

    # Lock acquisition is outside of run-state — we don't want to
    # record a "failed" run just because the previous run is still
    # going (which is normal at the 2-minute cadence).
    try:
        lock = FileLock(config.state.lock_path)
        lock.acquire()
    except LockHeldError as exc:
        logger.info("skipping run: %s", exc)
        result.skipped_lock_held = True
        result.error = str(exc)
        return result

    try:
        return _execute_under_lock(config, result)
    finally:
        lock.release()


def _execute_under_lock(
    config: PipelineConfig, result: RunResult,
) -> RunResult:
    """Open the state store and execute the run.

    State-store init failure is catastrophic — without state we can't
    safely record anything. We alert via the emergency path (a one-shot
    SMTP send not gated by the normal state-backed rate limit) and
    return.
    """
    try:
        state = StateStore(config.state.db_path)
    except Exception as exc:
        logger.exception("could not open state DB")
        result.error = f"state init failed: {exc}"
        _emergency_alert(
            config,
            "Pipeline catastrophic: state DB unavailable",
            f"State DB at {config.state.db_path} failed to open: {exc}\n\n"
            f"{traceback.format_exc()}",
        )
        return result

    try:
        with state:
            run = PipelineRun(config, state, result)
            return run.execute()
    except Exception as exc:  # pragma: no cover — last-resort net
        logger.exception("unexpected error in pipeline runner")
        result.error = f"{type(exc).__name__}: {exc}"
        return result


# --------------------------------------------------------------------------- #
# PipelineRun                                                                 #
# --------------------------------------------------------------------------- #


class PipelineRun:
    """One execution of the pipeline.

    Construct once per run, then call :meth:`execute`. The class holds
    per-run state (run_id, batch signature, in-flight new-file list) as
    attributes so individual phase methods don't need long parameter
    lists.

    The class is not designed for reuse across runs — its identity is
    one run. To run again, construct a new instance with a fresh
    :class:`RunResult`.

    Phase methods are named after the corresponding ``run_steps`` row
    they record. Each one either completes its step or raises an
    exception that :meth:`execute` routes to the right terminal state.
    """

    def __init__(
        self,
        config: PipelineConfig,
        state: StateStore,
        result: RunResult,
    ) -> None:
        self._config = config
        self._state = state
        self._result = result
        self._alerter = Alerter(config.email, state)
        # Delivery strategy is chosen by config.delivery.mode. Built
        # once here so the same instance handles both drain (pending
        # outbox files) and the current run's batch.
        self._delivery: Delivery = build_delivery(config)

        # Filled in as the run progresses. Methods that need these
        # check that the prerequisite phase set them; an attribute
        # access on a None field is a programming bug worth crashing on.
        self._run_id: int | None = None
        self._batch_sig: str | None = None
        self._new_files: list[tuple[Path, str]] = []

    # ------------------------------------------------------------------ #
    # Main entry point                                                   #
    # ------------------------------------------------------------------ #

    def execute(self) -> RunResult:
        """Walk the run lifecycle and return the final :class:`RunResult`.

        The body reads as a narrative of what happens: cleanup, start,
        drain, check, quiesce, discover, check, process, mark, finish.
        Each ``if`` represents an early-exit condition; the happy path
        falls through to ``_finish_success``.
        """
        self._cleanup()
        self._start_run()

        try:
            self._drain_outbox()
            if self._outbox_has_pending():
                return self._defer_for_pending_outbox()

            self._quiesce()
            self._discover()
            if not self._new_files:
                return self._finish_no_new_work()

            self._compute_batch_signature()
            if self._state.is_batch_quarantined(self._require_batch_sig()):
                return self._skip_quarantined()

            try:
                self._process_batch()
            except (TransientError, PermanentError) as exc:
                return self._handle_batch_failure(exc)

            self._mark_processed()
            return self._finish_success()

        except QuiescenceTimeout as exc:
            return self._finish_quiescence_timeout(exc)
        except PipelineError as exc:
            return self._finish_pipeline_error(exc)

    # ------------------------------------------------------------------ #
    # Phases                                                             #
    # ------------------------------------------------------------------ #

    def _cleanup(self) -> None:
        """Best-effort startup cleanup; failures are warnings, not fatal.

        Done before ``start_run`` so a cleanup failure doesn't pollute
        the run record.
        """
        try:
            cleanup_staging_debris(self._config.folders.staging)
        except Exception:
            logger.exception("cleanup_staging_debris failed; continuing")
        try:
            cleanup_old_sent(
                self._config.folders.outbox_sent,
                self._config.outbox.sent_retention_days,
            )
        except Exception:
            logger.exception("cleanup_old_sent failed; continuing")

    def _start_run(self) -> None:
        """Allocate a run_id and record the run start in state."""
        self._run_id = self._state.start_run()
        self._result.run_id = self._run_id
        logger.info("starting pipeline run %d", self._run_id)

    def _drain_outbox(self) -> None:
        """Publish any pending outbox files left from prior runs.

        Each pending file is treated as its own batch for quarantine
        purposes (the manifest carries its own batch_signature).
        Failures are recorded against that signature; quarantined
        files are skipped.

        Sets :attr:`_result.drained_outbox_count`.
        """
        run_id = self._require_run_id()
        with self._state.step(run_id, "drain_outbox"):
            self._result.drained_outbox_count = self._drain_outbox_impl()

    def _drain_outbox_impl(self) -> int:
        pending = list_pending(self._config.folders.outbox_pending)
        if not pending:
            return 0

        logger.info("draining %d pending outbox file(s)", len(pending))
        drained = 0
        for pending_file in pending:
            try:
                manifest = read_manifest(pending_file)
            except PipelineError as exc:
                # Malformed/missing manifest — we can't safely drain.
                # Log and move on; operator needs to intervene.
                logger.error(
                    "skipping pending file %s: %s", pending_file.name, exc
                )
                continue

            if self._state.is_batch_quarantined(manifest.batch_signature):
                logger.warning(
                    "skipping quarantined pending file %s",
                    pending_file.name,
                )
                continue

            try:
                delivery_result = self._delivery.deliver(
                    pending_file,
                    manifest,
                    idempotency_key=manifest.batch_signature,
                )
                self._log_notification_outcome(
                    pending_file.name, delivery_result
                )
                mark_published(
                    pending_file, self._config.folders.outbox_sent
                )
                self._state.mark_processed(
                    manifest.run_id,
                    list(manifest.source_files),
                )
                self._state.clear_batch_failure(manifest.batch_signature)
                drained += 1
                logger.info(
                    "drained outbox file %s (%d source files marked processed)",
                    pending_file.name,
                    len(manifest.source_files),
                )
            except (TransientError, PermanentError) as exc:
                self._record_drain_failure(pending_file, manifest, exc)

        return drained

    def _record_drain_failure(
        self,
        pending_file: Path,
        manifest: object,  # OutboxManifest, untyped to avoid circular import
        exc: BaseException,
    ) -> None:
        """Record a drain-side batch failure and alert if quarantined.

        Drain failures use the same quarantine bookkeeping as new-batch
        failures (same ``failed_batches`` table, same threshold). The
        difference: drain failures don't set ``quarantined_now`` on the
        RunResult because they're not about the current run's batch.
        """
        sig: str = manifest.batch_signature  # type: ignore[attr-defined]
        attempts = self._state.record_batch_failure(
            sig,
            max_attempts=self._config.retry_policy.max_attempts_per_batch,
            error_text=f"drain: {type(exc).__name__}: {exc}",
        )
        now_quarantined = (
            attempts >= self._config.retry_policy.max_attempts_per_batch
        )
        logger.warning(
            "drain failed for %s (attempt %d): %s",
            pending_file.name,
            attempts,
            exc,
        )
        if now_quarantined:
            self._send_quarantine_alert(
                f"Pipeline: pending batch quarantined ({pending_file.name})",
                f"Outbox file {pending_file.name} failed {attempts} "
                f"times to publish.\n\nLast error: {exc}\n\n"
                f"Operator action required.",
            )

    def _outbox_has_pending(self) -> bool:
        """Check whether any outbox files remain after the drain attempt."""
        return bool(list_pending(self._config.folders.outbox_pending))

    def _quiesce(self) -> None:
        """Wait for the source folder to stop changing."""
        run_id = self._require_run_id()
        with self._state.step(run_id, "quiescence"):
            self._source_files = wait_for_quiescence(
                self._config.folders.source,
                quiet_seconds=self._config.quiescence.quiet_seconds,
                max_wait_seconds=self._config.quiescence.max_wait_seconds,
                poll_interval_seconds=(
                    self._config.quiescence.poll_interval_seconds
                ),
            )

    def _discover(self) -> None:
        """Hash each source file; drop ones already processed.

        Populates :attr:`_new_files` with ``(path, content_hash)`` tuples.
        """
        run_id = self._require_run_id()
        with self._state.step(run_id, "discover"):
            new_files: list[tuple[Path, str]] = []
            for path in self._source_files:
                try:
                    file_hash = compute_file_hash(path)
                except OSError as exc:
                    raise PipelineError(
                        f"cannot hash {path}: {exc}"
                    ) from exc
                if not self._state.is_processed(str(path), file_hash):
                    new_files.append((path, file_hash))
            self._new_files = new_files
            logger.info(
                "discovery: %d source files, %d new",
                len(self._source_files),
                len(new_files),
            )

    def _compute_batch_signature(self) -> None:
        """Compute the batch signature once we know the new-file set."""
        self._batch_sig = compute_batch_signature(
            (str(p), h) for p, h in self._new_files
        )
        self._result.batch_signature = self._batch_sig

    def _process_batch(self) -> None:
        """Fetch → parse → merge → write_outbox → publish.

        Any :class:`TransientError` or :class:`PermanentError` raised
        from this chain propagates to :meth:`execute` and is routed
        to :meth:`_handle_batch_failure`.
        """
        run_id = self._require_run_id()
        batch_sig = self._require_batch_sig()

        # --- Fetch ----------------------------------------------------- #
        with self._state.step(run_id, "fetch"):
            # We don't use the return value here — fetch_files writes
            # the files into config.folders.fetched, which is where
            # CsvMerger reads from below. The call's side effect is
            # what matters.
            fetch_files(
                [p for p, _ in self._new_files],
                self._config.folders.staging,
                self._config.folders.fetched,
                parallel_workers=self._config.fetch.parallel_workers,
            )

        # --- Parse / merge (delegated to existing CsvMerger) ---------- #
        # We use a temporary directory to hold the merged output before
        # the outbox write. CsvMerger writes atomically into the
        # output_path we give it; we then atomically copy it into the
        # outbox.
        with TemporaryDirectory(
            prefix="csv-merger-run-",
            dir=str(self._config.folders.staging),
        ) as scratch:
            scratch_path = Path(scratch)
            merged_output = scratch_path / "merged.txt"

            with self._state.step(run_id, "parse"):
                # Parsing is part of the merge step in the current
                # CsvMerger API; we record the step but the actual work
                # happens in `merge` below. Splitting CsvMerger into
                # parse + merge phases would be a larger refactor.
                pass

            with self._state.step(run_id, "merge"):
                merger = CsvMerger(
                    input_dir=self._config.folders.fetched,
                    output_path=merged_output,
                )
                merger.run()

            # --- Write outbox ----------------------------------------- #
            with self._state.step(run_id, "write_outbox"):
                outbox_file = write_to_outbox(
                    merged_output,
                    run_id=run_id,
                    batch_signature=batch_sig,
                    pending_dir=self._config.folders.outbox_pending,
                    source_files=[
                        (str(p), h) for p, h in self._new_files
                    ],
                )

        # --- Publish --------------------------------------------------- #
        with self._state.step(run_id, "publish"):
            # Build the manifest for the delivery call. This matches the
            # one already written to disk by write_to_outbox; we
            # construct an in-memory copy rather than re-reading the
            # sidecar (one less I/O op, same content).
            manifest = OutboxManifest(
                batch_signature=batch_sig,
                run_id=run_id,
                source_files=tuple(
                    (str(p), h) for p, h in self._new_files
                ),
            )
            delivery_result = self._delivery.deliver(
                outbox_file,
                manifest,
                idempotency_key=batch_sig,
            )
            self._log_notification_outcome(
                outbox_file.name, delivery_result
            )
            mark_published(
                outbox_file, self._config.folders.outbox_sent
            )

    def _mark_processed(self) -> None:
        """Record processed files in state. The commit point for "owned"."""
        run_id = self._require_run_id()
        with self._state.step(run_id, "mark_processed"):
            self._state.mark_processed(
                run_id,
                ((str(p), h) for p, h in self._new_files),
            )
            self._result.files_processed = len(self._new_files)

    # ------------------------------------------------------------------ #
    # Terminal handlers (each returns the populated RunResult)           #
    # ------------------------------------------------------------------ #

    def _defer_for_pending_outbox(self) -> RunResult:
        """Drain didn't clear pending; skip new-batch work."""
        run_id = self._require_run_id()
        remaining = list_pending(self._config.folders.outbox_pending)
        logger.warning(
            "skipping new batch: %d outbox file(s) still pending after drain",
            len(remaining),
        )
        self._state.finish_run(
            run_id,
            status=RUN_STATUS_FAILED,
            error_text=(
                f"{len(remaining)} outbox file(s) still pending "
                "after drain; new batch deferred"
            ),
        )
        self._result.status = RUN_STATUS_FAILED
        self._result.error = "outbox drain incomplete"
        return self._result

    def _finish_no_new_work(self) -> RunResult:
        """No new files to process; record skipped steps and finish."""
        run_id = self._require_run_id()
        logger.info("no new files to process")
        _record_skipped_steps(
            self._state,
            run_id,
            ("fetch", "parse", "merge", "write_outbox",
             "publish", "mark_processed"),
        )
        self._state.finish_run(run_id, status=RUN_STATUS_SUCCESS)
        self._result.status = RUN_STATUS_SUCCESS
        return self._result

    def _skip_quarantined(self) -> RunResult:
        """Pre-existing quarantine record; skip the run."""
        run_id = self._require_run_id()
        batch_sig = self._require_batch_sig()
        logger.warning(
            "skipping run: batch %s is quarantined", batch_sig[:16]
        )
        self._state.finish_run(
            run_id,
            status=RUN_STATUS_FAILED,
            error_text="batch is quarantined; requires operator action",
            batch_signature=batch_sig,
        )
        self._result.status = RUN_STATUS_FAILED
        self._result.skipped_quarantined = True
        return self._result

    def _handle_batch_failure(self, exc: BaseException) -> RunResult:
        """Record a batch failure and decide whether to quarantine + alert."""
        run_id = self._require_run_id()
        batch_sig = self._require_batch_sig()

        error_text = f"{type(exc).__name__}: {exc}"
        attempts = self._state.record_batch_failure(
            batch_sig,
            max_attempts=self._config.retry_policy.max_attempts_per_batch,
            error_text=error_text,
        )
        self._state.finish_run(
            run_id,
            status=RUN_STATUS_FAILED,
            error_text=error_text,
            batch_signature=batch_sig,
        )
        self._result.status = RUN_STATUS_FAILED
        self._result.error = error_text

        quarantined = (
            attempts >= self._config.retry_policy.max_attempts_per_batch
        )
        self._result.quarantined_now = quarantined

        logger.error(
            "batch failed (attempt %d/%d, %squarantined): %s",
            attempts,
            self._config.retry_policy.max_attempts_per_batch,
            "" if quarantined else "not ",
            exc,
        )

        if quarantined:
            self._send_quarantine_alert(
                f"Pipeline: batch {batch_sig[:16]} quarantined",
                f"Batch failed {attempts} consecutive times.\n\n"
                f"Last error: {error_text}\n\n"
                f"Run ID: {run_id}\n"
                f"Source file count: {self._result.files_processed or '?'}\n\n"
                f"Operator action required.",
            )

        return self._result

    def _finish_success(self) -> RunResult:
        """Happy path: clear any prior batch failure and record success."""
        run_id = self._require_run_id()
        batch_sig = self._require_batch_sig()
        self._state.clear_batch_failure(batch_sig)
        self._state.finish_run(
            run_id,
            status=RUN_STATUS_SUCCESS,
            batch_signature=batch_sig,
        )
        self._result.status = RUN_STATUS_SUCCESS
        logger.info(
            "pipeline run %d completed successfully (%d files)",
            run_id,
            len(self._new_files),
        )
        return self._result

    def _finish_quiescence_timeout(
        self, exc: QuiescenceTimeout,
    ) -> RunResult:
        """Source folder never settled; catastrophic alert."""
        run_id = self._require_run_id()
        logger.exception("quiescence timeout")
        self._state.finish_run(
            run_id,
            status=RUN_STATUS_FAILED,
            error_text=str(exc),
        )
        self._send_catastrophic_alert(
            "Pipeline: source folder did not quiesce",
            f"Run {run_id} aborted: {exc}",
        )
        self._result.error = str(exc)
        return self._result

    def _finish_pipeline_error(self, exc: PipelineError) -> RunResult:
        """Catch-all for our own errors that escaped batch handling.

        Drain failures, hash failures during discover, and other
        PipelineError subclasses land here. We alert catastrophic
        because the operator needs to know — these aren't normal batch
        failures the auto-retry will handle.
        """
        run_id = self._require_run_id()
        logger.exception("pipeline error")
        self._state.finish_run(
            run_id,
            status=RUN_STATUS_FAILED,
            error_text=str(exc),
        )
        self._send_catastrophic_alert(
            f"Pipeline run {run_id} failed",
            f"{type(exc).__name__}: {exc}\n\n{traceback.format_exc()}",
        )
        self._result.error = str(exc)
        return self._result

    # ------------------------------------------------------------------ #
    # Utility methods                                                    #
    # ------------------------------------------------------------------ #

    def _log_notification_outcome(
        self,
        file_name: str,
        result: DeliveryResult,
    ) -> None:
        """Log the notification-side outcome of a delivery.

        Strategies that don't issue a follow-up notification (e.g.
        :class:`~csv_merger.pipeline.delivery.HttpDelivery`) report
        ``notification_sent=None`` and this is a no-op. Strategies
        that do (e.g. share+MQTT) report True/False, and a False
        outcome surfaces here as a warning. The file is still
        considered delivered in either case.
        """
        if result.notification_sent is None:
            return
        if result.notification_sent:
            logger.debug(
                "delivery notification sent for %s", file_name
            )
            return
        # Notification failed. The file is on the destination but the
        # consumer's hint didn't make it. Surface this loudly enough
        # for operators to see, but don't fail the run — the next tick
        # will not re-attempt because the file is already in
        # outbox/sent.
        logger.warning(
            "delivery succeeded but notification failed for %s: %s",
            file_name,
            result.notification_error,
        )

    def _send_quarantine_alert(self, subject: str, body: str) -> None:
        r = self._alerter.send(ALERT_QUARANTINE, subject, body)
        if r.sent:
            self._result.alerts_sent.append(ALERT_QUARANTINE)

    def _send_catastrophic_alert(self, subject: str, body: str) -> None:
        r = self._alerter.send(ALERT_CATASTROPHIC, subject, body)
        if r.sent:
            self._result.alerts_sent.append(ALERT_CATASTROPHIC)

    def _require_run_id(self) -> int:
        """Assert run_id is set; only call in phases that follow start_run."""
        if self._run_id is None:
            raise AssertionError(
                "phase called before _start_run() set run_id"
            )
        return self._run_id

    def _require_batch_sig(self) -> str:
        """Assert batch_sig is set; only call after _compute_batch_signature."""
        if self._batch_sig is None:
            raise AssertionError(
                "phase called before _compute_batch_signature() set batch_sig"
            )
        return self._batch_sig


# --------------------------------------------------------------------------- #
# Module-level helpers (not specific to one run)                              #
# --------------------------------------------------------------------------- #


def _record_skipped_steps(
    state: StateStore,
    run_id: int,
    step_names: tuple[str, ...],
) -> None:
    """Record steps as ``skipped`` so observability queries see them.

    Uses the same context manager API but immediately marks the step
    as skipped instead of running it. Done when there's no work for
    the step (e.g. no files to fetch).
    """
    for name in step_names:
        with _record_as_skipped(state, run_id, name):
            pass


@contextmanager
def _record_as_skipped(
    state: StateStore,
    run_id: int,
    step_name: str,
) -> Iterator[None]:
    """Like ``state.step`` but records the step as ``skipped`` on success.

    We achieve this by recording via the normal step API then patching
    the row to ``skipped`` status — clean way to reuse the timing code
    rather than duplicating the SQL.
    """
    with state.step(run_id, step_name):
        yield
    # Patch status after the step recorded success.
    state._conn.execute(
        "UPDATE run_steps SET status = ? "
        "WHERE run_id = ? AND step_name = ?",
        (STEP_STATUS_SKIPPED, run_id, step_name),
    )


def _emergency_alert(
    config: PipelineConfig, subject: str, body: str,
) -> None:
    """Send an alert without state-store rate limiting.

    Used only when the state store itself cannot be opened, which is
    a catastrophic condition the operator needs to know about. We
    swallow any SMTP errors — alerting must never be the cause of
    silent failure.
    """
    try:
        # Build a no-state Alerter shim by constructing an in-memory
        # store. This still gives us rate limiting (against nothing,
        # so the first call goes through) and reuses the SMTP logic.
        from csv_merger.pipeline.alerting import Alerter as _A
        from csv_merger.pipeline.state import StateStore as _S
        with TemporaryDirectory() as tmp:
            tmp_state = _S(Path(tmp) / "emergency.db")
            try:
                _A(config.email, tmp_state).send(
                    ALERT_CATASTROPHIC, subject, body,
                )
            finally:
                tmp_state.close()
    except Exception:
        logger.exception("emergency alert path itself failed")
